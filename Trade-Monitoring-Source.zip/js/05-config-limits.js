/* ============================================================
   Trader control profile
   Every threshold a rule tests against belongs to the trader, not to the desk:
   their own ticket authorisation, their own position limit, their own approved
   products, their own tenor cap, their own peer cohort. Two people sitting side
   by side on the same desk are held to different limits, and the engine holds
   each of them to their own — which is the whole point of running detection at
   trader granularity rather than pooling a desk.
============================================================ */
const GRADE_MULT={"Associate":{tk:1.6,pos:5.0,tenor:5,ctpy:0.45,w:1.0},
                  "Senior":{tk:2.8,pos:6.5,tenor:10,ctpy:0.38,w:1.5},
                  "Executive Director":{tk:4.6,pos:8.0,tenor:30,ctpy:0.34,w:2.2}};
const niceLimit=v=>v>=200?Math.round(v/50)*50:v>=60?Math.round(v/10)*10:v>=20?Math.round(v/5)*5:Math.round(v);
TRADERS.forEach(t=>{
  const d=DESK_BY_ID[t.deskId], g=GRADE_MULT[t.grade];
  // Authorisation is sized to the book the trader actually runs: a $25m repo
  // ticket limit would be meaningless on a desk whose median deal is $75m.
  const scale=median(d.mandate.map(p=>PROD_BY_NAME[p].med));
  t.ticketLimit=niceLimit(scale*g.tk);
  t.posLimit=niceLimit(t.ticketLimit*g.pos);
  t.tenorYrs=g.tenor; t.ctpyCap=g.ctpy;
  /* An associate is signed off for part of the desk's list, never all of it —
     but the part has to move. Taking the first N of the mandate for everybody
     leaves whatever sits at the end untraded across the whole floor, which is
     how a desk named for NDFs ends up barely booking one. A sliding window over
     the mandate covers every product while still narrowing with seniority. */
  const per=t.grade==="Executive Director"?d.mandate.length
           :t.grade==="Senior"?Math.max(3,Math.ceil(d.mandate.length*0.72))
           :Math.max(2,Math.ceil(d.mandate.length*0.52));
  const off=d.traders.indexOf(t)*2, out=[];
  for(let k=0;k<per;k++) out.push(d.mandate[(off+k)%d.mandate.length]);
  t.products=uniq(out);
  // Each trader faces their own handful of counterparties. A floor-wide list
  // makes concentration meaningless: nobody deals with forty names, and the
  // rule that asks "who is this trader's flow going to?" needs a real answer.
  t.ctpys=shuffle(COUNTERPARTIES.filter(c=>INST_TYPES.indexOf(c.type)>=0)).slice(0,randInt(6,10))
    .concat(shuffle(COUNTERPARTIES.filter(c=>INST_TYPES.indexOf(c.type)<0)).slice(0,randInt(2,4)));
});
TRADERS.forEach(t=>{
  const d=DESK_BY_ID[t.deskId];
  t.supervisor=(d.traders.filter(x=>x.grade==="Executive Director"&&x.id!==t.id)[0]
              ||TRADERS.filter(x=>x.grade==="Executive Director"&&x.id!==t.id)[0]).name;
});

/* Peer cohort — same grade, same kind of book. "Unusual" is measured against
   the people doing the same job, which is the only comparison that survives an
   argument with a desk head. Cohorts cut across desks on purpose: two juniors
   on two FX desks are better comparators for each other than either is for the
   ED sitting next to them. */
const COHORT_FAM={fx:"FX & Options",ndf:"FX & Options",fxopt:"FX & Options",rate:"Rates",
  bondg:"Credit, Equity & Financing",bondc:"Credit, Equity & Financing",repo:"Credit, Equity & Financing",
  cds:"Credit, Equity & Financing",cdsi:"Credit, Equity & Financing",trs:"Credit, Equity & Financing",
  eq:"Credit, Equity & Financing",eqopt:"Credit, Equity & Financing"};
const FINE_COHORT={}, BY_GRADE={};
TRADERS.forEach(t=>{
  const k=t.grade+" · "+(COHORT_FAM[PROD_BY_NAME[DESK_BY_ID[t.deskId].mandate[0]].fam]||"Other");
  (FINE_COHORT[k]=FINE_COHORT[k]||[]).push(t);
  (BY_GRADE[t.grade]=BY_GRADE[t.grade]||[]).push(t);
  t.fineKey=k;
});
// A cohort of one or two compares a trader with themselves. Where the finer
// split is too thin to mean anything, the comparator widens to everyone of
// that grade rather than pretending a group of two is a peer group.
const COHORTS={};
TRADERS.forEach(t=>{
  const fine=FINE_COHORT[t.fineKey];
  if(fine.length>=3){ t.peers=fine; t.cohort=t.fineKey; }
  else { t.peers=BY_GRADE[t.grade]; t.cohort=t.grade+" · all books"; }
  (COHORTS[t.cohort]=COHORTS[t.cohort]||[]).push(t);
});
const COHORT_KEYS=Object.keys(COHORTS);

/* Structure names per option product, so the instrument on the ticket is one
   the product could actually be. */
const STRUCTURES={
  "FX Vanilla Option":["25d call","25d put","ATM straddle","10d risk reversal","ATM call","ATM put"],
  "FX Barrier Option":["knock-in call","knock-out put","reverse KO call","up-and-out call","down-and-in put"],
  "FX Digital Option":["digital call","digital put","one-touch","no-touch","double-no-touch"],
  "FX Accumulator":["accumulator","decumulator","target redemption forward"],
  "FX Variance Swap":["variance swap","volatility swap"],
  "Equity Option":["call","put","collar","risk reversal"],
  "Variance Swap":["variance swap","volatility swap"],
};