/* ============================================================
   Derived indices
============================================================ */
/* The hour the alerting activity was actually executed, taken from the earliest
   deal on the alert. Booking time is a behaviour in its own right — concealment
   clusters outside the hours anyone is watching — so it earns its own axis. */
ALERTS.forEach(a=>{
  let m=null;
  const ct=[], ch=[], tb=[], sb=[];
  a.tradeIds.forEach(id=>{
    const t=TRADES_BY_ID[id]; if(!t) return;
    if(m===null||t.execMin<m) m=t.execMin;
    if(ct.indexOf(t.ctpy)<0) ct.push(t.ctpy);
    if(ch.indexOf(t.channel)<0) ch.push(t.channel);
    const b1=tenorBandOf(t.tenor); if(tb.indexOf(b1)<0) tb.push(b1);
    const b2=sizeBandOf(t.notional); if(sb.indexOf(b2)<0) sb.push(b2);
  });
  a.hour=m===null?null:Math.min(23,Math.floor(m/60));
  a.ctpys=ct; a.channels=ch; a.tenorBands=tb; a.sizeBands=sb;
});

const TRADER_STATS={};
TRADERS.forEach(t=>TRADER_STATS[t.id]={id:t.id,name:t.name,deskId:t.deskId,cohort:t.cohort,
  trades:0,notional:0,pnl:0,alerts:0,crit:0,susp:0,score:0,rules:{}});
const RULE_STATS={};
RULES.forEach(r=>RULE_STATS[r.id]={id:r.id,hits:0,open:0,passed:0,susp:0,notional:0,months:Array(12).fill(0),days:Array(DAYS).fill(0)});
ALERTS.forEach(a=>{
  const s=RULE_STATS[a.ruleId]; s.hits++; s.notional+=a.notional;
  if(a.status==="Open"||a.status==="In Review") s.open++;
  else if(a.status==="Passed") s.passed++; else s.susp++;
  s.days[a.day]++;
});
// Twelve rolling months ending today, oldest first.
const MONTH_KEYS=[];
(function(){
  for(let i=11;i>=0;i--){ const d=new Date(TODAY.getFullYear(),TODAY.getMonth()-i,1); MONTH_KEYS.push({y:d.getFullYear(),m:d.getMonth(),label:MONTHS[d.getMonth()],full:MONTHS[d.getMonth()]+" "+String(d.getFullYear()).slice(2)}); }
})();
const monthIdxOf=d=>{ for(let i=0;i<12;i++) if(MONTH_KEYS[i].y===d.getFullYear()&&MONTH_KEYS[i].m===d.getMonth()) return i; return -1; };
ALERTS.forEach(a=>{ const mi=monthIdxOf(a.date); if(mi>=0) RULE_STATS[a.ruleId].months[mi]++; });
