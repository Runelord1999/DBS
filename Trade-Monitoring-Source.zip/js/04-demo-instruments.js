/* ============================================================
   Instruments — reference levels per product family. Trade prices are drawn
   around these, and distance from them is what the off-market rules measure,
   so the reference belongs in the data model, not in the detector.
============================================================ */
/* pair, reference level, and a volatility multiplier — the HKD is pegged inside
   a 7.75–7.85 band and the CNH is managed, so neither can be walked like a free
   float without producing a level that would never print. */
const CCY_PAIRS=[
  ["EUR/USD",1.0842,1.00],["USD/JPY",152.35,1.05],["GBP/USD",1.2715,1.05],
  ["AUD/USD",0.6612,1.15],["USD/CHF",0.8925,0.95],["NZD/USD",0.6035,1.20],
  ["USD/CAD",1.3585,0.85],["EUR/JPY",165.20,1.10],["USD/SGD",1.3405,0.60],
  ["USD/HKD",7.8100,0.05],["USD/CNH",7.2380,0.40],
];
const NDF_VOL={"USD/KRW":1.15,"USD/TWD":0.55,"USD/IDR":0.85,"USD/INR":0.45,"USD/PHP":0.60,"USD/CNY":0.30};
const NDF_PAIRS=[
  ["USD/KRW",1338.5,0.85],["USD/TWD",32.352,0.020],["USD/IDR",15720,9.5],
  ["USD/INR",83.552,0.028],["USD/PHP",57.205,0.038],["USD/CNY",7.2415,0.0025],
];
const RATE_CCY=[["USD",4.28],["EUR",2.62],["GBP",4.05],["JPY",0.78],["SGD",3.11],["AUD",4.16],["HKD",4.34],["CNY",2.15]];
const GOVT_ISSUERS=[["US Treasury","USD"],["UK Gilt","GBP"],["Bund","EUR"],["JGB","JPY"],["SGS","SGD"],["ACGB","AUD"],["HKGB","HKD"]];
const CORP_ISSUERS=[
  ["Arcadia Energy 5.25% 2031","BBB"],["Northwind Telecom 4.60% 2029","BBB-"],["Kestrel Mining 6.10% 2033","BB+"],
  ["Vantara Property 7.25% 2028","BB-"],["Halcyon Airlines 8.40% 2030","B+"],["Meridian Utilities 3.90% 2035","A-"],
  ["Solstice Retail 5.75% 2027","BB"],["Pinnacle Chemicals 4.15% 2032","BBB+"],["Cobalt Shipping 6.80% 2029","BB-"],
  ["Everline Healthcare 3.45% 2031","A"],
];
const CDS_NAMES=[
  ["Vantara Property","BB-"],["Halcyon Airlines","B+"],["Kestrel Mining","BB+"],["Cobalt Shipping","BB-"],
  ["Solstice Retail","BB"],["Northwind Telecom","BBB-"],["Arcadia Energy","BBB"],["Pinnacle Chemicals","BBB+"],
];
const CDS_INDICES=["iTraxx Asia ex-Japan S42","iTraxx Europe Main S42","CDX.NA.IG S43","iTraxx Australia S42"];
const EQ_UNDERLYINGS=[
  ["Helion Semiconductor","HLN"],["Pacific Orient Bank","POB"],["Aurora Robotics","ARB"],["Sentinel Insurance","SNL"],
  ["Kaimana Resorts","KMN"],["Vertex BioSciences","VXB"],["Nimbus Cloud Ltd","NBC"],["Tanjong Motors","TJM"],
];
const EQ_INDICES=["HSI Futures","Nikkei 225 Futures","S&P 500 Futures","MSCI Asia ex-J Futures","STI Futures"];

const COUNTERPARTIES=[
  ["Meridian Global Bank","Bank","London"],["Sovereign Atlantic Bank","Bank","London"],["Crown Pacific Bank","Bank","Hong Kong"],
  ["Straits Union Bank","Bank","Singapore"],["Zenith Capital Bank","Bank","London"],["Cathay Continental Bank","Bank","Taiwan"],
  ["Orient Pacific Bank","Bank","China"],["Northbridge Global Bank","Bank","Hong Kong"],["Silverline Intl Bank","Bank","Singapore"],
  ["Ganges Merchant Bank","Bank","India"],["Helios Atlantic Bank","Bank","London"],["Anchor Union Bank","Bank","Hong Kong"],
  ["Blackfen Capital Partners","Hedge Fund","London"],["Sable Ridge Macro Fund","Hedge Fund","Singapore"],
  ["Cygnet Alpha Partners","Hedge Fund","Hong Kong"],["Redwater Global Macro","Hedge Fund","London"],
  ["Tessellate Quant Fund","Hedge Fund","Singapore"],["Ironbark Systematic","Hedge Fund","Sydney"],
  ["Aurelian Asset Management","Asset Manager","London"],["Pinewood Pension Trust","Asset Manager","Singapore"],
  ["Concord Life Assurance","Insurer","Hong Kong"],["Harbourfront Investments","Asset Manager","Singapore"],
  ["Kestrel Mining Ltd","Corporate","Australia"],["Arcadia Energy plc","Corporate","London"],
  ["Northwind Telecom","Corporate","Singapore"],["Tanjong Motors","Corporate","Malaysia"],
  ["Vantara Property Group","Corporate","Hong Kong"],["Halcyon Airlines","Corporate","Singapore"],
  ["Solstice Retail Holdings","Corporate","Hong Kong"],["Pinnacle Chemicals","Corporate","Singapore"],
  ["Everline Healthcare","Corporate","London"],["Cobalt Shipping","Corporate","Greece"],
  ["Lattice Prime Brokerage","Broker","London"],["Fairhaven Securities","Broker","Hong Kong"],
  ["Marchmont Interdealer","Broker","London"],["Oakstone Prime","Broker","Singapore"],
  ["Sunrise Family Office","Private Client","Singapore"],["Verandah Holdings Pte","Private Client","Singapore"],
  ["Peregrine Trust (Cayman)","Private Client","Cayman"],["Blue Lantern Ventures","Private Client","BVI"],
].map(a=>({name:a[0],type:a[1],country:a[2]}));
/* Counterparties with a documented connection to a member of staff — the
   related-party register the surveillance system reconciles trades against. */
/* Benchmark and block flow is institutional: a family-office trust printing
   $300m into the 4pm fix reads as a data error rather than as a finding. */
const INST_TYPES=["Bank","Hedge Fund","Asset Manager","Broker","Insurer"];
const RELATED_PARTIES={
  "Verandah Holdings Pte":"Director is the spouse of a member of trading staff",
  "Peregrine Trust (Cayman)":"Beneficial owner matches a staff personal-account declaration",
  "Blue Lantern Ventures":"Registered address shared with a declared staff dependant",
};
const INST_CTPY=COUNTERPARTIES.filter(c=>INST_TYPES.indexOf(c.type)>=0);
/* Jurisdictions the financial-crime policy rates as high risk for payment
   routing, and the names the wall keeps the trading floor out of. Both are
   checked per trader: a wall crossing is granted to a person, not to a desk. */
const HIGH_RISK_JUR=[["Seychelles","High — FATF grey list"],["Panama","High — enhanced due diligence"],
  ["Cyprus","Elevated — shell-company exposure"],["Latvia","Elevated — correspondent banking"],
  ["Cayman","Elevated — beneficial-ownership opacity"],["BVI","High — beneficial-ownership opacity"]];
const RESTRICTED=[["Vantara Property","Advisory mandate live — corporate finance wall"],
  ["Halcyon Airlines","Restructuring committee — bank is a lender"],
  ["Kestrel Mining","Announced acquisition financing in progress"],
  ["Solstice Retail","Covenant negotiation — bank holds material non-public information"]];
const INTERNAL_BOOKS=["TRSY-FUNDING","XVA-DESK","PROP-LEGACY","CVA-HEDGE","STRUCT-WAREHOUSE"];
const CHANNELS=[["Voice",34],["eComm single-dealer",30],["Multi-dealer platform",18],["API / Algo",12],["Internal booking",6]];
const VENUES=["OTC bilateral","SEF / MTF","Exchange (SGX)","Exchange (CME)","Exchange (HKEX)","Interdealer broker","Internal"];

const PRODUCTS=[
  {p:"FX Spot",             ac:"FX Cash",                   fam:"fx",    med:14, sig:1.10, tenors:["T+2"]},
  {p:"FX Forward",          ac:"FX Cash",                   fam:"fx",    med:11, sig:1.05, tenors:["1M","3M","6M","1Y"]},
  {p:"FX Swap",             ac:"FX Cash",                   fam:"fx",    med:22, sig:1.00, tenors:["1W","1M","3M","6M"]},
  {p:"NDF",                 ac:"FX Cash",                   fam:"ndf",   med:8,  sig:1.05, tenors:["1M","3M","6M","1Y"]},
  {p:"FX Vanilla Option",   ac:"FX Options",                fam:"fxopt", med:9,  sig:1.10, tenors:["1M","3M","6M","1Y"]},
  {p:"FX Barrier Option",   ac:"FX Options",                fam:"fxopt", med:7,  sig:1.15, tenors:["3M","6M","1Y"]},
  {p:"FX Digital Option",   ac:"FX Options",                fam:"fxopt", med:5,  sig:1.10, tenors:["1M","3M","6M"]},
  {p:"FX Accumulator",      ac:"FX Derivatives",            fam:"fxopt", med:6,  sig:1.05, tenors:["6M","1Y"]},
  {p:"FX Variance Swap",    ac:"FX Derivatives",            fam:"fxopt", med:4,  sig:1.00, tenors:["3M","6M","1Y"]},
  {p:"FX Futures",          ac:"FX Futures",                fam:"fx",    med:6,  sig:0.95, tenors:["Front month","Back month","Quarterly"]},
  {p:"IRS",                 ac:"Interest Rate Derivatives", fam:"rate",  med:28, sig:1.05, tenors:["2Y","5Y","10Y","30Y"]},
  {p:"OIS",                 ac:"Interest Rate Derivatives", fam:"rate",  med:34, sig:1.00, tenors:["1M","3M","1Y","2Y"]},
  {p:"FRA",                 ac:"Interest Rate Derivatives", fam:"rate",  med:40, sig:0.90, tenors:["3x6","6x9","9x12"]},
  {p:"Swaption",            ac:"Interest Rate Derivatives", fam:"rate",  med:18, sig:1.05, tenors:["1Y into 5Y","2Y into 10Y","5Y into 5Y"]},
  {p:"Cap/Floor",           ac:"Interest Rate Derivatives", fam:"rate",  med:15, sig:1.00, tenors:["2Y","5Y","10Y"]},
  {p:"Inflation Swap",      ac:"Interest Rate Derivatives", fam:"rate",  med:12, sig:1.00, tenors:["5Y","10Y","20Y"]},
  {p:"CCS",                 ac:"Interest Rate Derivatives", fam:"rate",  med:16, sig:1.05, tenors:["3Y","5Y","10Y"]},
  {p:"Cross-Ccy Basis Swap",ac:"Interest Rate Derivatives", fam:"rate",  med:20, sig:1.00, tenors:["1Y","3Y","5Y"]},
  {p:"Govt Bond",           ac:"Bonds",                     fam:"bondg", med:19, sig:1.05, tenors:["2Y","5Y","10Y","30Y"]},
  {p:"Corp Bond",           ac:"Bonds",                     fam:"bondc", med:7,  sig:1.10, tenors:["3Y","5Y","7Y","10Y"]},
  {p:"Bond Forward",        ac:"Bonds",                     fam:"bondg", med:12, sig:1.00, tenors:["1M","3M"]},
  {p:"Repo",                ac:"Repo",                      fam:"repo",  med:75, sig:0.85, tenors:["O/N","1W","1M","3M"]},
  {p:"Reverse Repo",        ac:"Repo",                      fam:"repo",  med:68, sig:0.85, tenors:["O/N","1W","1M","3M"]},
  {p:"Equity Option",       ac:"Equity Derivatives",        fam:"eqopt", med:5,  sig:1.10, tenors:["1M","3M","6M","1Y"]},
  {p:"Equity Swap",         ac:"Equity Derivatives",        fam:"eq",    med:11, sig:1.05, tenors:["3M","6M","1Y"]},
  {p:"Variance Swap",       ac:"Equity Derivatives",        fam:"eqopt", med:4,  sig:1.00, tenors:["3M","6M","1Y"]},
  {p:"Equity Index Future", ac:"Equity Derivatives",        fam:"eq",    med:8,  sig:0.95, tenors:["Front month","Quarterly"]},
  {p:"CDS Single Name",     ac:"Credit Derivatives",        fam:"cds",   med:10, sig:1.00, tenors:["3Y","5Y","10Y"]},
  {p:"CDS Index",           ac:"Credit Derivatives",        fam:"cdsi",  med:25, sig:0.95, tenors:["5Y","10Y"]},
  {p:"Total Return Swap",   ac:"Credit Derivatives",        fam:"trs",   med:14, sig:1.00, tenors:["1Y","3Y","5Y"]},
];
const PROD_BY_NAME={}; PRODUCTS.forEach(p=>PROD_BY_NAME[p.p]=p);
/* The longest maturity each product is actually written to. A 25-year FX
   forward and a 40-year equity swap are not long-dated trades, they are data
   errors — so only the products below can carry a tenor-cap breach. */
const MAX_YEARS={"IRS":50,"CCS":30,"Cross-Ccy Basis Swap":30,"Inflation Swap":50,
  "Cap/Floor":30,"Govt Bond":50,"Corp Bond":30,"CDS Single Name":10,"Total Return Swap":10};
/* Every tenor convention on the book reduced to years, so a swap, a bill, a
   swaption and an FRA can sit in the same bucket. A swaption's risk is its
   underlying, not the option leg, and an FRA's is the far date. */
function tenorYears(t){
  if(!t) return 0.25;
  if(/^O\/N|^T\+/i.test(t)) return 0.004;
  const into=t.match(/into\s+(\d+)\s*Y/i);      if(into) return +into[1];
  const fra=t.match(/^(\d+)x(\d+)$/);            if(fra)  return +fra[2]/12;
  const w=t.match(/^(\d+)\s*W$/i);               if(w)    return +w[1]/52;
  const m=t.match(/^(\d+)\s*M$/);                if(m)    return +m[1]/12;
  const y=t.match(/^(\d+)\s*Y$/i);               if(y)    return +y[1];
  if(/month|quarter/i.test(t)) return 0.25;
  return 0.25;
}
const TENOR_BANDS=[
  {label:"≤ 1 month",   max:1/12,     color:"var(--pass)"},
  {label:"1–12 months", max:1,        color:"var(--agent)"},
  {label:"1–5 years",   max:5,        color:"var(--warn)"},
  {label:"5 years +",   max:Infinity, color:"var(--fail)"},
];
function tenorBandOf(t){
  const y=tenorYears(t);
  for(let i=0;i<TENOR_BANDS.length;i++) if(y<=TENOR_BANDS[i].max) return TENOR_BANDS[i].label;
  return TENOR_BANDS[TENOR_BANDS.length-1].label;
}
const BAND_MID={"≤ 1 month":0.04,"1–12 months":0.5,"1–5 years":3,"5 years +":12};
/* Ticket-size bands. Defined once so the distribution chart and the highlight
   dimension cannot disagree about where a $25m deal belongs. */
const SIZE_BANDS=[[0,1,"< $1m"],[1,5,"$1–5m"],[5,10,"$5–10m"],[10,25,"$10–25m"],[25,50,"$25–50m"],
  [50,100,"$50–100m"],[100,250,"$100–250m"],[250,500,"$250–500m"],[500,Infinity,"$500m +"]];
function sizeBandOf(n){
  for(let i=0;i<SIZE_BANDS.length;i++) if(n>=SIZE_BANDS[i][0]&&n<SIZE_BANDS[i][1]) return SIZE_BANDS[i][2];
  return SIZE_BANDS[SIZE_BANDS.length-1][2];
}

/* Products whose price comes out of a model rather than off a screen. Only
   these can carry a day-one P&L argument; a spot deal is marked within seconds. */
const MODELLED=["FX Barrier Option","FX Digital Option","FX Accumulator","FX Variance Swap",
  "Swaption","Cap/Floor","Inflation Swap","Cross-Ccy Basis Swap","Variance Swap","Equity Swap","Total Return Swap"];
const ASSET_CLASSES=[];
PRODUCTS.forEach(p=>{ if(ASSET_CLASSES.indexOf(p.ac)<0) ASSET_CLASSES.push(p.ac); });
const AC_COLOR={
  "FX Cash":"var(--agent)","FX Options":"var(--run)","FX Derivatives":"var(--cyan)","FX Futures":"var(--violet)",
  "Interest Rate Derivatives":"var(--gold)","Bonds":"var(--pink)","Repo":"var(--ink-3)",
  "Equity Derivatives":"var(--pass)","Credit Derivatives":"var(--fail)"};
const PRODUCTS_BY_AC={}; ASSET_CLASSES.forEach(ac=>PRODUCTS_BY_AC[ac]=PRODUCTS.filter(p=>p.ac===ac).map(p=>p.p));
