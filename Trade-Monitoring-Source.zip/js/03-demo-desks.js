/* ============================================================
   Trader groups ("desks") and traders
   A desk is an organisational grouping of traders and the reporting line they
   sit under — it is not a unit of detection. Surveillance runs on the
   individual: a $4m ticket that disappears into a desk's pooled turnover is
   still four times a junior trader's own daily average, and only the second
   reading finds anything. The desk mandate below is the union of what its
   members are signed off for; each trader carries their own narrower list.
============================================================ */
const DESKS=[
  {id:"D1", name:"G10 FX Spot & Forwards", region:"Singapore", short:"G10 FX", dpt:4.0,
   mandate:["FX Spot","FX Forward","FX Swap"]},
  {id:"D2", name:"Asia EM FX & NDF", region:"Singapore", short:"EM FX/NDF", dpt:4.3,
   mandate:["NDF","FX Spot","FX Forward","FX Swap"]},
  {id:"D3", name:"FX Options & Exotics", region:"Hong Kong", short:"FX Options", dpt:3.7,
   mandate:["FX Vanilla Option","FX Barrier Option","FX Digital Option","FX Accumulator","FX Variance Swap"]},
  {id:"D4", name:"FX Futures & Algo Execution", region:"London", short:"FX Futures", dpt:4.0,
   mandate:["FX Futures","FX Spot","FX Swap"]},
  {id:"D5", name:"G10 Rates Swaps", region:"London", short:"G10 Rates", dpt:3.3,
   mandate:["IRS","OIS","Swaption","FRA"]},
  {id:"D6", name:"Asia Rates & Cross-Currency", region:"Singapore", short:"Asia Rates/CCS", dpt:3.0,
   mandate:["IRS","CCS","Cross-Ccy Basis Swap","OIS"]},
  {id:"D7", name:"Inflation & Structured Rates", region:"London", short:"Structured Rates", dpt:2.5,
   mandate:["Inflation Swap","Swaption","Cap/Floor","IRS"]},
  {id:"D8", name:"Credit & Bond Trading", region:"Singapore", short:"Credit Bonds", dpt:3.0,
   mandate:["Govt Bond","Corp Bond","Bond Forward"]},
  {id:"D9", name:"Credit Derivatives", region:"London", short:"Credit Derivs", dpt:3.0,
   mandate:["CDS Single Name","CDS Index","Total Return Swap"]},
  {id:"D10",name:"Bonds Repo & Financing", region:"Singapore", short:"Repo/Financing", dpt:2.7,
   mandate:["Repo","Reverse Repo","Govt Bond","Bond Forward"]},
  {id:"D11",name:"Equity Derivatives", region:"Hong Kong", short:"Equity Derivs", dpt:2.7,
   mandate:["Equity Option","Equity Index Future","Equity Swap","Variance Swap"]},
  {id:"D12",name:"Structured Products", region:"Singapore", short:"Structured", dpt:2.0,
   mandate:["FX Accumulator","FX Digital Option","Equity Swap","Cap/Floor"]},
];
const DESK_BY_ID={}; DESKS.forEach(d=>DESK_BY_ID[d.id]=d);

/* risk drives how often a trader is picked as the subject of a planted pattern;
   `arc` names the typology storyline, so the same trader keeps surfacing under
   related rules rather than scattering unconnected noise across the floor. */
const TRADERS=[
  ["T01","Adrian Koh","D1","Senior",0.10,null],
  ["T02","Nadia Farrell","D1","Executive Director",0.06,null],
  ["T03","Wesley Tan","D1","Associate",0.14,null],
  ["T04","Ingrid Halvorsen","D1","Senior",0.08,null],
  ["T05","Rohan Mistry","D2","Senior",0.95,"After-hours booking & loss parking"],
  ["T06","Clara Devereux","D2","Executive Director",0.09,null],
  ["T07","Bayu Santoso","D2","Associate",0.18,null],
  ["T08","Marcus Vellacourt","D3","Executive Director",1.00,"Loss concealment via mis-marking"],
  ["T09","Yuki Tanabe","D3","Senior",0.10,null],
  ["T10","Serena Alcantara","D3","Associate",0.16,null],
  ["T11","Callum Brightwater","D4","Senior",0.92,"Benchmark / fixing manipulation"],
  ["T12","Elena Marchetti","D4","Associate",0.11,null],
  ["T13","Dominic Ashworth","D5","Executive Director",0.07,null],
  ["T14","Fiona Brennan","D5","Senior",0.12,null],
  ["T15","Tomas Novak","D5","Associate",0.20,null],
  ["T16","Vikram Sethi","D6","Senior",0.13,null],
  ["T17","Amelia Cheng","D6","Executive Director",0.06,null],
  ["T18","Hiroshi Nakada","D6","Associate",0.15,null],
  ["T19","Beatrice Nolan","D7","Senior",0.09,null],
  ["T20","Oscar Lindqvist","D7","Associate",0.22,null],
  ["T21","Ravi Iyengar","D8","Senior",0.11,null],
  ["T22","Josephine Lau","D8","Executive Director",0.08,null],
  ["T23","Dmitri Volkov","D8","Senior",0.90,"Information misuse ahead of announcements"],
  ["T24","Sebastian Crowe","D9","Executive Director",0.10,null],
  ["T25","Hannah Weiss","D9","Senior",0.24,null],
  ["T26","Gerald Ong","D10","Executive Director",0.88,"Reporting-date balance-sheet dressing"],
  ["T27","Meera Kapoor","D10","Senior",0.09,null],
  ["T28","Anton Reyes","D10","Associate",0.17,null],
  ["T29","Felicity Zhang","D11","Senior",0.86,"Wash trading & inter-book transfers"],
  ["T30","Julien Marchand","D11","Executive Director",0.07,null],
  ["T31","Kwame Osei","D11","Associate",0.19,null],
  ["T32","Isabel Ferreira","D12","Senior",0.12,null],
  ["T33","Nathan Quek","D12","Associate",0.26,null],
  ["T34","Priya Raghunathan","D1","Senior",0.11,null],
  ["T35","Lucas Bergstrom","D1","Associate",0.19,null],
  ["T36","Mei-Ling Chua","D1","Senior",0.09,null],
  ["T37","Aaron Whitfield","D1","Executive Director",0.07,null],
  ["T38","Siti Rahmah","D1","Associate",0.21,null],
  ["T39","Gustavo Pereira","D1","Senior",0.13,null],
  ["T40","Arjun Balakrishnan","D2","Senior",0.12,null],
  ["T41","Ha-eun Seo","D2","Associate",0.18,null],
  ["T42","Nurul Aziz","D2","Senior",0.10,null],
  ["T43","Terrence Fong","D2","Executive Director",0.08,null],
  ["T44","Lakshmi Venkatesan","D2","Associate",0.23,null],
  ["T45","Ophelia Sandoval","D3","Senior",0.84,"Volatility mis-marking into expiries"],
  ["T46","Daniyar Kassymov","D3","Associate",0.17,null],
  ["T47","Charlotte Vane","D3","Senior",0.11,null],
  ["T48","Renzo Battaglia","D3","Executive Director",0.09,null],
  ["T49","Imogen Trask","D4","Senior",0.14,null],
  ["T50","Ade Okonkwo","D4","Associate",0.20,null],
  ["T51","Henrik Lindholm","D4","Executive Director",0.08,null],
  ["T52","Rosalind Ayers","D5","Senior",0.10,null],
  ["T53","Piotr Zielinski","D5","Associate",0.22,null],
  ["T54","Malcolm Ferris","D5","Senior",0.12,null],
  ["T55","Kenji Watanabe","D6","Senior",0.11,null],
  ["T56","Sunitha Menon","D6","Associate",0.19,null],
  ["T57","Bernard Chiam","D6","Executive Director",0.07,null],
  ["T58","Delphine Rousseau","D7","Senior",0.82,"Day-one profit on structured trades"],
  ["T59","Emeka Adeyemi","D8","Senior",0.13,null],
  ["T60","Ingeborg Haas","D8","Associate",0.18,null],
  ["T61","Rafael Duarte","D8","Senior",0.10,null],
  ["T62","Cassandra Nkemelu","D9","Executive Director",0.09,null],
  ["T63","Tobias Grandin","D9","Associate",0.25,null],
  ["T64","Wei-Jian Lo","D10","Senior",0.12,null],
  ["T65","Aisha Karimova","D10","Associate",0.16,null],
  ["T66","Etienne Rocheford","D11","Senior",0.80,"Cross-book risk transfer at stale marks"],
  ["T67","Grace Tumelo","D11","Associate",0.21,null],
  ["T68","Viktor Marchenko","D12","Senior",0.14,null],
].map(a=>({id:a[0],name:a[1],deskId:a[2],grade:a[3],risk:a[4],arc:a[5],book:a[2]+"-BK"+a[0].slice(1),leave:null}));
const TRADER_BY_ID={}; TRADERS.forEach(t=>TRADER_BY_ID[t.id]=t);
DESKS.forEach(d=>d.traders=TRADERS.filter(t=>t.deskId===d.id));

/* Mandatory block-leave windows (dayIdx inclusive) — two weeks each, staggered
   across the year. Trading inside your own block leave is a control breach on
   its own, which is why the window is modelled rather than assumed. */
TRADERS.forEach((t,i)=>{
  const start=30+Math.round((i*(DAYS-90))/TRADERS.length)+randInt(-4,4);
  t.leave=[start,start+13];
});

