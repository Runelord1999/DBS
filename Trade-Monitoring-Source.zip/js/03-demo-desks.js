/* ============================================================
   Trader groups ("desks") and traders
   A desk is an organisational grouping of traders and the reporting line they
   sit under — it is not a unit of detection. Surveillance runs on the
   individual: a $4m ticket that disappears into a desk's pooled turnover is
   still four times a junior trader's own daily average, and only the second
   reading finds anything. The desk mandate below is the union of what its
   members are signed off for; each trader carries their own narrower list.
============================================================ */
const DESKS=[
  {id:"D1", name:"G10 FX Spot & Forwards", region:"Singapore", short:"G10 FX", dpt:4.0,
   mandate:["FX Spot","FX Forward","FX Swap"]},
  {id:"D2", name:"Asia EM FX & NDF", region:"Singapore", short:"EM FX/NDF", dpt:4.3,
   mandate:["NDF","FX Spot","FX Forward","FX Swap"]},
  {id:"D3", name:"FX Options & Exotics", region:"Hong Kong", short:"FX Options", dpt:3.7,
   mandate:["FX Vanilla Option","FX Barrier Option","FX Digital Option","FX Accumulator","FX Variance Swap"]},
  {id:"D4", name:"FX Futures & Algo Execution", region:"London", short:"FX Futures", dpt:4.0,
   mandate:["FX Futures","FX Spot","FX Swap"]},
  {id:"D5", name:"G10 Rates Swaps", region:"London", short:"G10 Rates", dpt:3.3,
   mandate:["IRS","OIS","Swaption","FRA"]},
  {id:"D6", name:"Asia Rates & Cross-Currency", region:"Singapore", short:"Asia Rates/CCS", dpt:3.0,
   mandate:["IRS","CCS","Cross-Ccy Basis Swap","OIS"]},
  {id:"D7", name:"Inflation & Structured Rates", region:"London", short:"Structured Rates", dpt:2.5,
   mandate:["Inflation Swap","Swaption","Cap/Floor","IRS"]},
  {id:"D8", name:"Credit & Bond Trading", region:"Singapore", short:"Credit Bonds", dpt:3.0,
   mandate:["Govt Bond","Corp Bond","Bond Forward"]},
  {id:"D9", name:"Credit Derivatives", region:"London", short:"Credit Derivs", dpt:3.0,
   mandate:["CDS Single Name","CDS Index","Total Return Swap"]},
  {id:"D10",name:"Bonds Repo & Financing", region:"Singapore", short:"Repo/Financing", dpt:2.7,
   mandate:["Repo","Reverse Repo","Govt Bond","Bond Forward"]},
  {id:"D11",name:"Equity Derivatives", region:"Hong Kong", short:"Equity Derivs", dpt:2.7,
   mandate:["Equity Option","Equity Index Future","Equity Swap","Variance Swap"]},
  {id:"D12",name:"Structured Products", region:"Singapore", short:"Structured", dpt:2.0,
   mandate:["FX Accumulator","FX Digital Option","Equity Swap","Cap/Floor"]},
];
const DESK_BY_ID={}; DESKS.forEach(d=>DESK_BY_ID[d.id]=d);

/* risk drives how often a trader is picked as the subject of a planted pattern;
   `arc` names the typology storyline, so the same trader keeps surfacing under
   related rules rather than scattering unconnected noise across the floor. */
const TRADERS=[
  ["T01","Takeshi Kobayashi","D1","Senior",0.10,null],
  ["T02","Naomi Fujiwara","D1","Executive Director",0.06,null],
  ["T03","Daichi Hayashi","D1","Associate",0.14,null],
  ["T04","Haruka Ishikawa","D1","Senior",0.08,null],
  ["T05","Ryota Matsumoto","D2","Senior",0.95,"After-hours booking & loss parking"],
  ["T06","Ayaka Morita","D2","Executive Director",0.09,null],
  ["T07","Yusuke Saito","D2","Associate",0.18,null],
  ["T08","Masahiro Kudo","D3","Executive Director",1.00,"Loss concealment via mis-marking"],
  ["T09","Yuki Tanabe","D3","Senior",0.10,null],
  ["T10","Sakura Aoki","D3","Associate",0.16,null],
  ["T11","Kenta Shimizu","D4","Senior",0.92,"Benchmark / fixing manipulation"],
  ["T12","Emi Maeda","D4","Associate",0.11,null],
  ["T13","Daisuke Ogawa","D5","Executive Director",0.07,null],
  ["T14","Fumiko Nishimura","D5","Senior",0.12,null],
  ["T15","Tomoya Nakamura","D5","Associate",0.20,null],
  ["T16","Hayato Sugiyama","D6","Senior",0.13,null],
  ["T17","Asuka Kondo","D6","Executive Director",0.06,null],
  ["T18","Hiroshi Nakada","D6","Associate",0.15,null],
  ["T19","Misaki Noguchi","D7","Senior",0.09,null],
  ["T20","Osamu Ikeda","D7","Associate",0.22,null],
  ["T21","Ryo Inoue","D8","Senior",0.11,null],
  ["T22","Junko Yamada","D8","Executive Director",0.08,null],
  ["T23","Kazuki Okada","D8","Senior",0.90,"Information misuse ahead of announcements"],
  ["T24","Shinji Hasegawa","D9","Executive Director",0.10,null],
  ["T25","Hana Yoshida","D9","Senior",0.24,null],
  ["T26","Makoto Ono","D10","Executive Director",0.88,"Reporting-date balance-sheet dressing"],
  ["T27","Mai Kato","D10","Senior",0.09,null],
  ["T28","Akira Endo","D10","Associate",0.17,null],
  ["T29","Rina Takahashi","D11","Senior",0.86,"Wash trading & inter-book transfers"],
  ["T30","Jun Murakami","D11","Executive Director",0.07,null],
  ["T31","Koji Ota","D11","Associate",0.19,null],
  ["T32","Izumi Fukuda","D12","Senior",0.12,null],
  ["T33","Naoki Kubo","D12","Associate",0.26,null],
  ["T34","Yui Hirano","D1","Senior",0.11,null],
  ["T35","Takuya Mizuno","D1","Associate",0.19,null],
  ["T36","Mei Kikuchi","D1","Senior",0.09,null],
  ["T37","Atsushi Sakai","D1","Executive Director",0.07,null],
  ["T38","Saki Imai","D1","Associate",0.21,null],
  ["T39","Kaito Hirose","D1","Senior",0.13,null],
  ["T40","Haruto Yamaguchi","D2","Senior",0.12,null],
  ["T41","Hinata Sato","D2","Associate",0.18,null],
  ["T42","Nanami Arai","D2","Senior",0.10,null],
  ["T43","Tetsuya Fujita","D2","Executive Director",0.08,null],
  ["T44","Riko Uchida","D2","Associate",0.23,null],
  ["T45","Yoko Sasaki","D3","Senior",0.84,"Volatility mis-marking into expiries"],
  ["T46","Daiki Kawasaki","D3","Associate",0.17,null],
  ["T47","Chihiro Yano","D3","Senior",0.11,null],
  ["T48","Ren Takeda","D3","Executive Director",0.09,null],
  ["T49","Kaori Tsuchiya","D4","Senior",0.14,null],
  ["T50","Akio Okamoto","D4","Associate",0.20,null],
  ["T51","Hideki Nomura","D4","Executive Director",0.08,null],
  ["T52","Reiko Aizawa","D5","Senior",0.10,null],
  ["T53","Shun Iwasaki","D5","Associate",0.22,null],
  ["T54","Masato Fujii","D5","Senior",0.12,null],
  ["T55","Kenji Watanabe","D6","Senior",0.11,null],
  ["T56","Sayaka Miura","D6","Associate",0.19,null],
  ["T57","Kenichi Hara","D6","Executive Director",0.07,null],
  ["T58","Eriko Matsuda","D7","Senior",0.82,"Day-one profit on structured trades"],
  ["T59","Yuto Kimura","D8","Senior",0.13,null],
  ["T60","Asami Hattori","D8","Associate",0.18,null],
  ["T61","Ryuji Doi","D8","Senior",0.10,null],
  ["T62","Kana Nakajima","D9","Executive Director",0.09,null],
  ["T63","Tatsuya Goto","D9","Associate",0.25,null],
  ["T64","Wataru Nagai","D10","Senior",0.12,null],
  ["T65","Aya Kaneko","D10","Associate",0.16,null],
  ["T66","Eiji Kawaguchi","D11","Senior",0.80,"Cross-book risk transfer at stale marks"],
  ["T67","Megumi Tsuda","D11","Associate",0.21,null],
  ["T68","Kosuke Ueno","D12","Senior",0.14,null],
].map(a=>({id:a[0],name:a[1],deskId:a[2],grade:a[3],risk:a[4],arc:a[5],book:a[2]+"-BK"+a[0].slice(1),leave:null}));
const TRADER_BY_ID={}; TRADERS.forEach(t=>TRADER_BY_ID[t.id]=t);
DESKS.forEach(d=>d.traders=TRADERS.filter(t=>t.deskId===d.id));

/* Mandatory block-leave windows (dayIdx inclusive) — two weeks each, staggered
   across the year. Trading inside your own block leave is a control breach on
   its own, which is why the window is modelled rather than assumed. */
TRADERS.forEach((t,i)=>{
  const start=30+Math.round((i*(DAYS-90))/TRADERS.length)+randInt(-4,4);
  t.leave=[start,start+13];
});

