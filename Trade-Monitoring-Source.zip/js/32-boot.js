/* ============================================================
   Boot
============================================================ */
state.blot.from=isoDate(dateAt(29));
state.blot.to=isoDate(TODAY);
render();
window.__tmReady=true;