/* ============================================================
   State + filtering
============================================================ */
const state={
  tab:"overview", dateRangeDays:30,
  // The trader filter is the primary scope: detection is per person, and the
  // group filter only widens that to everyone sharing a reporting line.
  filters:{trader:new Set(),desk:new Set(),assetClass:new Set(),severity:new Set()},
  // The queue opens on unworked items: the daily job is the open list, and
  // history is something you drill into from the overview, not the default view.
  det:{rule:"",status:"",cat:"",trader:"",search:"",sort:{key:"day",dir:-1},page:0,per:25,openOnly:true},
  blot:{ac:"",product:"",desk:"",trader:"",dir:"",ctpy:"",flagged:false,search:"",from:"",to:"",
        sort:{key:"seq",dir:-1},page:0,per:50},
  rules:{cat:"",sort:{key:"hits",dir:-1}},
  act:{year:TODAY.getFullYear(),unit:"week",range:"",cols:0,
       metric:storedMeasure()==="pnl"?"pnl":"count",scale:"own",yoy:false},
  // enc holds at most one of trader/desk, enforced where it is toggled.
  // px is pixels per day and runs continuously from months down to seconds.
  // Only trader has a chart-level picker; desk and asset class come from the rail.
  ts:{enc:["ac"],n:3,unit:"month",y:"notional",px:16,h:470,pick:{trader:[]},case:""},
  heat:{rows:"rule",cols:"trader",top:18,density:"comfortable"},
  highlight:true,
  /* Which quantity the Trade Activity panels are drawn in. "txn" counts deals
     and measures them in notional; "pnl" draws the same cuts in revenue. */
  measure:storedMeasure(),
  trad:{sort:{key:"idx",dir:-1},view:"cards"},
  log:{who:"me",status:"",search:"",sort:{key:"reviewDay",dir:-1},page:0,per:25},
  ovMonthSel:null,
};
const MSEL_OPTS={
  trader:TRADERS.slice().sort((a,b)=>a.name.localeCompare(b.name)).map(t=>t.id),
  desk:DESKS.map(d=>d.id), assetClass:ASSET_CLASSES.slice(), severity:SEV_ORDER.slice(),
};
const MSEL_LABEL={trader:id=>TRADER_BY_ID[id].name+" · "+DESK_BY_ID[TRADER_BY_ID[id].deskId].short,
  desk:id=>DESK_BY_ID[id].name, assetClass:v=>v, severity:v=>v};
const MSEL_TITLE={trader:"traders",desk:"desks",assetClass:"asset classes",severity:"severities"};

function alertInRange(a){ return a.day>=DAYS-state.dateRangeDays; }
function matchRail(a){
  const f=state.filters;
  if(f.trader.size&&!f.trader.has(a.traderId)) return false;
  if(f.desk.size&&!f.desk.has(a.deskId)) return false;
  if(f.severity.size&&!f.severity.has(a.sev)) return false;
  if(f.assetClass.size&&!a.acs.some(x=>f.assetClass.has(x))) return false;
  return true;
}
/* Works for a TRADERS entry or a TRADER_STATS row — both carry id and deskId. */
const traderInRail=t=>(!state.filters.trader.size||state.filters.trader.has(t.id))&&
                      (!state.filters.desk.size||state.filters.desk.has(t.deskId));
function railActive(){ return state.filters.trader.size||state.filters.desk.size||state.filters.assetClass.size||state.filters.severity.size; }
// The rail scopes every view; the period scopes the alert views only, so the
// blotter keeps its own explicit from/to dates.
const scopedAlerts=()=>ALERTS.filter(a=>alertInRange(a)&&matchRail(a));
const allScopedAlerts=()=>ALERTS.filter(matchRail);
const isOpen=a=>a.status==="Open"||a.status==="In Review";
const openAlerts=()=>ALERTS.filter(a=>isOpen(a)&&matchRail(a));

function tradeMatchesRail(t){
  const f=state.filters;
  if(f.trader.size&&!f.trader.has(t.traderId)) return false;
  if(f.desk.size&&!f.desk.has(t.deskId)) return false;
  if(f.assetClass.size&&!f.assetClass.has(t.ac)) return false;
  return true;
}

/* Risk index: severity-weighted alerts per 100 of the trader's own deals, so a
   busy name is not flagged for being busy and a quiet one cannot hide inside a
   desk's turnover. The peer multiple restates the same number against the
   cohort median — the comparison a desk head will ask for first.

   Built against the rail rather than once at load. It used to be a single
   all-time, whole-floor figure: filtering to one asset class changed which
   names were listed but never their scores, so the panel answered a question
   nobody had asked. It stays on the full twelve months deliberately — a score
   computed over a week has denominators too small to rank anything — so the
   window is stated on every panel that shows it.

   Recomputed only when the rail actually changes; a pass over 59k deals on
   every render would be paid for on scroll and zoom as well. */
/* A ratio needs a denominator. Scoped to one asset class, a trader with a
   single deal that happened to alert scores 300–400 and buries names with a
   thousand deals and a real pattern — the top of the list becomes an artefact
   of dividing by one. A name has to have booked at least this many deals in
   the current scope before it can be ranked; those below it keep their stats
   and are reported as set aside rather than silently dropped. */
const RANK_MIN_DEALS=25;
const rankable=s=>s.trades>=RANK_MIN_DEALS;
/* The peer multiple compares a trader with the median of their cohort. Scoped
   to a thin asset class the cohort can collapse to the trader alone, and the
   multiple then reads ×1 — a comparison with oneself, dressed as a comparison
   with peers. Below this many rankable peers it is not shown at all. */
const PEER_MIN_COHORT=3;
const peerText=s=>(s.cohortN>=PEER_MIN_COHORT?"\u00d7"+s.peer:"\u2014");
const peerTip=s=>s.cohortN>=PEER_MIN_COHORT
  ? "Versus the median of "+s.cohortN+" cohort peers"
  : "Not shown: only "+s.cohortN+" peer"+(s.cohortN===1?"":"s")+" left in this scope, too few to compare against";
let TRADER_STATS_SIG=null;
function buildTraderStats(){
  const f=state.filters;
  const sig=JSON.stringify([[...f.trader],[...f.desk],[...f.assetClass],[...f.severity]]);
  if(TRADER_STATS_SIG===sig) return;
  TRADER_STATS_SIG=sig;
  Object.values(TRADER_STATS).forEach(s=>{
    s.trades=0; s.notional=0; s.pnl=0; s.alerts=0; s.crit=0; s.susp=0; s.score=0; s.rules={};
  });
  TRADES.forEach(t=>{ if(!tradeMatchesRail(t)) return;
    const s=TRADER_STATS[t.traderId]; s.trades++; s.notional+=t.notional; s.pnl+=t.pnl; });
  ALERTS.forEach(a=>{ if(!matchRail(a)) return;
    const s=TRADER_STATS[a.traderId]; s.alerts++;
    if(a.sev==="Critical") s.crit++;
    if(a.status==="Suspicious"||a.status==="Escalated") s.susp++;
    s.score+=SEV_RANK[a.sev];
    s.rules[a.ruleId]=(s.rules[a.ruleId]||0)+1;
  });
  Object.values(TRADER_STATS).forEach(s=>{
    s.idx=s.trades?+(s.score/s.trades*100).toFixed(1):0;
    s.ruleCount=Object.keys(s.rules).length;
  });
  TRADERS.forEach(t=>{
    /* A cohort peer with no deals left in scope scores zero, and enough of those
       drag the median to the floor and inflate everyone's multiple. Only peers
       still trading inside the rail anchor it. */
    const live=t.peers.filter(x=>rankable(TRADER_STATS[x.id]));
    const base=live.length?live:t.peers.filter(x=>TRADER_STATS[x.id].trades>0);
    const med=Math.max(0.1,median((base.length?base:t.peers).map(x=>TRADER_STATS[x.id].idx)));
    TRADER_STATS[t.id].peer=+(TRADER_STATS[t.id].idx/med).toFixed(1);
    TRADER_STATS[t.id].cohortMedian=med;
    TRADER_STATS[t.id].cohortN=(base.length?base:t.peers).length;
  });
}
buildTraderStats();
