/* ============================================================
   Alert construction
============================================================ */
const ALERTS=[];
/* An actor who could actually run this pattern: a rule about structured
   day-one P&L needs somebody with a structured book, and a rule about repo
   needs somebody in financing. Falling back to whoever came up first is how a
   financing desk ends up booking a barrier option at its repo ticket limit. */
function pickActorWith(rule,ok){
  for(let i=0;i<40;i++){ const t=pickActor(rule); if(ok(t)) return t; }
  const all=TRADERS.filter(ok);
  return all.length?weightedChoice(all.map(t=>[t,0.25+t.risk])):pickActor(rule);
}
function pickActor(rule){
  // Storylines carry most of the weight, so the same handful of traders recur
  // across related rules — that is the pattern an officer is meant to spot.
  if(rule.actors&&rule.actors.length&&rng()<0.58) return TRADER_BY_ID[choice(rule.actors)];
  return weightedChoice(TRADERS.map(t=>[t,0.25+t.risk]));
}
function pickDay(lo,hi){
  lo=lo==null?4:lo; hi=hi==null?DAYS-1:hi;
  for(let i=0;i<60;i++){ const d=randInt(lo,hi); if(isBiz(dateForIdx(d))) return d; }
  return BIZ_DAYS[BIZ_DAYS.length-1];
}
// Recent weeks carry a modest extra share so the live queue is never empty —
// enough for a working morning, not so much that the trend chart shows a cliff.
function pickDayWeighted(){ return rng()<0.06?pickDay(DAYS-45,DAYS-1):pickDay(4,DAYS-1); }
function ensureTrades(trader,day,n,prod){
  const arr=(byTraderDay.get(trader.id+"|"+day)||[]).filter(t=>!prod||t.product===prod);
  const out=shuffle(arr).slice(0,n);
  while(out.length<n) out.push(makeTrade(day,trader,prod||choice(trader.products),{}));
  return out;
}
function mkAlert(rule,day,trader,trades,ev,summary,opts){
  opts=opts||{};
  const date=dateForIdx(day);
  const sev=opts.sev||rule.sev;
  const arcBonus=trader.risk>0.7?7:0;
  const score=Math.max(8,Math.min(99,Math.round(SEV_BASE[sev]+rand(-9,11)+arcBonus+(opts.scoreAdj||0))));
  const notional=trades.reduce((a,t)=>a+t.notional,0);
  // Detection runs on the overnight batch: an alert raised at 06:40 the next
  // business day is what the officer actually finds in the queue each morning.
  const raised=new Date(date.getTime()+dayMs);
  const a={
    id:"", ruleId:rule.id, rule:rule.name, cat:rule.cat, day, date, dateStr:fmtDate(date), iso:isoDate(date),
    raisedStr:fmtDate(raised)+" 06:40",
    traderId:trader.id, trader:trader.name, deskId:trader.deskId, deskShort:DESK_BY_ID[trader.deskId].short,
    deskName:DESK_BY_ID[trader.deskId].name, region:DESK_BY_ID[trader.deskId].region,
    sev, score, notional, tradeIds:trades.map(t=>t.id), acs:[], products:[],
    summary, evidence:ev, why:rule.why,
    status:"Open", reason:"", note:"", reviewer:"", reviewedStr:"", audit:[],
  };
  trades.forEach(t=>{
    if(a.acs.indexOf(t.ac)<0) a.acs.push(t.ac);
    if(a.products.indexOf(t.product)<0) a.products.push(t.product);
    if(t.flags.indexOf(rule.id)<0) t.flags.push(rule.id);
    t.alerts.push(a);
  });
  a.audit.push({ts:a.raisedStr,actor:"Surveillance engine",action:"Alert raised",detail:rule.id+" · score "+a.score+" · "+sev});
  ALERTS.push(a);
  return a;
}
const ev=(k,v,bad)=>({k,v,bad:!!bad});
const fmt2=(v,dp)=>v.toFixed(dp);
const px=t=>t.px.toFixed(t.dp)+(t.unit==="%"?"%":t.unit==="bps"?" bps":t.unit==="% prem"?"%":"");
const mkt=t=>t.mktPx.toFixed(t.dp)+(t.unit==="%"?"%":t.unit==="bps"?" bps":t.unit==="% prem"?"%":"");

/* ------------------------------------------------------------
   The pattern generators, one per rule. Each one builds the trades that embody the
   typology and then raises the alert those trades would trigger — the
   evidence on the alert is read back off the trades, never invented twice.
------------------------------------------------------------ */
const PLANT={};

PLANT["TS-01"]=function(rule){
  const tr=pickActor(rule), day=pickDayWeighted(), b=trBase(tr);
  // Only a cash-priced instrument can be tested this way. An option's value
  // lives in its volatility, which is what TS-15 measures instead.
  const cash=tr.products.filter(x=>FAM_MKT[PROD_BY_NAME[x].fam].omFloor>0);
  const prod=cash.length?choice(cash):"FX Spot";
  const inst=instrumentFor(prod);
  const thr=omThreshold(inst);
  // This rule is partly about size, so the ticket is allowed past the trader's
  // authorisation — and the evidence says so when it is.
  const t=makeTrade(day,tr,prod,{inst,notional:Math.max(0.4,trBase(tr).medSize*rand(3.2,9))});
  applyDev(t,devFor(inst,rand(1.15,7.5)));
  t.pnl=bpValue(t.fam,t.notional,t.devBps);
  if(rng()<0.3){ const rp=choice(Object.keys(RELATED_PARTIES)); t.ctpy=rp; t.ctpyType="Private Client"; }
  const related=RELATED_PARTIES[t.ctpy];
  return mkAlert(rule,day,tr,[t],[
    ev("Product / instrument",t.product+" · "+t.instrument),
    ev("Traded price",px(t),true), ev("Market mid at execution",mkt(t)),
    ev("Deviation",Math.abs(t.devBps).toFixed(1)+" bps ("+(t.devBps>0?"above":"below")+" mid)",true),
    ev("Normal dealing spread in this name",inst.spreadBps.toFixed(2)+" bps — the print is "+(Math.abs(t.devBps)/inst.spreadBps).toFixed(0)+"× it",true),
    ev("Materiality threshold",thr.toFixed(1)+" bps — 8× the spread, floored at "+inst.omFloor+" bps for "+t.ac),
    ev("Notional",fmtM(t.notional),true),
    ev("This trader's median ticket",fmtM(b.medSize)+" — deal is "+xBase(t.notional,b.medSize)+" their own normal size",true),
    ev("This trader's ticket authorisation",fmtM(tr.ticketLimit)+(t.notional>tr.ticketLimit?" — exceeded, "+xBase(t.notional,tr.ticketLimit):" — within authority"),t.notional>tr.ticketLimit),
    ev("Counterparty",t.ctpy+" · "+t.ctpyType),
    ev("Booking P&L effect",fmtK(t.pnl),true),
    ev("Related-party register",related?"MATCH — "+related:"No match",!!related),
  ],"Trade printed "+Math.abs(t.devBps).toFixed(0)+" bps off mid in "+t.instrument+" — "+(Math.abs(t.devBps)/thr).toFixed(1)+"× the materiality threshold for that name, on "+fmtM(t.notional),
  {sev:related?"Critical":Math.abs(t.devBps)>thr*4?"Critical":"High",scoreAdj:related?9:0});
};

PLANT["TS-02"]=function(rule){
  const tr=pickActor(rule), day=pickDayWeighted();
  const t=ensureTrades(tr,day,1)[0], b=trBase(tr);
  t.captureLag=Math.round(rand(180,1900));
  const nextDay=t.execMin+t.captureLag>1440;
  t.status=rng()<0.4?"Amended":t.status;
  const ownLag=rand(2,9);
  return mkAlert(rule,day,tr,[t],[
    ev("Execution timestamp",fmtDateShort(t.date)+" "+fmtTime(t.execMin)+" "+t.region),
    ev("Captured in risk system",(nextDay?"+1 business day ":"")+fmtTime((t.execMin+t.captureLag)%1440),true),
    ev("Capture lag",(t.captureLag/60).toFixed(1)+" hours",true),
    ev("Policy threshold","30 minutes"),
    ev("This trader's median capture lag",ownLag.toFixed(0)+" minutes across "+fmtNum(b.deals)+" deals",true),
    ev("Trade / product",t.id+" · "+t.product+" · "+t.instrument),
    ev("Notional",fmtM(t.notional)),
    ev("Booking channel",t.channel),
    ev("Deal amended after capture",t.status==="Amended"?"Yes — 1 amendment":"No",t.status==="Amended"),
  ],"Execution captured "+(t.captureLag/60).toFixed(1)+"h after the trade was struck"+(nextDay?", crossing into the next business day":""),
  {sev:t.captureLag>720?"High":"Medium"});
};

PLANT["TS-03"]=function(rule){
  const tr=pickActor(rule), day=pickDayWeighted(), b=trBase(tr);
  const ts=ensureTrades(tr,day,randInt(3,5));
  let amends=0, cancels=0;
  ts.forEach((t,i)=>{
    t.amends=randInt(3,7); amends+=t.amends;
    if(i>0&&rng()<0.5){ t.cancelled=true; t.status="Cancelled"; cancels++; }
    else t.status="Amended";
  });
  const sessionRate=amends/ts.length, ownRate=Math.max(0.05,b.amendsPerDeal);
  return mkAlert(rule,day,tr,ts,[
    ev("Deals touched",String(ts.length)),
    ev("Total amendments",String(amends),true),
    ev("Cancel & rebook events",String(cancels),cancels>0),
    ev("Amendments per deal this session",sessionRate.toFixed(1),true),
    ev("This trader's own 12-month rate",ownRate.toFixed(2)+" per deal — session runs at "+xBase(sessionRate,ownRate),true),
    ev("Peer cohort ("+tr.cohort+")",Math.max(0.03,b.cohort.amendsPerDeal).toFixed(2)+" per deal"),
    ev("Rule threshold","3 amendments on one deal, or 4× the trader's own rate"),
    ev("Largest amended ticket",fmtM(Math.max.apply(null,ts.map(t=>t.notional)))),
    ev("Amended after value date",rng()<0.4?"Yes — 1 deal":"No",rng()<0.4),
  ],plural(amends,"amendment")+" and "+plural(cancels,"cancellation")+" in one session — "+xBase(sessionRate,ownRate)+" this trader's own rate",
  {sev:amends>18?"High":"Medium"});
};

PLANT["TS-04"]=function(rule){
  const tr=pickActor(rule), day=pickDayWeighted();
  const desk=DESK_BY_ID[tr.deskId], prod=choice(tr.products), inst=instrumentFor(prod);
  const notional=sizeFor(tr,1.4,6.5), ctpy=rng()<0.35?{name:choice(Object.keys(RELATED_PARTIES)),type:"Private Client",country:"Singapore"}:choice(COUNTERPARTIES);
  const m1=execMinFor(desk), gap=randInt(3,52);
  const L=longDir(prod);
  const a=makeTrade(day,tr,prod,{inst,notional,dir:L,ctpy,execMin:m1,pnl:bpValue(PROD_BY_NAME[prod].fam,notional,rand(4,11))});
  const b=makeTrade(day,tr,prod,{inst,notional:notional*rand(0.995,1.005),dir:oppDir(L),ctpy,execMin:m1+gap,pnl:0});
  b.pnl=+(-a.pnl+rand(-1.5,1.5)).toFixed(1);
  const net=+(a.pnl+b.pnl).toFixed(1);
  return mkAlert(rule,day,tr,[a,b],[
    ev("Instrument",prod+" · "+inst.name),
    ev("Leg 1",a.dir+" "+fmtM(a.notional)+" @ "+px(a)+" · "+fmtTime(a.execMin)),
    ev("Leg 2",b.dir+" "+fmtM(b.notional)+" @ "+px(b)+" · "+fmtTime(b.execMin),true),
    ev("Time between legs",gap+" minutes",true),
    ev("Notional match",(100-Math.abs(a.notional-b.notional)/a.notional*100).toFixed(2)+"%",true),
    ev("Counterparty (both legs)",ctpy.name+" · "+ctpy.type,true),
    ev("Net risk after pair","Nil — position unchanged",true),
    ev("Net P&L",fmtK(net)),
    ev("Related-party register",RELATED_PARTIES[ctpy.name]?"MATCH — "+RELATED_PARTIES[ctpy.name]:"No match",!!RELATED_PARTIES[ctpy.name]),
  ],"Equal and opposite "+prod+" pair with "+ctpy.name+" "+gap+" minutes apart, no net risk",
  {sev:RELATED_PARTIES[ctpy.name]?"Critical":"High"});
};

PLANT["TS-05"]=function(rule){
  const tr=pickActor(rule), day=pickDay(4,DAYS-8);
  const desk=DESK_BY_ID[tr.deskId], prod=choice(tr.products), inst=instrumentFor(prod);
  const notional=sizeFor(tr,2.2,7.5), hops=randInt(3,4), legs=[];
  const parties=shuffle(COUNTERPARTIES.filter(c=>c.type==="Broker"||c.type==="Bank")).slice(0,hops);
  for(let i=0;i<hops;i++){
    const d=Math.min(DAYS-1,day+i*randInt(1,2));
    legs.push(makeTrade(isBiz(dateForIdx(d))?d:day,tr,prod,{inst,notional:notional*rand(0.985,1.015),
      dir:i%2===0?shortDir(prod):longDir(prod),ctpy:parties[i%parties.length]}));
  }
  const span=Math.max(1,BIZ_DAYS.indexOf(legs[legs.length-1].dayIdx)-BIZ_DAYS.indexOf(legs[0].dayIdx));
  return mkAlert(rule,day,tr,legs,[
    ev("Instrument",prod+" · "+inst.name),
    ev("Chain length",hops+" legs",true),
    ev("Counterparty chain",parties.map(p=>p.name).join(" → "),true),
    ev("Notional spread across legs",fmtM(Math.min.apply(null,legs.map(l=>l.notional)))+" – "+fmtM(Math.max.apply(null,legs.map(l=>l.notional)))),
    ev("Size match across chain",(100-(Math.max.apply(null,legs.map(l=>l.notional))-Math.min.apply(null,legs.map(l=>l.notional)))/notional*100).toFixed(1)+"%",true),
    ev("Chain closed in",span+" business days",true),
    ev("Net position change","Nil",true),
    ev("Aggregate fees paid away",fmtK(rand(45,260))),
  ],hops+"-leg round trip in "+inst.name+" closing within "+plural(span,"business day")+" and no net position change");
};

PLANT["TS-06"]=function(rule){
  const tr=pickActor(rule), day=pickDayWeighted();
  const desk=DESK_BY_ID[tr.deskId], prod=choice(tr.products), inst=instrumentFor(prod);
  const L=tr.ticketLimit;
  const n=randInt(3,6), t0=execMinFor(desk), ctpy=choice(INST_CTPY), ts=[];
  for(let i=0;i<n;i++) ts.push(makeTrade(day,tr,prod,{inst,notional:L*rand(0.902,0.995),dir:longDir(prod),ctpy,execMin:t0+i*randInt(2,10)}));
  const tot=ts.reduce((a,t)=>a+t.notional,0);
  return mkAlert(rule,day,tr,ts,[
    ev("Instrument",prod+" · "+inst.name),
    ev("Tickets booked",String(n),true),
    ev("Individual sizes",ts.map(t=>"$"+t.notional.toFixed(1)+"m").join(", "),true),
    ev("This trader's ticket authorisation",fmtM(L)+" per ticket ("+tr.grade+")"),
    ev("Largest ticket as % of their own limit",(Math.max.apply(null,ts.map(t=>t.notional))/L*100).toFixed(1)+"%",true),
    ev("Aggregate notional",fmtM(tot)+" — "+(tot/L).toFixed(1)+"× the limit that was avoided",true),
    ev("Window",(ts[n-1].execMin-t0)+" minutes",true),
    ev("Counterparty (all tickets)",ctpy.name),
    ev("Supervisor who would have signed",tr.supervisor),
    ev("Independent approval obtained","None — each ticket self-approved",true),
  ],n+" tickets of "+prod+" each just under this trader's own "+fmtM(L)+" authorisation, "+fmtM(tot)+" in "+(ts[n-1].execMin-t0)+" minutes");
};

PLANT["TS-07"]=function(rule){
  const tr=pickActor(rule), day=pickDayWeighted(), b=trBase(tr);
  const desk=DESK_BY_ID[tr.deskId];
  // Two shapes: a product nobody on the floor near them trades, or — the more
  // interesting one — a product the desk is signed off for but this trader is not.
  const deskOnly=desk.mandate.filter(p=>tr.products.indexOf(p)<0);
  const offFloor=PRODUCTS.filter(p=>desk.mandate.indexOf(p.p)<0).map(p=>p.p);
  const deskApproved=deskOnly.length&&rng()<0.45;
  const prod=deskApproved?choice(deskOnly):choice(offFloor);
  const t=makeTrade(day,tr,prod,{notional:sizeFor(tr,0.6,5.5)});
  return mkAlert(rule,day,tr,[t],[
    ev("Trader",tr.name+" · "+tr.grade+" · "+desk.name),
    ev("Product booked",prod+" ("+t.ac+")",true),
    ev("This trader's approved products",tr.products.join(", ")),
    ev("Desk-level approval",deskApproved?"Held by the desk — NOT extended to this trader":"Not held by the desk either",true),
    ev("Personal mandate exception on file","None",true),
    ev("Prior deals in this product by this trader",b.products.indexOf(prod)>=0?"Some — see the blotter":"None in 12 months",b.products.indexOf(prod)<0),
    ev("Notional",fmtM(t.notional)),
    ev("Instrument",t.instrument), ev("Counterparty",t.ctpy),
    ev("Risk captured in this trader's limits","No — booked to "+t.book,true),
  ],prod+" booked by "+tr.name+", which is not on their own approved product list"+(deskApproved?" (the desk holds it; they do not)":""),
  {sev:t.notional>b.medSize*3?"High":"Medium"});
};

PLANT["TS-08"]=function(rule){
  const tr=pickActor(rule);
  const weekend=rng()<0.55;
  let day;
  if(weekend){ day=randInt(4,DAYS-1); for(let i=0;i<40&&isBiz(dateForIdx(day));i++) day=randInt(4,DAYS-1); }
  else day=pickDayWeighted();
  const desk=DESK_BY_ID[tr.deskId], h=DESK_HOURS[desk.region], b=trBase(tr);
  const em=weekend?Math.round(rand(9,20)*60):(rng()<0.5?Math.round(rand(0,h[0]*60-95)):Math.round(rand(h[1]*60+95,1435)));
  const t=makeTrade(day,tr,choice(tr.products),{execMin:em,notional:sizeFor(tr,0.5,7),captureLag:rand(5,90)});
  const d=dateForIdx(day);
  // The trader's own working window, not the desk's — some names never book
  // before ten, and 07:20 for one of them is the finding.
  const lo=b.execMean-2.5*b.execSd, hi=b.execMean+2.5*b.execSd;
  const zOwn=b.execSd?Math.abs(em-b.execMean)/b.execSd:0;
  return mkAlert(rule,day,tr,[t],[
    ev("Booking timestamp",fmtDate(d)+" "+fmtTime(em)+" "+desk.region,true),
    ev("Calendar status",isWeekend(d)?["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"][d.getDay()]+" — non-business day":isHoliday(d)?"Local holiday — non-business day":"Business day",!isBiz(d)),
    ev("This trader's own window (±2.5σ)",fmtTime(Math.max(0,lo))+" – "+fmtTime(Math.min(1439,hi))+" "+desk.region+", from "+fmtNum(b.deals)+" deals"),
    ev("Distance from their own mean",zOwn.toFixed(1)+"σ",true),
    ev("Desk hours for reference",fmtTime(h[0]*60)+" – "+fmtTime(h[1]*60)+" "+desk.region),
    ev("Outside window by",isBiz(d)?(em<h[0]*60?((h[0]*60-em)/60).toFixed(1)+"h before open":((em-h[1]*60)/60).toFixed(1)+"h after close"):"Full day",true),
    ev("Supervisor on desk","No",true),
    ev("Product / notional",t.product+" · "+fmtM(t.notional)),
    ev("Counterparty",t.ctpy),
  ],t.product+" booked at "+fmtTime(em)+" "+desk.region+(isBiz(d)?" — "+zOwn.toFixed(1)+"σ outside this trader's own working window":" on a non-business day"),
  {sev:!isBiz(d)?"High":"Medium"});
};

PLANT["TS-09"]=function(rule){
  const tr=pickActor(rule), b=trBase(tr);
  const day=choice(MONTH_END_REV);
  // A mark is set on a price. An option book is marked on its surface, which is
  // TS-15's test, so this rule stays on the cash-priced names.
  const cash=tr.products.filter(x=>FAM_MKT[PROD_BY_NAME[x].fam].omFloor>0);
  const prod=cash.length?choice(cash):"FX Spot";
  const inst=instrumentFor(prod), n=randInt(2,4), ts=[];
  for(let i=0;i<n;i++) ts.push(makeTrade(day,tr,prod,{inst,notional:sizeFor(tr,1.2,5),dir:longDir(prod)}));
  let pnl=0;
  ts.forEach(t=>{ applyDev(t,devFor(inst,rand(1.3,4.4))); t.pnl=bpValue(t.fam,t.notional,t.devBps); pnl+=t.pnl; });
  // The reversal is the point: the mark exists for the close, not for the book.
  const revGap=randInt(1,3), revDay=bizFwd(day,revGap);
  const rev=makeTrade(revDay,tr,ts[0].product,{inst:INST_BY_KEY[ts[0].instKey],label:ts[0].instrument,
    notional:ts[0].notional,dir:oppDir(ts[0].dir),pnl:+(-pnl*rand(0.72,0.95)).toFixed(1)});
  return mkAlert(rule,day,tr,ts.concat([rev]),[
    ev("Valuation date",fmtDate(dateForIdx(day))+" — month end",true),
    ev("Off-market trades on the date",String(ts.length),true),
    ev("Average deviation from mid",(ts.reduce((a,t)=>a+Math.abs(t.devBps),0)/ts.length).toFixed(1)+" bps",true),
    ev("Direction","All "+ts[0].dir+" — one-sided",true),
    ev("P&L booked on valuation date",fmtK(pnl),true),
    ev("Reversal",fmtDate(dateForIdx(revDay))+" — "+revGap+" business day"+(revGap>1?"s":"")+" later · "+rev.dir+" "+fmtM(rev.notional)+" · "+fmtK(rev.pnl),true),
    ev("Net economic result",fmtK(pnl+rev.pnl)),
    ev("Independent price verification","Not performed — trades post-dated the IPV run",true),
  ],ts.length+" one-sided off-market marks on the month-end valuation date, reversed "+revGap+" business day"+(revGap>1?"s":"")+" later");
};

PLANT["TS-10"]=function(rule){
  const tr=pickActorWith(rule,x=>x.products.some(p=>["fx","ndf"].indexOf(PROD_BY_NAME[p].fam)>=0));
  const day=pickDayWeighted();
  const desk=DESK_BY_ID[tr.deskId];
  const prod=tr.products.indexOf("FX Spot")>=0?"FX Spot":choice(tr.products);
  const inst=instrumentFor(prod);
  const n=randInt(5,9), ts=[], ctpy=choice(INST_CTPY);
  // 16:00–16:03 London: the WM/Reuters benchmark window.
  for(let i=0;i<n;i++) ts.push(makeTrade(day,tr,prod,{inst,notional:sizeFor(tr,0.9,3.4),dir:longDir(prod),execMin:960+randInt(0,3),ctpy,captureLag:rand(0,4)}));
  const fixVol=ts.reduce((a,t)=>a+t.notional,0);
  const dayVol=fixVol/rand(0.42,0.78);
  // Read off the pair's own path across the window the chart shows.
  const move=Math.abs(mktMove(inst,day,958,972))+rand(1.5,6);
  ts.forEach(t=>{ t.pnl=bpValue(t.fam,t.notional,move); });
  return mkAlert(rule,day,tr,ts,[
    ev("Instrument",inst.name),
    ev("Orders in 16:00 fix window",String(n),true),
    ev("Notional in window",fmtM(fixVol),true),
    ev("Trader volume that day",fmtM(dayVol)),
    ev("Share of daily volume in window",(fixVol/dayVol*100).toFixed(1)+"%",true),
    ev("Rule threshold","40%"),
    ev("Direction","100% "+ts[0].dir+" — one-sided",true),
    ev("Benchmark move across the window","+"+move.toFixed(1)+" bps in "+inst.name,true),
    ev("P&L attributed to the fix",fmtK(ts.reduce((a,t)=>a+t.pnl,0)),true),
  ],(fixVol/dayVol*100).toFixed(0)+"% of the day's volume executed one-way inside the 16:00 benchmark window");
};

PLANT["TS-11"]=function(rule){
  const tr=pickActor(rule), day=pickDayWeighted(), b=trBase(tr);
  const desk=DESK_BY_ID[tr.deskId], prod=choice(tr.products), inst=instrumentFor(prod);
  const clientCtpy=choice(COUNTERPARTIES.filter(c=>c.type==="Asset Manager"||c.type==="Corporate"||c.type==="Insurer"));
  const gap=randInt(1,14);
  const em=execMinFor(desk);
  const L=longDir(prod);
  const house=makeTrade(day,tr,prod,{inst,notional:sizeFor(tr,1.2,4),dir:L,ctpy:choice(COUNTERPARTIES.filter(c=>c.type==="Broker")),execMin:em,channel:"API / Algo"});
  const client=makeTrade(day,tr,prod,{inst,notional:sizeFor(tr,5.5,16),dir:L,ctpy:clientCtpy,execMin:em+gap,channel:"Voice"});
  applyDev(client,rand(6,19));
  house.pnl=+(house.notional*rand(1.6,5.2)).toFixed(1);
  return mkAlert(rule,day,tr,[house,client],[
    ev("Instrument",prod+" · "+inst.name),
    ev("House trade",house.dir+" "+fmtM(house.notional)+" @ "+px(house)+" · "+fmtTime(house.execMin)+" · "+house.channel,true),
    ev("Client order",client.dir+" "+fmtM(client.notional)+" @ "+px(client)+" · "+fmtTime(client.execMin)+" · "+clientCtpy.name),
    ev("Lead time",gap+" minutes ahead of the client",true),
    ev("Direction","Same side as the client order",true),
    ev("Client order size",fmtM(client.notional)+" — "+xBase(client.notional,b.medSize)+" this trader's median ticket",true),
    ev("Price move between the two",Math.abs(client.devBps).toFixed(1)+" bps against the client",true),
    ev("House P&L on the client print",fmtK(house.pnl),true),
    ev("Order handling record","No pre-hedge authorisation recorded",true),
  ],"House "+prod+" position taken "+gap+" minutes ahead of a "+fmtM(client.notional)+" client order in the same direction");
};

PLANT["TS-12"]=function(rule){
  const tr=pickActor(rule), day=pickDayWeighted();
  const desk=DESK_BY_ID[tr.deskId], prod=choice(tr.products), inst=instrumentFor(prod);
  const limit=tr.posLimit;
  const build=[], n=randInt(3,5); let pos=0;
  const t0=execMinFor(desk);
  const L=longDir(prod);
  // Every leg stays inside the trader's ticket authorisation — the breach is
  // the position they add up to, which is exactly why no single deal is caught.
  const target=limit*rand(1.32,1.85);
  const n2=Math.max(n,Math.ceil(target/(tr.ticketLimit*0.95)));
  const leg=target/n2;
  for(let i=0;i<n2;i++){ const t=makeTrade(day,tr,prod,{inst,notional:Math.min(tr.ticketLimit*0.98,leg*rand(0.86,1.14)),dir:L,
    execMin:Math.min(1439,t0+i*randInt(6,26))}); pos+=t.notional; build.push(t); }
  /* The unwind respects the same authorisation the build did: a position this
     size is flattened in clips, not in one ticket several times the limit the
     alert is arguing was never breached. */
  const flatTotal=pos*rand(0.88,0.97);
  const flatN=Math.max(1,Math.ceil(flatTotal/(tr.ticketLimit*0.95)));
  const closeMin=Math.min(1439,DESK_HOURS[desk.region][1]*60-randInt(5,25));
  const flats=[];
  for(let i=0;i<flatN;i++) flats.push(makeTrade(day,tr,prod,{inst,notional:flatTotal/flatN,dir:oppDir(L),
    execMin:Math.max(t0+1,closeMin-(flatN-1-i)*randInt(2,7))}));
  const flat=flats[flats.length-1];
  const eod=pos-flatTotal;
  return mkAlert(rule,day,tr,build.concat(flats),[
    ev("Instrument",prod+" · "+inst.name),
    ev("This trader's position limit",fmtM(limit)+" ("+tr.grade+", "+desk.short+")"),
    ev("Tickets used to build it",build.length+" × "+fmtM(pos/build.length)+" — every one inside the "+fmtM(tr.ticketLimit)+" ticket authorisation",true),
    ev("Peak intraday position",fmtM(pos)+" at "+fmtTime(build[build.length-1].execMin),true),
    ev("Peak as % of their own limit",(pos/limit*100).toFixed(0)+"%",true),
    ev("Unwind",plural(flats.length,"ticket")+" · "+flat.dir+" "+fmtM(flatTotal)+" between "+fmtTime(flats[0].execMin)+" and "+fmtTime(flat.execMin),true),
    ev("End-of-day position",fmtM(eod)+" ("+(eod/limit*100).toFixed(0)+"% of their limit)"),
    ev("Breach visible on EOD risk report","No",true),
    ev("Limit escalation raised","None — no snapshot ever saw it",true),
    ev("Supervisor",tr.supervisor),
  ],"Position peaked at "+(pos/limit*100).toFixed(0)+"% of this trader's own limit intraday and was flattened before the end-of-day snapshot");
};

PLANT["TS-13"]=function(rule){
  const tr=pickActor(rule), day=pickDayWeighted();
  const ts=ensureTrades(tr,day,randInt(2,4));
  const sd=rand(38,95), mean=rand(-8,22);
  const z=rand(3.05,7.4);
  const dayPnl=mean+z*sd;
  let acc=0;
  ts.forEach((t,i)=>{ t.pnl=+(dayPnl*(i===0?0.62:0.38/(ts.length-1||1))).toFixed(1); acc+=t.pnl; });
  return mkAlert(rule,day,tr,ts,[
    ev("Trading day",fmtDate(dateForIdx(day))),
    ev("Daily P&L",fmtK(acc),true),
    ev("Trailing 60-day mean",fmtK(mean)),
    ev("Trailing 60-day σ",fmtK(sd)),
    ev("z-score",z.toFixed(2),true),
    ev("Rule threshold","3.00"),
    ev("Deals contributing",String(ts.length)+" ("+ts.map(t=>t.product).filter((v,i,a)=>a.indexOf(v)===i).join(", ")+")"),
    ev("Volume that day","Within normal range — move not explained by size",true),
    ev("Market move in underlying",rand(-0.4,0.5).toFixed(2)+"% — insufficient to explain",true),
  ],"Daily P&L of "+fmtK(acc)+" sits "+z.toFixed(1)+"σ outside this trader's own 60-day distribution",
  {sev:z>5?"Critical":"High"});
};

PLANT["TS-14"]=function(rule){
  const tr=pickActor(rule);
  const me=choice(MONTH_END_REV);
  const outDay=BIZ_DAYS[Math.max(0,BIZ_DAYS.indexOf(me)-randInt(1,3))];
  const backDay=BIZ_DAYS[Math.min(BIZ_DAYS.length-1,BIZ_DAYS.indexOf(me)+randInt(2,8))];
  const desk=DESK_BY_ID[tr.deskId], prod=choice(tr.products), inst=instrumentFor(prod);
  const notional=sizeFor(tr,2.0,7.0), book=choice(INTERNAL_BOOKS);
  const loss=-Math.abs(rand(420,3100));
  const out=makeTrade(outDay,tr,prod,{inst,notional,dir:shortDir(prod),ctpy:{name:book,type:"Internal book",country:"—"},
    internal:true,venue:"Internal",channel:"Internal booking",pnl:0});
  const back=makeTrade(backDay,tr,prod,{inst,notional:notional*rand(0.998,1.002),dir:longDir(prod),ctpy:{name:book,type:"Internal book",country:"—"},
    internal:true,venue:"Internal",channel:"Internal booking",pnl:+loss.toFixed(1)});
  return mkAlert(rule,outDay,tr,[out,back],[
    ev("Reporting date",fmtDate(dateForIdx(me))+" — month end",true),
    ev("Transfer out",fmtDate(dateForIdx(outDay))+" · "+fmtM(notional)+" → "+book,true),
    ev("Days before reporting date",String(BIZ_DAYS.indexOf(me)-BIZ_DAYS.indexOf(outDay)),true),
    ev("Transfer back",fmtDate(dateForIdx(backDay))+" · "+fmtM(back.notional)+" ← "+book,true),
    ev("Round trip closed in",(BIZ_DAYS.indexOf(backDay)-BIZ_DAYS.indexOf(outDay))+" business days",true),
    ev("Size match","99.9% — same position returned",true),
    ev("Unrealised loss removed from the book at period end",fmtK(loss),true),
    ev("External counterparty","None — internal warehouse book",true),
    ev("Transfer pricing approval","Not evidenced",true),
  ],fmtM(notional)+" moved to "+book+" days before month end and returned unchanged, carrying "+fmtK(loss)+" of loss");
};

PLANT["TS-15"]=function(rule){
  const tr=pickActorWith(rule,x=>x.products.some(p=>PROD_BY_NAME[p].fam==="fxopt"));
  const day=pickDayWeighted(), b=trBase(tr);
  const desk=DESK_BY_ID[tr.deskId];
  const prod=tr.products.filter(p=>PROD_BY_NAME[p].fam==="fxopt")[0]||"FX Vanilla Option";
  const inst=instrumentFor(prod);
  const t=makeTrade(day,tr,prod,{inst,notional:sizeFor(tr,2.1,8)});
  const diff=rand(2.1,6.4)*(rng()<0.5?-1:1);
  t.mktVol=+volAt(inst,day).toFixed(2);
  t.vol=+(t.mktVol+diff).toFixed(2);
  // A vol away from the surface is worth vega: roughly $0.4k per $m of notional
  // per vol on a three-to-six month option, not a price deviation.
  t.pnl=+(t.notional*Math.abs(diff)*rand(0.32,0.55)).toFixed(1);
  return mkAlert(rule,day,tr,[t],[
    ev("Instrument",prod+" · "+t.instrument),
    ev("Quoted implied volatility",t.vol.toFixed(2)+" vols",true),
    ev("Official surface (same pair/tenor)",t.mktVol.toFixed(2)+" vols"),
    ev("Deviation",(diff>0?"+":"")+diff.toFixed(2)+" vols",true),
    ev("Rule threshold","±2.00 vols"),
    ev("Notional",fmtM(t.notional)+" — "+xBase(t.notional,b.medSize)+" this trader's median ticket",true),
    ev("Day-one P&L effect",fmtK(t.pnl),true),
    ev("Counterparty",t.ctpy+" · "+t.ctpyType),
    ev("Surface override approval","None recorded for this trader",true),
  ],prod+" priced "+Math.abs(diff).toFixed(1)+" vols away from the official surface on "+fmtM(t.notional));
};

PLANT["TS-16"]=function(rule){
  const tr=pickActor(rule), day=pickDayWeighted(), b=trBase(tr);
  const desk=DESK_BY_ID[tr.deskId];
  const cash=tr.products.filter(p=>FAM_MKT[PROD_BY_NAME[p].fam].omFloor>0);
  const prod=cash.length?choice(cash):"FX Spot";
  const inst=instrumentFor(prod);
  const toBook=choice(INTERNAL_BOOKS);
  // An internal price answers to nobody, so it is held to a tighter test than a
  // print struck with a counterparty who can argue about it.
  const thr=Math.max(6,omThreshold(inst)*0.6);
  const notional=sizeFor(tr,1.6,7), bps=devFor(inst,rand(0.7,3.3));
  const t=makeTrade(day,tr,prod,{inst,notional,ctpy:{name:toBook,type:"Internal book",country:"—"},
    internal:true,venue:"Internal",channel:"Internal booking",spreadBps:bps});
  t.pnl=bpValue(t.fam,notional,t.devBps);
  return mkAlert(rule,day,tr,[t],[
    ev("Booking type","Internal transfer — no external counterparty",true),
    ev("From book",tr.book), ev("To book",toBook),
    ev("Instrument",prod+" · "+inst.name),
    ev("Transfer price",px(t),true), ev("Market mid",mkt(t)),
    ev("Deviation",Math.abs(t.devBps).toFixed(1)+" bps",true),
    ev("Threshold for an internal price in this name",thr.toFixed(1)+" bps"),
    ev("Notional",fmtM(notional)),
    ev("P&L moved between books",fmtK(t.pnl),true),
    ev("Transfer price signed off by both books","No",true),
  ],fmtK(t.pnl)+" of P&L moved to "+toBook+" through an internal transfer priced "+Math.abs(t.devBps).toFixed(0)+" bps off mid");
};

PLANT["TS-17"]=function(rule){
  const tr=pickActor(rule), day=pickDayWeighted();
  const t=ensureTrades(tr,day,1)[0];
  t.ssiChanged=true; t.amends=Math.max(1,t.amends); t.status="Amended";
  t.notional=Math.max(t.notional,rand(9,140));
  const origBank=choice(COUNTERPARTIES.filter(c=>c.type==="Bank"));
  const newJur=choice(["Cyprus","Seychelles","Panama","Latvia","UAE","Cayman"]);
  const hrs=rand(0.4,26);
  return mkAlert(rule,day,tr,[t],[
    ev("Trade",t.id+" · "+t.product+" · "+fmtM(t.notional)),
    ev("Counterparty",t.ctpy+" · "+t.ctpyType+" · "+t.ctpyCountry),
    ev("SSI on static record",origBank.name+" ("+origBank.country+")"),
    ev("SSI at settlement instruction",choice(["Northgate Clearing SA","Aurora Trust Bank","Continental Escrow NV","Pallas Financial Ltd"])+" ("+newJur+")",true),
    ev("Jurisdiction change",t.ctpyCountry+" → "+newJur,true),
    ev("Amended",hrs.toFixed(1)+" hours after execution",true),
    ev("Amended by",rng()<0.5?"Front office — "+tr.name:"Front office (shared desk ID)",true),
    ev("Counterparty confirmation of change","Not on file",true),
    ev("Amount at risk",fmtM(t.notional),true),
  ],"Settlement instructions redirected to "+newJur+" "+hrs.toFixed(0)+"h after execution on a "+fmtM(t.notional)+" "+t.product);
};

PLANT["TS-18"]=function(rule){
  const tr=pickActorWith(rule,x=>x.products.some(p=>PROD_BY_NAME[p].fam==="repo"));
  const qe=choice(QUARTER_END);
  const qi=BIZ_DAYS.indexOf(qe);
  const startDay=BIZ_DAYS[Math.max(0,qi-randInt(8,20))];
  const matDay=BIZ_DAYS[Math.max(0,qi-randInt(1,2))];
  const reDay=BIZ_DAYS[Math.min(BIZ_DAYS.length-1,qi+randInt(1,3))];
  const bs=trBase(tr);
  const notional=bs.medSize*rand(4.2,14), inst=instrumentFor("Repo");
  const a=makeTrade(startDay,tr,"Repo",{inst,notional,dir:"Borrow",tenor:"1M"});
  const b=makeTrade(reDay,tr,"Repo",{inst,notional:notional*rand(0.98,1.02),dir:"Borrow",tenor:"1M"});
  return mkAlert(rule,startDay,tr,[a,b],[
    ev("Reporting date",fmtDate(dateForIdx(qe))+" — quarter end",true),
    ev("Financing",fmtM(notional)+" "+a.instrument),
    ev("This trader's median financing ticket",fmtM(bs.medSize)+" — roll is "+xBase(notional,bs.medSize)+" their own normal size",true),
    ev("This trader's ticket authorisation",fmtM(tr.ticketLimit)+(notional>tr.ticketLimit?" — exceeded on the roll, "+xBase(notional,tr.ticketLimit):" — within authority"),notional>tr.ticketLimit),
    ev("Matures",fmtDate(dateForIdx(matDay))+" — "+(qi-BIZ_DAYS.indexOf(matDay))+" business days before reporting date",true),
    ev("Re-struck",fmtDate(dateForIdx(reDay))+" — "+(BIZ_DAYS.indexOf(reDay)-qi)+" business days after",true),
    ev("Size on re-strike",fmtM(b.notional)+" (within 2% of original)",true),
    ev("Balance sheet reported over the date","Nil — this financing was not outstanding",true),
    ev("Prior occurrences",randInt(2,5)+" quarters in the last 8",true),
    ev("Counterparty",a.ctpy),
    ev("Business rationale documented","None",true),
  ],fmtM(notional)+" of repo funding matured just before the quarter end and was re-struck days later");
};

PLANT["TS-19"]=function(rule){
  const tr=pickActor(rule);
  const lo=tr.leave[0], hi=tr.leave[1];
  let day=randInt(lo,hi);
  for(let i=0;i<20&&!isBiz(dateForIdx(day));i++) day=randInt(lo,hi);
  const n=randInt(1,4), ts=[];
  const desk=DESK_BY_ID[tr.deskId];
  for(let i=0;i<n;i++) ts.push(makeTrade(day,tr,choice(tr.products),{notional:trBase(tr).medSize*rand(0.6,8)}));
  const tot=ts.reduce((a,t)=>a+t.notional,0);
  return mkAlert(rule,day,tr,ts,[
    ev("Block leave window",fmtDate(dateForIdx(lo))+" – "+fmtDate(dateForIdx(hi)),true),
    ev("Activity date",fmtDate(dateForIdx(day))+" — day "+(day-lo+1)+" of leave",true),
    ev("Deals booked under trader ID",String(n),true),
    ev("Aggregate notional",fmtM(tot),true),
    ev("Products",ts.map(t=>t.product).filter((v,i,a)=>a.indexOf(v)===i).join(", ")),
    ev("Booked from","Remote session — non-office IP",true),
    ev("Cover trader on the desk",choice(desk.traders.filter(x=>x.id!==tr.id)).name),
    ev("Delegation recorded","None — deals carry the absent trader's ID",true),
  ],n+" deal"+(n>1?"s":"")+" totalling "+fmtM(tot)+" booked under "+tr.name+"'s ID during mandatory block leave");
};

PLANT["TS-20"]=function(rule){
  const tr=pickActor(rule);
  const annDay=pickDay(20,DAYS-2);
  const lead=randInt(1,5);
  const day=BIZ_DAYS[Math.max(0,BIZ_DAYS.indexOf(annDay)-lead)];
  const desk=DESK_BY_ID[tr.deskId];
  const creditBooks=tr.products.filter(p=>PROD_BY_NAME[p].fam==="cds"||PROD_BY_NAME[p].fam==="bondc");
  const prod=creditBooks.length?choice(creditBooks):choice(tr.products);
  const inst=instrumentFor(prod);
  const nameOnly=inst.name.replace(/ 5Y CDS| \d.*$/,"");
  const news=choice([
    ["Rating downgrade to sub-investment grade","S&P / Moody's action"],
    ["Profit warning and covenant waiver request","Company announcement"],
    ["Missed coupon payment","Trustee notice"],
    ["Emergency refinancing announced","Company announcement"],
    ["Regulatory investigation disclosed","Exchange filing"],
  ]);
  const n=randInt(2,4), ts=[];
  for(let i=0;i<n;i++) ts.push(makeTrade(day,tr,prod,{inst,notional:sizeFor(tr,0.8,3.2),dir:prod.indexOf("CDS")>=0?longDir(prod):shortDir(prod)}));
  const tot=ts.reduce((a,t)=>a+t.notional,0);
  const gain=rand(420,4200);
  ts.forEach(t=>{ t.pnl=+(gain*t.notional/tot).toFixed(1); });
  return mkAlert(rule,day,tr,ts,[
    ev("Name",nameOnly+(inst.rating?" ("+inst.rating+")":"")),
    ev("Position built",ts[0].dir+" "+fmtM(tot)+" across "+n+" tickets on "+fmtDate(dateForIdx(day)),true),
    ev("Direction","One-sided — no offsetting flow",true),
    ev("Announcement",news[0]+" · "+news[1]),
    ev("Announcement date",fmtDate(dateForIdx(annDay)),true),
    ev("Lead time",lead+" business days before the announcement",true),
    ev("Prior activity in this name","None in the preceding 6 months",true),
    ev("Mark-to-market gain on the news",fmtK(gain),true),
    ev("Wall-crossing / restricted list check","Name not on the restricted list at the time",false),
  ],ts[0].dir+" "+fmtM(tot)+" of "+nameOnly+" risk built "+lead+" days before "+news[0].toLowerCase()+", gaining "+fmtK(gain));
};

/* ------------------------------------------------------------
   TS-21 … TS-50. Every generator resolves its threshold from the trader's own
   profile — their authorisation, their baseline, their cohort — so the evidence
   an officer reads is an argument about one person's book, not a desk average.
------------------------------------------------------------ */

PLANT["TS-21"]=function(rule){
  // Forward points are a forward, swap or NDF concept. An option has a premium,
  // not a points leg, so it cannot carry this finding at all.
  const FWD=["FX Forward","FX Swap","NDF"];
  const tr=pickActorWith(rule,x=>x.products.some(p=>FWD.indexOf(p)>=0));
  const day=pickDayWeighted(), b=trBase(tr);
  const fwd=tr.products.filter(p=>FWD.indexOf(p)>=0);
  const prod=fwd.length?choice(fwd):"FX Forward";
  const t=makeTrade(day,tr,prod,{notional:sizeFor(tr,2.2,9)});
  const bps=devFor(INST_BY_KEY[t.instKey],rand(1.1,4.4));
  applyDev(t,bps);
  const curve=rand(18,140);
  t.pnl=bpValue(t.fam,t.notional,t.devBps);
  return mkAlert(rule,day,tr,[t],[
    ev("Instrument",prod+" · "+t.instrument+" · "+t.tenor),
    ev("Traded forward points",(curve+bps).toFixed(1)+" pts",true),
    ev("Curve-implied points",curve.toFixed(1)+" pts"),
    ev("Difference",bps.toFixed(1)+" bps of the outright",true),
    ev("Rule threshold","18.0 bps"),
    ev("Spot leg","On market — within 0.4 bps of mid"),
    ev("Notional",fmtM(t.notional)+" — "+xBase(t.notional,b.medSize)+" this trader's median ticket",true),
    ev("Counterparty",t.ctpy+" · "+t.ctpyType),
    ev("Value transferred",fmtK(t.pnl),true),
  ],prod+" points struck "+bps.toFixed(0)+" bps off the curve while the spot leg printed on market",
  {sev:bps>50?"Critical":"High"});
};

PLANT["TS-22"]=function(rule){
  const tr=pickActor(rule), day=pickDay(24,DAYS-1), b=trBase(tr);
  const ctpy=rng()<0.45?{name:choice(Object.keys(RELATED_PARTIES)),type:"Private Client",country:"Singapore"}:choice(COUNTERPARTIES);
  const prod=choice(tr.products), inst=instrumentFor(prod);
  const n=randInt(8,13), ts=[], favour=rand(6.5,21);
  for(let i=0;i<n;i++){
    const t=makeTrade(bizBack(day,randInt(0,19)),tr,prod,{inst,notional:sizeFor(tr,0.6,2.4),ctpy,dir:i%2?longDir(prod):shortDir(prod)});
    applyDev(t,-favour*rand(0.75,1.25));   // the fill sits on the counterparty's side of mid
    t.pnl=-bpValue(t.fam,t.notional,t.devBps);
    ts.push(t);
  }
  const give=ts.reduce((a,t)=>a+Math.abs(t.devBps),0)/n;
  const paid=ts.reduce((a,t)=>a+t.pnl,0);
  const rel=RELATED_PARTIES[ctpy.name];
  return mkAlert(rule,day,tr,ts,[
    ev("Counterparty",ctpy.name+" · "+ctpy.type,true),
    ev("Trades with this name (20 business days)",String(n),true),
    ev("Mean execution versus mid",give.toFixed(1)+" bps in the counterparty's favour",true),
    ev("This trader's other flow","0.8 bps — inside the spread, as expected"),
    ev("Rule threshold","6.0 bps sustained across ≥8 trades"),
    ev("Aggregate value paid away",fmtK(paid),true),
    ev("This trader's largest counterparty (12m)",b.topCtpy+" at "+fmtPct(b.topCtpyShare,1)+" of tickets"),
    ev("Related-party register",rel?"MATCH — "+rel:"No match",!!rel),
  ],n+" fills to "+ctpy.name+" averaging "+give.toFixed(1)+" bps in their favour while the rest of this trader's book printed inside the spread",
  {sev:rel?"Critical":"High"});
};

PLANT["TS-23"]=function(rule){
  const tr=pickActorWith(rule,x=>x.products.indexOf("NDF")>=0);
  const day=pickDayWeighted(), b=trBase(tr);
  const prod=tr.products.indexOf("NDF")>=0?"NDF":"NDF";
  const t=makeTrade(day,tr,prod,{notional:sizeFor(tr,1.5,7)});
  const bps=devFor(INST_BY_KEY[t.instKey],rand(1.1,4.6));
  applyDev(t,bps);
  t.pnl=bpValue(t.fam,t.notional,t.devBps);
  const src=choice(["EMTA","ABS Benchmarks","Reuters SPOT","central bank reference"]);
  return mkAlert(rule,day,tr,[t],[
    ev("Instrument",prod+" · "+t.instrument+" · "+t.tenor),
    ev("Settlement rate applied",px(t),true),
    ev("Published official fixing",mkt(t)+" ("+src+")"),
    ev("Difference",Math.abs(t.devBps).toFixed(1)+" bps in the trader's favour",true),
    ev("Rule threshold","20.0 bps"),
    ev("Fixing source on the confirmation",src),
    ev("Notional",fmtM(t.notional)),
    ev("Cash settlement effect",fmtK(t.pnl),true),
    ev("Rate override approval","None recorded for this trader",true),
  ],prod+" cash-settled "+Math.abs(t.devBps).toFixed(0)+" bps away from the published "+src+" fixing");
};

PLANT["TS-24"]=function(rule){
  // A session extreme is a price. An option premium moves with its surface, so
  // this rule stays on the cash-quoted names.
  const tr=pickActorWith(rule,x=>x.products.some(p=>FAM_MKT[PROD_BY_NAME[p].fam].omFloor>0));
  const day=pickDayWeighted(), b=trBase(tr);
  const cash=tr.products.filter(p=>FAM_MKT[PROD_BY_NAME[p].fam].omFloor>0);
  const prod=cash.length?choice(cash):"FX Spot";
  const inst=instrumentFor(prod);
  const n=randInt(4,7), t0=execMinFor(DESK_BY_ID[tr.deskId]), ts=[];
  const L=rng()<0.5?longDir(prod):shortDir(prod);
  const buySide=["Buy","Pay","Borrow"].indexOf(L)>=0;
  /* Find the minutes at which the session actually reached its best level for
     this side, and print there. The claim is then visible on the chart rather
     than asserted next to it. */
  const grid=[];
  for(let m=SESSION_OPEN;m<=SESSION_CLOSE;m+=5) grid.push({m,v:midAt(inst,day,m)});
  grid.sort((x,y)=>buySide?x.v-y.v:y.v-x.v);
  const best=grid.slice(0,Math.max(n,6));
  for(let i=0;i<n;i++){
    const pick=best[i%best.length];
    const t=makeTrade(day,tr,prod,{inst,notional:sizeFor(tr,0.7,2.6),dir:L,execMin:pick.m+randInt(0,4)});
    applyDev(t,-rand(0.2,1.9));
    ts.push(t);
  }
  const dr=dayRange(inst,day);
  const range=Math.abs(devBpsOf(inst.unit,dr.hi,dr.lo));
  const expected=Math.max(1,Math.round(b.tickets*0.08));
  const stamped=rng()<0.4;
  return mkAlert(rule,day,tr,ts,[
    ev("Instrument",prod+" · "+inst.name),
    ev("Trades at the session extreme",String(n),true),
    ev("Direction","All "+L+" — the extreme is the day's "+(buySide?"low":"high"),true),
    ev("Session range in "+inst.name,range.toFixed(1)+" bps ("+fmt2(dr.lo,inst.dp)+" – "+fmt2(dr.hi,inst.dp)+")"),
    ev("Mean distance from the extreme",(ts.reduce((a,t)=>a+Math.abs(t.devBps),0)/n).toFixed(2)+" bps",true),
    ev("Expected at this trader's ticket count","≤"+expected+" per session"),
    ev("This trader's daily ticket average",b.tickets.toFixed(1)),
    ev("Timestamps amended after capture",stamped?"Yes — 2 tickets":"No",stamped),
  ],n+" fills placed within 2 bps of the day's best price for this trader, against an expected "+expected,
  {sev:stamped?"High":"Medium"});
};

PLANT["TS-25"]=function(rule){
  const tr=pickActor(rule), day=pickDayWeighted(), b=trBase(tr);
  const n=randInt(3,6), ts=ensureTrades(tr,day,n), gaps=[];
  ts.forEach(t=>{ t.cancelled=true; t.status="Cancelled"; t.amends=Math.max(1,t.amends); gaps.push(randInt(2,14)); });
  const tot=ts.reduce((a,t)=>a+t.notional,0);
  return mkAlert(rule,day,tr,ts,[
    ev("Deals booked and pulled",String(n),true),
    ev("Time to cancellation",gaps.join(", ")+" minutes",true),
    ev("Policy threshold","3 cancellations inside 15 minutes in one session"),
    ev("This trader's own cancellation rate",fmtPct(Math.max(0.004,b.amendRate*0.3),1)+" of tickets across "+fmtNum(b.deals)+" deals"),
    ev("Aggregate notional pulled",fmtM(tot),true),
    ev("Position visible on the intraday risk run","No — every deal cancelled between runs",true),
    ev("Counterparties",uniq(ts.map(t=>t.ctpy)).slice(0,3).join(", ")),
    ev("Prices shown to the market before cancellation","Yes",true),
  ],n+" deals booked and cancelled within minutes, none of them reaching an intraday risk run");
};

PLANT["TS-26"]=function(rule){
  const tr=pickActor(rule), b=trBase(tr);
  const shortSettle=tr.products.filter(p=>SETTLE_DAYS[p]!=null&&SETTLE_DAYS[p]<=2);
  const prod=shortSettle.length?choice(shortSettle):"FX Spot";
  const day=pickDay(4,DAYS-25), settle=SETTLE_DAYS[prod]||2;
  const t=makeTrade(day,tr,prod,{notional:sizeFor(tr,0.8,4)});
  t.cancelled=true; t.status="Cancelled"; t.amends=Math.max(1,t.amends);
  const after=randInt(2,15), alertDay=Math.min(DAYS-1,day+settle+after);
  return mkAlert(rule,alertDay,tr,[t],[
    ev("Trade",t.id+" · "+t.product+" · "+fmtM(t.notional)),
    ev("Trade date",t.dateStr),
    ev("Value date",fmtDate(t.valueDate),true),
    ev("Cancelled",fmtDate(dateForIdx(alertDay))+" — "+after+" days after value date",true),
    ev("Confirmation status before cancellation","Confirmed and matched",true),
    ev("Settlement record","Cash movement shows as settled",true),
    ev("Cancelled by","Front office — "+tr.name,true),
    ev("Middle-office authorisation","None on file",true),
    ev("Counterparty notified of the cancellation","No record",true),
  ],fmtM(t.notional)+" "+prod+" cancelled "+after+" days after it should already have settled");
};

PLANT["TS-27"]=function(rule){
  const tr=pickActor(rule), day=pickDayWeighted(), b=trBase(tr);
  const t=ensureTrades(tr,day,1)[0];
  t.status="Amended"; t.amends=randInt(2,4);
  t.notional=Math.max(t.notional,sizeFor(tr,1.2,5));
  const field=choice([["Traded price","moved "+rand(9,60).toFixed(1)+" bps in the trader's favour"],
                      ["Notional","increased by "+rand(18,140).toFixed(0)+"%"],
                      ["Tenor","extended by "+randInt(1,9)+" months"],
                      ["Value date","moved "+randInt(1,6)+" business days later"]]);
  const hrs=rand(1.2,52);
  applyDev(t,devFor(INST_BY_KEY[t.instKey],rand(0.8,3.2)));
  t.pnl=bpValue(t.fam,t.notional,t.devBps);
  return mkAlert(rule,day,tr,[t],[
    ev("Trade",t.id+" · "+t.product+" · "+t.instrument),
    ev("Field amended",field[0]+" — "+field[1],true),
    ev("Amended",hrs.toFixed(1)+" hours after capture",true),
    ev("Policy threshold","60 minutes for economic fields"),
    ev("Amendment type","Economic — not a static-data correction",true),
    ev("Amendments on this deal",String(t.amends),true),
    ev("Counterparty re-confirmation","Not on file",true),
    ev("P&L effect of the amendment",fmtK(t.pnl),true),
    ev("This trader's own amendment rate",fmtPct(b.amendRate,1)+" of tickets"),
  ],field[0].toLowerCase()+" on a "+fmtM(t.notional)+" "+t.product+" changed "+hrs.toFixed(0)+"h after capture, worth "+fmtK(t.pnl));
};

PLANT["TS-28"]=function(rule){
  const tr=pickActor(rule), day=pickDayWeighted(), b=trBase(tr);
  const n=randInt(8,15), t0=execMinFor(DESK_BY_ID[tr.deskId]), ts=[];
  const prod=choice(tr.products), inst=instrumentFor(prod);
  for(let i=0;i<n;i++) ts.push(makeTrade(day,tr,prod,{inst,notional:sizeFor(tr,0.5,1.8),
    execMin:Math.min(1439,t0+randInt(0,9)),captureLag:rand(0,3)}));
  const tot=ts.reduce((a,t)=>a+t.notional,0);
  const peak=Math.max(2,Math.round(b.tickets*0.45));
  return mkAlert(rule,day,tr,ts,[
    ev("Tickets in the window",String(n),true),
    ev("Window","10 minutes from "+fmtTime(t0),true),
    ev("This trader's 90-day peak ten-minute rate",peak+" tickets"),
    ev("Burst versus their own peak",xBase(n,peak),true),
    ev("This trader's daily ticket average",b.tickets.toFixed(1)),
    ev("Aggregate notional",fmtM(tot)),
    ev("Counterparties in the burst",String(uniq(ts.map(t=>t.ctpy)).length)),
    ev("Booking channel",uniq(ts.map(t=>t.channel)).join(", ")),
    ev("Capture lag","under 3 minutes on every ticket — entered from a list",true),
  ],n+" tickets booked inside ten minutes — "+xBase(n,peak)+" this trader's own peak booking rate");
};

PLANT["TS-29"]=function(rule){
  const tr=pickActor(rule), day=pickDayWeighted(), b=trBase(tr);
  const peers=DESK_BY_ID[tr.deskId].traders.filter(x=>x.id!==tr.id);
  const toPeer=peers.length&&rng()<0.5;
  const victim=peers.length?choice(peers):tr;
  const book=toPeer?victim.book:choice(INTERNAL_BOOKS);
  const n=randInt(1,3), ts=[], prod=choice(tr.products), inst=instrumentFor(prod);
  for(let i=0;i<n;i++) ts.push(makeTrade(day,tr,prod,{inst,notional:sizeFor(tr,1.4,6),book}));
  const tot=ts.reduce((a,t)=>a+t.notional,0);
  return mkAlert(rule,day,tr,ts,[
    ev("Booked by",tr.name+" · "+tr.grade),
    ev("This trader's own book",tr.book),
    ev("Book used",book+(toPeer?" — "+victim.name+"'s book":" — internal warehouse"),true),
    ev("Deals",n+" · "+fmtM(tot),true),
    ev("Delegation record","None on file",true),
    ev("Visible in this trader's limit utilisation","No",true),
    ev("Visible in this trader's P&L","No",true),
    ev("Book owner notified",toPeer?"No record":"No owner — warehouse book",true),
    ev("Product",prod+" · "+inst.name),
  ],fmtM(tot)+" of "+prod+" booked by "+tr.name+" into "+book+", not their own book");
};

PLANT["TS-30"]=function(rule){
  const tr=pickActor(rule), day=pickDayWeighted(), b=trBase(tr);
  const prod=choice(tr.products), inst=instrumentFor(prod);
  const fills=randInt(2,5), ts=[], t0=execMinFor(DESK_BY_ID[tr.deskId]), L=longDir(prod);
  for(let i=0;i<fills;i++) ts.push(makeTrade(day,tr,prod,{inst,notional:sizeFor(tr,0.6,2),dir:L,
    execMin:Math.min(1439,t0+i*randInt(3,20)),channel:"API / Algo",venue:"SEF / MTF"}));
  const orders=fills*randInt(21,46), ratio=orders/fills, own=rand(3.1,5.6);
  ts.forEach(t=>{ t.pnl=bpValue(t.fam,t.notional,rand(14,42)); });
  return mkAlert(rule,day,tr,ts,[
    ev("Instrument",prod+" · "+inst.name),
    ev("Orders placed",String(orders),true),
    ev("Orders executed",String(fills)),
    ev("Cancel-to-trade ratio",ratio.toFixed(1)+":1",true),
    ev("This trader's own 12-month baseline",own.toFixed(1)+":1",true),
    ev("Rule threshold","20:1 in a session"),
    ev("Order side","Cancelled orders all on the opposite side to the fills",true),
    ev("Mean order lifetime",randInt(180,900)+" ms",true),
    ev("Channel","API / Algo"),
    ev("P&L on the executed side",fmtK(ts.reduce((a,t)=>a+t.pnl,0)),true),
  ],ratio.toFixed(0)+":1 cancel-to-trade on the algo channel against this trader's own "+own.toFixed(1)+":1 baseline");
};

PLANT["TS-31"]=function(rule){
  const tr=pickActor(rule), day=pickDayWeighted(), b=trBase(tr);
  const prod=choice(tr.products), inst=instrumentFor(prod);
  const n=randInt(5,8), t0=execMinFor(DESK_BY_ID[tr.deskId]), ts=[], L=longDir(prod);
  for(let i=0;i<n;i++) ts.push(makeTrade(day,tr,prod,{inst,notional:sizeFor(tr,0.5,1.6),dir:L,
    execMin:Math.min(1439,t0+i),captureLag:rand(0,2)}));
  const built=ts.reduce((a,t)=>a+t.notional,0);
  const back=randInt(9,29);
  const move=Math.abs(mktMove(inst,day,t0,Math.min(SESSION_CLOSE,t0+n)))+rand(4,14);
  const rev=makeTrade(day,tr,prod,{inst,notional:built*rand(0.92,1.06),dir:oppDir(L),execMin:Math.min(1439,t0+n+back)});
  rev.pnl=+(built*move*0.05).toFixed(1);
  return mkAlert(rule,day,tr,ts.concat([rev]),[
    ev("Instrument",prod+" · "+inst.name),
    ev("Burst",n+" × "+L+" inside "+n+" minutes from "+fmtTime(t0),true),
    ev("Notional built",fmtM(built),true),
    ev("Mid move over the burst","+"+move.toFixed(1)+" bps",true),
    ev("Reversal",rev.dir+" "+fmtM(rev.notional)+" at "+fmtTime(rev.execMin)+" — "+back+" minutes later",true),
    ev("Net position after the reversal","Nil",true),
    ev("P&L collected on the reversal",fmtK(rev.pnl),true),
    ev("Client order behind the burst","None recorded",true),
    ev("This trader's median ticket",fmtM(b.medSize)),
  ],n+" one-way prints moved the mid "+move.toFixed(0)+" bps and were reversed "+back+" minutes later for "+fmtK(rev.pnl));
};

PLANT["TS-32"]=function(rule){
  const tr=pickActor(rule), day=pickDayWeighted(), b=trBase(tr);
  const desk=DESK_BY_ID[tr.deskId], close=Math.round(DESK_HOURS[desk.region][1]*60);
  const prod=choice(tr.products), inst=instrumentFor(prod);
  const n=randInt(4,8), ts=[], L=rng()<0.5?longDir(prod):shortDir(prod);
  for(let i=0;i<n;i++) ts.push(makeTrade(day,tr,prod,{inst,notional:sizeFor(tr,0.9,3),dir:L,execMin:close-randInt(0,14)}));
  const lateVol=ts.reduce((a,t)=>a+t.notional,0);
  const dayVol=lateVol/rand(0.36,0.72);
  const move=Math.abs(mktMove(inst,day,close-15,close))+rand(2,7);
  ts.forEach(t=>{ t.pnl=bpValue(t.fam,t.notional,move); });
  return mkAlert(rule,day,tr,ts,[
    ev("Instrument",prod+" · "+inst.name),
    ev("This trader's session close",fmtTime(close)+" "+desk.region),
    ev("Trades in the final 15 minutes",String(n),true),
    ev("Notional in the window",fmtM(lateVol),true),
    ev("This trader's volume that day",fmtM(dayVol)),
    ev("Share of their own daily volume",fmtPct(lateVol/dayVol,1),true),
    ev("Rule threshold","35%"),
    ev("Direction","100% "+L+" — one-sided",true),
    ev("Closing mid move","+"+move.toFixed(1)+" bps",true),
    ev("Published benchmark window","None — this is not a fixing",false),
    ev("Mark-to-market effect on the book",fmtK(ts.reduce((a,t)=>a+t.pnl,0)),true),
  ],fmtPct(lateVol/dayVol,0)+" of this trader's day executed one-way into their own close, moving the mid "+move.toFixed(0)+" bps");
};

PLANT["TS-33"]=function(rule){
  const tr=pickActor(rule), day=pickDayWeighted(), b=trBase(tr);
  const cash=tr.products.filter(p=>FAM_MKT[PROD_BY_NAME[p].fam].omFloor>0);
  const prod=cash.length?choice(cash):"FX Spot";
  const inst=instrumentFor(prod);
  const clients=shuffle(COUNTERPARTIES.filter(c=>["Asset Manager","Corporate","Insurer","Private Client"].indexOf(c.type)>=0)).slice(0,2);
  const notional=sizeFor(tr,1.6,6), m=execMinFor(DESK_BY_ID[tr.deskId]), gap=randInt(1,5);
  const thr=Math.max(5,omThreshold(inst)*0.45);
  const bps=devFor(inst,rand(0.5,2.0)), L=longDir(prod);
  const a=makeTrade(day,tr,prod,{inst,notional,dir:L,ctpy:clients[0],execMin:m});
  const c=makeTrade(day,tr,prod,{inst,notional,dir:oppDir(L),ctpy:clients[1],execMin:m+gap});
  applyDev(a,bps);
  // A cross prints once: both clients get the same level, and it is off mid.
  c.mktPx=a.mktPx; c.px=a.px; c.devBps=devBpsOf(c.unit,c.px,c.mktPx);
  const xfer=bpValue(a.fam,notional,a.devBps);
  a.pnl=-xfer; c.pnl=xfer;
  const rel=RELATED_PARTIES[clients[1].name];
  return mkAlert(rule,day,tr,[a,c],[
    ev("Instrument",prod+" · "+inst.name),
    ev("Leg 1",a.dir+" "+fmtM(a.notional)+" · "+clients[0].name+" · "+fmtTime(a.execMin)),
    ev("Leg 2",c.dir+" "+fmtM(c.notional)+" · "+clients[1].name+" · "+fmtTime(c.execMin)),
    ev("Crossed at",px(a),true),
    ev("Market mid at the cross",mkt(a)),
    ev("Distance from mid",Math.abs(a.devBps).toFixed(1)+" bps",true),
    ev("Threshold for a cross in this name",thr.toFixed(1)+" bps"),
    ev("Client disadvantaged",clients[0].name+" — "+fmtK(Math.abs(a.pnl)),true),
    ev("Client advantaged",clients[1].name+" — "+fmtK(c.pnl),true),
    ev("Best-execution record","No evidence either client was shown the mid",true),
    ev("Related-party register",rel?"MATCH — "+rel:"No match",!!rel),
  ],"Two client orders crossed by "+tr.name+" at "+Math.abs(a.devBps).toFixed(0)+" bps off mid, moving "+fmtK(c.pnl)+" between them",
  {sev:rel?"Critical":"High"});
};

PLANT["TS-34"]=function(rule){
  const tr=pickActor(rule), day=pickDay(24,DAYS-1), b=trBase(tr);
  const L=tr.ticketLimit, n=randInt(10,16), ts=[];
  const prod=choice(tr.products), inst=instrumentFor(prod);
  for(let i=0;i<n;i++) ts.push(makeTrade(bizBack(day,randInt(0,19)),tr,prod,{inst,notional:L*rand(0.902,0.994)}));
  const tot=ts.reduce((a,t)=>a+t.notional,0);
  const lo=Math.min.apply(null,ts.map(t=>t.notional)), hi=Math.max.apply(null,ts.map(t=>t.notional));
  return mkAlert(rule,day,tr,ts,[
    ev("This trader's ticket authorisation",fmtM(L)+" ("+tr.grade+")"),
    ev("Tickets at 90–99.5% of that limit",n+" in 20 business days",true),
    ev("Size range",fmtM(lo)+" – "+fmtM(hi)+" — never once above",true),
    ev("Mean utilisation of their own limit",fmtPct(tot/n/L,1),true),
    ev("Tickets above the limit in 12 months","None",true),
    ev("This trader's median ticket",fmtM(b.medSize)),
    ev("Aggregate notional",fmtM(tot)),
    ev("Distribution shape","Truncated hard at the limit — not a natural size distribution",true),
    ev("Rule threshold","10 tickets in 20 business days"),
  ],n+" tickets sized between "+fmtPct(lo/L,0)+" and "+fmtPct(hi/L,0)+" of this trader's own authorisation, and none above it");
};

PLANT["TS-35"]=function(rule){
  const tr=pickActor(rule), b=trBase(tr);
  // A tenor cap can only be breached on a product written long-dated in the
  // first place, and only out as far as that product actually trades.
  const dated=tr.products.filter(p=>MAX_YEARS[p]>tr.tenorYrs);
  const prod=dated.length?choice(dated):"IRS";
  const day=pickDayWeighted(), inst=instrumentFor(prod);
  const room=[15,20,25,30,40,50].filter(y=>y>tr.tenorYrs&&y<=(MAX_YEARS[prod]||30));
  const yrs=room.length?choice(room):Math.min(MAX_YEARS[prod]||30,tr.tenorYrs+10);
  const t=makeTrade(day,tr,prod,{inst,notional:sizeFor(tr,0.8,4.5),tenor:yrs+"Y"});
  return mkAlert(rule,day,tr,[t],[
    ev("Trader",tr.name+" · "+tr.grade),
    ev("This trader's approved maximum tenor",tr.tenorYrs+" years"),
    ev("Tenor booked",yrs+" years",true),
    ev("Longest this product is written",(MAX_YEARS[prod]||30)+" years"),
    ev("Excess",(yrs-tr.tenorYrs)+" years beyond their own authority",true),
    ev("Product",prod+" · "+t.instrument),
    ev("Notional",fmtM(t.notional)),
    ev("Maturity",fmtDate(new Date(t.date.getTime()+yrs*365*dayMs)),true),
    ev("Tenor exception on file","None",true),
    ev("Supervisor sign-off",tr.supervisor+" — not evidenced",true),
  ],prod+" written to "+yrs+" years by a trader approved to "+tr.tenorYrs,
  {sev:yrs>tr.tenorYrs*3?"High":"Medium"});
};

PLANT["TS-36"]=function(rule){
  const tr=pickActor(rule), day=pickDayWeighted(), b=trBase(tr);
  const never=PRODUCTS.map(p=>p.p).filter(p=>b.products.indexOf(p)<0);
  const prod=never.length?choice(never):choice(PRODUCTS).p;
  const t=makeTrade(day,tr,prod,{notional:sizeFor(tr,2.2,9)});
  const onList=tr.products.indexOf(prod)>=0;
  return mkAlert(rule,day,tr,[t],[
    ev("Product",prod+" · "+t.instrument,true),
    ev("Prior trades in this product by this trader","None in 12 months",true),
    ev("Products this trader does trade",b.products.slice(0,6).join(", ")+(b.products.length>6?" +"+(b.products.length-6)+" more":"")),
    ev("Notional",fmtM(t.notional)+" — "+xBase(t.notional,b.medSize)+" their median ticket",true),
    ev("Rule threshold","2× the trader's own median ticket"),
    ev("On this trader's approved list",onList?"Yes":"No",!onList),
    ev("Counterparty",t.ctpy+" · "+t.ctpyType),
    ev("Booked to",t.book),
    ev("Product sign-off record for this trader","Not evidenced",true),
  ],"First "+prod+" this trader has booked in 12 months, entered at "+xBase(t.notional,b.medSize)+" their median ticket",
  {sev:onList?"Medium":"High"});
};

PLANT["TS-37"]=function(rule){
  const tr=pickActor(rule), b=trBase(tr);
  const lead=randInt(1,3);
  let day=Math.max(4,Math.min(DAYS-1,tr.leave[0]-lead));
  for(let i=0;i<10&&!isBiz(dateForIdx(day));i++) day=Math.max(4,day-1);
  const n=Math.max(4,Math.round(b.tickets*rand(2.6,4.4)));
  const ts=ensureTrades(tr,day,Math.min(n,9));
  const tot=ts.reduce((a,t)=>a+t.notional,0)*(n/Math.max(1,ts.length));
  const cover=(DESK_BY_ID[tr.deskId].traders.filter(x=>x.id!==tr.id)[0]||tr).name;
  return mkAlert(rule,day,tr,ts,[
    ev("Block leave window",fmtDate(dateForIdx(tr.leave[0]))+" – "+fmtDate(dateForIdx(tr.leave[1])),true),
    ev("Activity date",fmtDate(dateForIdx(day))+" — "+lead+" business day"+(lead>1?"s":"")+" before leave",true),
    ev("Tickets booked",String(n),true),
    ev("This trader's 90-day daily mean",b.tickets.toFixed(1)+" tickets"),
    ev("Surge versus their own baseline",xBase(n,b.tickets),true),
    ev("Notional",fmtM(tot),true),
    ev("Positions left open over the leave",randInt(2,9)+" deals",true),
    ev("Handover note to the cover trader","Not on file",true),
    ev("Cover trader",cover),
  ],n+" tickets booked "+lead+" day"+(lead>1?"s":"")+" before block leave — "+xBase(n,b.tickets)+" this trader's own daily average");
};

PLANT["TS-38"]=function(rule){
  const tr=pickActor(rule), day=pickDayWeighted(), b=trBase(tr);
  const z=rand(3.05,6.8);
  const target=b.dayNotional+z*Math.max(1,b.dayNotionalSd);
  const n=randInt(3,6), ts=ensureTrades(tr,day,n), share=target/n;
  ts.forEach(t=>{ t.notional=share*rand(0.7,1.3); });
  const tot=ts.reduce((a,t)=>a+t.notional,0);
  const deskDay=b.dayNotional*DESK_BY_ID[tr.deskId].traders.length*rand(2.6,4);
  return mkAlert(rule,day,tr,ts,[
    ev("Trading day",fmtDate(dateForIdx(day))),
    ev("Notional booked",fmtM(tot),true),
    ev("This trader's 90-day daily mean",fmtM(b.dayNotional)),
    ev("This trader's 90-day σ",fmtM(b.dayNotionalSd)),
    ev("z-score against their own book",z.toFixed(2),true),
    ev("Rule threshold","3.00"),
    ev("Same day measured at desk level",fmtPct(tot/Math.max(tot,deskDay),1)+" of the desk's notional — invisible in a pooled view",true),
    ev("Market event that session","None scheduled"),
    ev("Tickets",n+" · "+uniq(ts.map(t=>t.product)).join(", ")),
  ],fmtM(tot)+" booked in one day — "+z.toFixed(1)+"σ outside this trader's own distribution");
};

PLANT["TS-39"]=function(rule){
  const tr=pickActor(rule), day=pickDayWeighted(), b=trBase(tr);
  const window=40;
  const own=b.lossDays;
  const lossPct=own*rand(0.10,0.32);   // a third of their own rate, or less
  const ts=ensureTrades(tr,day,randInt(2,4));
  ts.forEach(t=>{ t.pnl=Math.abs(t.pnl)||+rand(20,180).toFixed(1); });
  return mkAlert(rule,day,tr,ts,[
    ev("Window","40 business days to "+fmtDate(dateForIdx(day))),
    ev("Losing days in the window",Math.round(window*lossPct)+" of "+window+" ("+fmtPct(lossPct,1)+")",true),
    ev("This trader's own 12-month rate",fmtPct(own,1)+" losing days"),
    ev("Peer cohort ("+tr.cohort+")",fmtPct(Math.max(0.28,b.cohort.lossDays),1)),
    ev("Rule threshold","below a third of the trader's own 12-month rate"),
    ev("Book risk over the window","Unchanged — position size and VaR in line",true),
    ev("Unrealised versus realised","Gains realised; losses left unrealised",true),
    ev("Independent price verification","2 positions carry manual marks",true),
    ev("This trader's daily P&L σ",fmtK(b.pnlSd)),
  ],"Only "+plural(Math.round(window*lossPct),"losing day")+" in 40, against this trader's own 12-month rate of "+fmtPct(own,0));
};

PLANT["TS-40"]=function(rule){
  const tr=pickActorWith(rule,x=>x.products.some(p=>MODELLED.indexOf(p)>=0));
  const day=pickDayWeighted(), b=trBase(tr);
  const structured=tr.products.filter(p=>MODELLED.indexOf(p)>=0);
  const prod=structured.length?choice(structured):"Swaption";
  const t=makeTrade(day,tr,prod,{notional:sizeFor(tr,1.4,6)});
  const pctNot=rand(2.65,5.2);
  t.pnl=+(t.notional*10*pctNot).toFixed(1);
  return mkAlert(rule,day,tr,[t],[
    ev("Structure",prod+" · "+t.instrument+" · "+t.tenor),
    ev("Notional",fmtM(t.notional)),
    ev("Day-one P&L recognised",fmtK(t.pnl),true),
    ev("As % of notional",pctNot.toFixed(2)+"%",true),
    ev("Model tolerance","2.50% of notional"),
    ev("Pricing input driving it",choice(["Correlation input outside the observed range",
      "Vol surface point interpolated beyond the last quote","Dividend assumption not in the market data set",
      "Recovery rate overridden manually"]),true),
    ev("Independent model validation","Not performed on this trade",true),
    ev("Counterparty",t.ctpy+" · "+t.ctpyType),
    ev("Day-one reserve held","None",true),
  ],prod+" booking "+pctNot.toFixed(1)+"% of notional as day-one profit against a 2.5% model tolerance");
};

PLANT["TS-41"]=function(rule){
  const tr=pickActor(rule), b=trBase(tr);
  const me=choice(MONTH_END_REV);
  const gain=rand(650,4200), backDay=bizFwd(me,randInt(1,3));
  const ts=ensureTrades(tr,backDay,randInt(2,4));
  const giveback=-gain*rand(0.72,0.98);
  ts.forEach(t=>{ t.pnl=+(giveback/ts.length).toFixed(1); });
  return mkAlert(rule,backDay,tr,ts,[
    ev("Valuation date",fmtDate(dateForIdx(me))+" — month end"),
    ev("P&L reported by this trader at the close",fmtK(gain),true),
    ev("Losses in the 3 days after",fmtK(giveback),true),
    ev("Give-back ratio",fmtPct(Math.abs(giveback)/gain,0)+" of the reported gain",true),
    ev("Rule threshold","70%"),
    ev("Positions involved","The same instruments that carried the month-end mark",true),
    ev("Market move over the period",rand(-0.3,0.35).toFixed(2)+"% — does not explain the reversal",true),
    ev("This trader's daily P&L σ",fmtK(b.pnlSd)),
    ev("Prior occurrences",randInt(2,5)+" of the last 12 month ends",true),
  ],fmtK(gain)+" reported at the month-end close and "+fmtPct(Math.abs(giveback)/gain,0)+" of it given back within three days");
};

PLANT["TS-42"]=function(rule){
  const tr=pickActor(rule), day=pickDayWeighted(), b=trBase(tr);
  const t=ensureTrades(tr,day,1)[0];
  t.ssiChanged=true; t.status="Amended"; t.amends=Math.max(1,t.amends);
  t.notional=Math.max(t.notional,sizeFor(tr,1.5,6));
  const n=randInt(2,3), shares=[]; let rem=100;
  for(let i=0;i<n-1;i++){ const s=Math.round(rand(15,rem-15)); shares.push(s); rem-=s; }
  shares.push(rem);
  const third=choice(["Northgate Clearing SA","Aurora Trust Bank","Continental Escrow NV","Pallas Financial Ltd"]);
  return mkAlert(rule,day,tr,[t],[
    ev("Trade",t.id+" · "+t.product+" · "+fmtM(t.notional)),
    ev("Counterparty",t.ctpy+" · "+t.ctpyType+" · "+t.ctpyCountry),
    ev("Settlement accounts used",String(n),true),
    ev("Split",shares.map(s=>s+"%").join(" / "),true),
    ev("Accounts on the counterparty static record","One"),
    ev("Additional destination",third+" — not on the static record",true),
    ev("Amount to the unregistered account",fmtM(t.notional*shares[shares.length-1]/100),true),
    ev("Instruction amended by","Front office — "+tr.name,true),
    ev("Counterparty confirmation of the split","Not on file",true),
  ],fmtM(t.notional)+" settled across "+n+" accounts, one of which is not on the counterparty's static record");
};

PLANT["TS-43"]=function(rule){
  const tr=pickActor(rule), day=pickDayWeighted(), b=trBase(tr);
  const t=ensureTrades(tr,day,1)[0];
  t.ssiChanged=true;
  t.notional=Math.max(t.notional,sizeFor(tr,1.2,5));
  const jur=choice(HIGH_RISK_JUR);
  const bank=choice(["Northgate Clearing SA","Aurora Trust Bank","Continental Escrow NV","Pallas Financial Ltd","Meridian Offshore Ltd"]);
  return mkAlert(rule,day,tr,[t],[
    ev("Trade",t.id+" · "+t.product+" · "+fmtM(t.notional)),
    ev("Counterparty",t.ctpy+" · "+t.ctpyType),
    ev("Counterparty domicile",t.ctpyCountry),
    ev("Settlement routed through",bank+" ("+jur[0]+")",true),
    ev("Jurisdiction risk rating",jur[1],true),
    ev("Connection to the counterparty","None documented",true),
    ev("Financial crime screening","Passed on the counterparty name only — not on the payment route",true),
    ev("Booked by",tr.name+" · "+tr.grade),
    ev("Value at risk of diversion",fmtM(t.notional),true),
  ],fmtM(t.notional)+" routed through "+jur[0]+", unconnected to a "+t.ctpyCountry+" counterparty");
};

PLANT["TS-44"]=function(rule){
  const tr=pickActor(rule), day=pickDay(4,DAYS-8), b=trBase(tr);
  const n=randInt(2,5), ts=ensureTrades(tr,day,n);
  const aged=randInt(6,31), own=Math.max(0.8,b.tickets*0.06);
  ts.forEach(t=>{ t.status="Live"; });
  return mkAlert(rule,Math.min(DAYS-1,day+aged),tr,ts,[
    ev("Deals outstanding",String(n),true),
    ev("Oldest unconfirmed",aged+" business days",true),
    ev("Policy deadline","5 business days"),
    ev("This trader's 12-month unconfirmed average",own.toFixed(1)+" open at any time"),
    ev("Current count versus their own rate",xBase(n,own),true),
    ev("Aggregate notional",fmtM(ts.reduce((a,t)=>a+t.notional,0)),true),
    ev("Counterparties",uniq(ts.map(t=>t.ctpy)).join(", ")),
    ev("Chaser record","No chase sent by the desk",true),
    ev("Counterparty acknowledgement","No record of these trades on their side",true),
  ],n+" deals still unconfirmed after "+aged+" business days — "+xBase(n,own)+" this trader's normal open count");
};

PLANT["TS-45"]=function(rule){
  const tr=pickActor(rule), day=pickDayWeighted(), b=trBase(tr);
  const prod=choice(tr.products), inst=instrumentFor(prod);
  const clients=shuffle(COUNTERPARTIES.filter(c=>["Asset Manager","Insurer","Private Client"].indexOf(c.type)>=0)).slice(0,2);
  const m=execMinFor(DESK_BY_ID[tr.deskId]), block=sizeFor(tr,3,9);
  const good=makeTrade(day,tr,prod,{inst,notional:block*rand(0.30,0.45),ctpy:clients[0],execMin:m});
  const rest=makeTrade(day,tr,prod,{inst,notional:block-good.notional,ctpy:clients[1],execMin:m});
  const edge=rand(8.5,34), hrs=rand(1.5,9);
  applyDev(good,-edge);
  const rel=RELATED_PARTIES[clients[0].name];
  return mkAlert(rule,day,tr,[good,rest],[
    ev("Block executed",fmtM(block)+" "+prod+" at "+fmtTime(m)),
    ev("Allocation amended",hrs.toFixed(1)+" hours after execution",true),
    ev("Account receiving the best fills",clients[0].name+" · "+fmtM(good.notional),true),
    ev("Account receiving the remainder",clients[1].name+" · "+fmtM(rest.notional)),
    ev("Fill advantage to the first account",edge.toFixed(1)+" bps against the block average",true),
    ev("Rule threshold","8.0 bps"),
    ev("Allocation instruction timestamp","After the market had moved",true),
    ev("Pre-trade allocation on file","None",true),
    ev("Related-party register",rel?"MATCH — "+rel:"No match",!!rel),
  ],"Block allocated "+hrs.toFixed(0)+"h after execution with the best fills going to "+clients[0].name);
};

PLANT["TS-46"]=function(rule){
  const tr=pickActor(rule), day=pickDay(24,DAYS-1), b=trBase(tr);
  const ctpy=rng()<0.35?{name:choice(Object.keys(RELATED_PARTIES)),type:"Private Client",country:"Singapore"}:choice(COUNTERPARTIES);
  const prod=choice(tr.products), inst=instrumentFor(prod);
  const n=randInt(9,18), ts=[];
  for(let i=0;i<n;i++) ts.push(makeTrade(bizBack(day,randInt(0,19)),tr,prod,{inst,notional:sizeFor(tr,0.6,2.6),ctpy}));
  const share=rand(tr.ctpyCap+0.06,0.84), total=Math.round(n/share);
  const rel=RELATED_PARTIES[ctpy.name];
  return mkAlert(rule,day,tr,ts,[
    ev("Counterparty",ctpy.name+" · "+ctpy.type,true),
    ev("Tickets to this name (20 business days)",n+" of "+total,true),
    ev("Share of this trader's flow",fmtPct(share,1),true),
    ev("This trader's concentration cap",fmtPct(tr.ctpyCap,0)+" ("+tr.grade+")"),
    ev("This trader's 12-month mix",fmtPct(b.topCtpyShare,1)+" to their largest name ("+b.topCtpy+")"),
    ev("Peer cohort ("+tr.cohort+")",fmtPct(b.cohort.topCtpyShare,1)+" median"),
    ev("Counterparties this trader normally faces",String(b.ctpyCount)),
    ev("Notional to this name",fmtM(ts.reduce((a,t)=>a+t.notional,0))),
    ev("Related-party register",rel?"MATCH — "+rel:"No match",!!rel),
  ],fmtPct(share,0)+" of this trader's tickets over 20 days went to "+ctpy.name+", against a cap of "+fmtPct(tr.ctpyCap,0),
  {sev:rel?"High":"Medium"});
};

PLANT["TS-47"]=function(rule){
  const tr=pickActor(rule), day=pickDayWeighted(), b=trBase(tr);
  const r=choice(RESTRICTED);
  const creditBooks=tr.products.filter(p=>["cds","bondc","trs"].indexOf(PROD_BY_NAME[p].fam)>=0);
  const prod=creditBooks.length?choice(creditBooks):choice(tr.products);
  // The restricted name replaces the ticket label only — the shared instrument
  // in the universe keeps its own identity and its own price path.
  const pool=(INST_BY_FAM[PROD_BY_NAME[prod].fam]||[]).filter(x=>x.name.indexOf(r[0])>=0);
  const inst=pool.length?choice(pool):instrumentFor(prod);
  const label=prod.indexOf("CDS")>=0?r[0]+" 5Y CDS":prod.indexOf("Bond")>=0?r[0]+" "+rand(3.5,7).toFixed(2)+"% 2031":"TRS on "+r[0];
  const n=randInt(1,3), ts=[];
  for(let i=0;i<n;i++) ts.push(makeTrade(day,tr,prod,{inst,label,notional:sizeFor(tr,1,5)}));
  const tot=ts.reduce((a,t)=>a+t.notional,0);
  const listed=Math.max(0,day-randInt(6,50));
  return mkAlert(rule,day,tr,ts,[
    ev("Name",r[0],true),
    ev("Restricted list status","On the list since "+fmtDate(dateForIdx(listed))+" — "+r[1],true),
    ev("Trades booked",n+" · "+fmtM(tot),true),
    ev("Instrument",label),
    ev("Wall-crossing record for this trader","None",true),
    ev("Personal-account declaration","No holding declared in this name"),
    ev("Prior activity by this trader in the name","None in 12 months",true),
    ev("Pre-trade restricted-list check","Not evidenced — booked through "+ts[0].channel,true),
    ev("Counterparty",ts[0].ctpy),
  ],n+" trade"+(n>1?"s":"")+" in "+r[0]+" while the name sat on the restricted list, with no wall-crossing record for this trader");
};

PLANT["TS-48"]=function(rule){
  const tr=pickActor(rule), b=trBase(tr);
  const annDay=pickDay(80,DAYS-2), lead=randInt(1,5);
  const exitDay=bizBack(annDay,lead), openDay=bizBack(exitDay,randInt(20,45));
  // An announcement belongs to a company. An index future has no issuer to make
  // one, so this rule only runs on single names.
  const books=tr.products.filter(p=>["cds","bondc","trs"].indexOf(PROD_BY_NAME[p].fam)>=0);
  const prod=books.length?choice(books):"Corp Bond";
  const pool=(INST_BY_FAM[PROD_BY_NAME[prod].fam]||[]).filter(x=>EQ_INDICES.indexOf(x.name)<0);
  const inst=pool.length?choice(pool):instrumentFor(prod);
  const notional=sizeFor(tr,1.6,7), L=longDir(prod);
  const open=makeTrade(openDay,tr,prod,{inst,notional,dir:L});
  const exit=makeTrade(exitDay,tr,prod,{inst,notional:notional*rand(0.99,1.01),dir:oppDir(L)});
  const avoided=rand(480,3600);
  const news=choice([["profit warning","Company announcement"],["rating downgrade","S&P / Moody's action"],
    ["withdrawal of guidance","Exchange filing"],["disclosed regulatory penalty","Exchange filing"],
    ["confirmed covenant breach","Trustee notice"]]);
  const held=BIZ_DAYS.indexOf(exitDay)-BIZ_DAYS.indexOf(openDay);
  const nameOnly=inst.name.replace(/ 5Y CDS| \d.*$/,"").replace(/^TRS on /,"");
  return mkAlert(rule,exitDay,tr,[open,exit],[
    ev("Name",nameOnly),
    ev("Position opened",fmtDate(dateForIdx(openDay))+" · "+open.dir+" "+fmtM(notional)),
    ev("Held for",held+" business days",true),
    ev("Position closed",fmtDate(dateForIdx(exitDay))+" · "+exit.dir+" "+fmtM(exit.notional),true),
    ev("Announcement",news[0].charAt(0).toUpperCase()+news[0].slice(1)+" · "+news[1]),
    ev("Announcement date",fmtDate(dateForIdx(annDay))+" — "+plural(lead,"business day")+" later",true),
    ev("Loss avoided by exiting",fmtK(avoided),true),
    ev("Reason for the exit recorded","None — no hedge, no limit, no client order",true),
    ev("This trader's usual holding period",randInt(35,90)+" business days in this book"),
    ev("Wall-crossing / restricted list check","Name not on the restricted list at the time"),
  ],"A "+plural(held,"business day")+" "+nameOnly+" position closed "+plural(lead,"day")+" before a "+news[0]+", avoiding "+fmtK(avoided));
};

PLANT["TS-49"]=function(rule){
  const tr=pickActorWith(rule,x=>x.products.some(p=>PROD_BY_NAME[p].fam==="repo"));
  const day=pickDayWeighted(), b=trBase(tr);
  const prod=tr.products.filter(p=>PROD_BY_NAME[p].fam==="repo")[0]||"Repo";
  const name=choice(Object.keys(RELATED_PARTIES));
  const t=makeTrade(day,tr,prod,{notional:sizeFor(tr,1.5,7),ctpy:{name,type:"Private Client",country:"Singapore"}});
  const bps=devFor(INST_BY_KEY[t.instKey],rand(1.2,4.5));
  applyDev(t,bps);
  t.pnl=-bpValue(t.fam,t.notional,t.devBps);
  const gc=rand(3.9,4.6);
  return mkAlert(rule,day,tr,[t],[
    ev("Financing",fmtM(t.notional)+" "+prod+" · "+t.tenor),
    ev("Counterparty",name,true),
    ev("Related-party register",RELATED_PARTIES[name],true),
    ev("Repo rate applied",(gc+bps/100).toFixed(3)+"%",true),
    ev("General collateral level",gc.toFixed(3)+"%"),
    ev("Difference",bps.toFixed(1)+" bps away from GC",true),
    ev("Rule threshold","15.0 bps"),
    ev("Direction of benefit","The counterparty",true),
    ev("Value transferred over the term",fmtK(Math.abs(t.pnl)),true),
    ev("Conflicts declaration by this trader","Does not disclose this counterparty",true),
  ],prod+" with "+name+" struck "+bps.toFixed(0)+" bps away from GC — the name is on the related-party register");
};

PLANT["TS-50"]=function(rule){
  const tr=pickActorWith(rule,x=>x.products.some(p=>PROD_BY_NAME[p].fam==="repo")), b=trBase(tr);
  const qe=choice(QUARTER_END);
  const outDay=bizBack(qe,randInt(1,2)), backDay=bizFwd(qe,randInt(1,5));
  const prod=tr.products.filter(p=>PROD_BY_NAME[p].fam==="repo")[0]||"Repo";
  const notional=sizeFor(tr,3,11);
  const a=makeTrade(outDay,tr,prod,{notional,dir:"Lend"});
  const c=makeTrade(backDay,tr,prod,{notional:notional*rand(0.99,1.01),dir:"Borrow"});
  const from=choice(["BB- corporate paper","B+ airline paper","unrated structured notes","BB property paper"]);
  const to=choice(["US Treasury 5Y","Bund 10Y","SGS 10Y","UK Gilt 5Y"]);
  return mkAlert(rule,outDay,tr,[a,c],[
    ev("Reporting date",fmtDate(dateForIdx(qe))+" — quarter end",true),
    ev("Collateral before substitution",from,true),
    ev("Collateral held over the reporting date",to,true),
    ev("Substituted",fmtDate(dateForIdx(outDay))+" — "+(BIZ_DAYS.indexOf(qe)-BIZ_DAYS.indexOf(outDay))+" business days before",true),
    ev("Reversed",fmtDate(dateForIdx(backDay))+" — "+(BIZ_DAYS.indexOf(backDay)-BIZ_DAYS.indexOf(qe))+" business days after",true),
    ev("Notional",fmtM(notional)),
    ev("Haircut reported over the date",rand(0.5,2).toFixed(1)+"% — against "+rand(8,18).toFixed(1)+"% on the paper actually held",true),
    ev("Business rationale documented","None",true),
    ev("Prior occurrences",randInt(2,4)+" of the last 8 quarters",true),
  ],"Collateral swapped from "+from+" into "+to+" across the quarter end and swapped straight back");
};

/* The plant and noise counts were tuned against a floor of 33. Scaling them with
   the roster holds alerts-per-trader steady as the floor grows, so the heatmap
   keeps its density and every per-trader baseline keeps its shape — a bigger
   desk should mean more alerts, not the same alerts spread thinner. */
const FLOOR_SCALE=TRADERS.length/33;
const scaled=n=>Math.max(1,Math.round(n*FLOOR_SCALE));

RULES.forEach(r=>{ if(r.stream) return; const f=PLANT[r.id]; for(let i=0;i<scaled(r.plants);i++) f(r); });

/* Background noise: ordinary trades that happen to sit just past a threshold.
   Without them every alert would be a genuine pattern, and the officer's job —
   telling a real signal from a benign one — would not exist. */
(function backgroundHits(){
  const NOISY=[["TS-02",90],["TS-08",55],["TS-03",40],["TS-07",25],["TS-13",30],["TS-01",28],["TS-06",18],["TS-15",14],
               ["TS-25",34],["TS-28",30],["TS-38",30],["TS-44",26],["TS-46",24],["TS-36",22],["TS-24",22],["TS-35",18],
               ["TS-27",16],["TS-34",14],["TS-32",12],["TS-21",12]];
  NOISY.forEach(pair=>{
    const rule=RULE_BY_ID[pair[0]];
    for(let i=0;i<scaled(pair[1]);i++){
      const tr=weightedChoice(TRADERS.map(t=>[t,1]));
      const day=pickDayWeighted();
      const t=ensureTrades(tr,day,1)[0];
      let evs, sum;
      if(rule.id==="TS-02"){
        t.captureLag=Math.round(rand(31,95));
        evs=[ev("Capture lag",t.captureLag+" minutes",true),ev("Policy threshold","30 minutes"),
             ev("Execution",fmtTime(t.execMin)+" "+t.region),ev("Booking channel",t.channel),
             ev("Notional",fmtM(t.notional)),ev("Product",t.product+" · "+t.instrument),
             ev("Known feed incident that session",rng()<0.5?"Yes — "+t.channel+" gateway latency":"None")];
        sum="Capture lag of "+t.captureLag+" minutes, just past the 30-minute policy threshold";
      }else if(rule.id==="TS-08"){
        const h=DESK_HOURS[t.region];
        t.execMin=Math.round(rng()<0.5?h[0]*60-rand(95,150):h[1]*60+rand(95,170));
        evs=[ev("Booking timestamp",fmtTime(t.execMin)+" "+t.region,true),ev("Desk hours",fmtTime(h[0]*60)+" – "+fmtTime(h[1]*60)),
             ev("Calendar status","Business day"),ev("Product / notional",t.product+" · "+fmtM(t.notional)),
             ev("Counterparty",t.ctpy),ev("Counterparty time zone",t.ctpyCountry)];
        sum=t.product+" booked at "+fmtTime(t.execMin)+" "+t.region+", outside desk hours";
      }else if(rule.id==="TS-03"){
        t.amends=randInt(3,4); t.status="Amended";
        evs=[ev("Amendments on this deal",String(t.amends),true),ev("Rule threshold","3"),
             ev("Fields amended",choice(["Value date","Counterparty entity","Settlement account","Tenor, then value date"])),
             ev("Notional",fmtM(t.notional)),ev("Product",t.product),ev("Price changed by amendment",rng()<0.25?"Yes":"No")];
        sum=t.amends+" amendments on a single "+t.product+" deal";
      }else if(rule.id==="TS-07"){
        evs=[ev("Desk",t.deskName),ev("Product booked",t.product,true),
             ev("Desk approved products",DESK_BY_ID[t.deskId].mandate.join(", ")),
             ev("Mandate exception on file",rng()<0.5?"Yes — temporary cover approval":"None"),
             ev("Notional",fmtM(t.notional)),ev("Counterparty",t.ctpy)];
        sum=t.product+" booked on "+t.deskShort+", outside the approved product list";
      }else if(rule.id==="TS-13"){
        const z=rand(3.0,3.9), sd=rand(30,70);
        t.pnl=+(z*sd).toFixed(1);
        evs=[ev("Daily P&L",fmtK(t.pnl),true),ev("Trailing 60-day σ",fmtK(sd)),ev("z-score",z.toFixed(2),true),
             ev("Rule threshold","3.00"),ev("Volume that day","Elevated — "+randInt(2,4)+"× normal ticket count"),
             ev("Market move in underlying",rand(0.6,1.9).toFixed(2)+"% — consistent with the P&L")];
        sum="Daily P&L "+z.toFixed(1)+"σ above the trader's own distribution";
      }else if(rule.id==="TS-01"){
        const inst=INST_BY_KEY[t.instKey];
        if(!inst||!priceTested(inst)) continue;
        const thr=omThreshold(inst);
        applyDev(t,devFor(inst,rand(1.02,1.34)));
        evs=[ev("Traded price",px(t),true),ev("Market mid",mkt(t)),
             ev("Deviation",Math.abs(t.devBps).toFixed(1)+" bps",true),
             ev("Materiality threshold for this name",thr.toFixed(1)+" bps"),
             ev("Normal dealing spread",inst.spreadBps.toFixed(2)+" bps"),
             ev("Notional",fmtM(t.notional)),ev("Counterparty",t.ctpy+" · "+t.ctpyType),
             ev("Liquidity at execution",choice(["Thin — post-close hours","Normal","Thin — event risk in the name"]))];
        sum="Trade "+Math.abs(t.devBps).toFixed(0)+" bps off mid in "+t.instrument+", marginally past its "+thr.toFixed(0)+" bps threshold";
      }else if(rule.id==="TS-06"){
        const L=tr.ticketLimit;
        t.notional=L*rand(0.904,0.996);
        evs=[ev("Ticket size",fmtM(t.notional),true),ev("This trader's authorisation",fmtM(L)+" ("+tr.grade+")"),
             ev("Ticket as % of their own limit",(t.notional/L*100).toFixed(1)+"%",true),
             ev("Other tickets in the window",String(randInt(2,3))),ev("Instrument",t.product+" · "+t.instrument),
             ev("Client order size",fmtM(t.notional*randInt(2,3))+" — split per client instruction")];
        sum="Tickets sized just under this trader's own "+fmtM(L)+" authorisation";
      }else if(rule.id==="TS-15"){
        const d=rand(2.0,2.6);
        t.vol=t.mktVol!=null?+(t.mktVol+d).toFixed(2):null;
        evs=[ev("Quoted volatility",(t.vol||0).toFixed(2)+" vols",true),ev("Surface",(t.mktVol||0).toFixed(2)+" vols"),
             ev("Deviation","+"+d.toFixed(2)+" vols",true),ev("Rule threshold","±2.00 vols"),
             ev("Notional",fmtM(t.notional)),ev("Structure",t.instrument),
             ev("Surface staleness","Surface last refreshed "+randInt(3,9)+"h before execution")];
        sum="Option quoted "+d.toFixed(1)+" vols off a surface last refreshed hours earlier";
      }else{
        // The trader-baseline rules produce their own kind of benign hit: a name
        // sitting fractionally the wrong side of their own threshold on a busy
        // day, with an ordinary explanation sitting behind it.
        const b2=trBase(tr), over=rand(1.02,1.31);
        evs=[ev("Trade / product",t.id+" · "+t.product+" · "+t.instrument),
             ev("Notional",fmtM(t.notional)),
             ev("Measured against",rule.base),
             ev("This trader's own baseline",fmtM(b2.medSize)+" median ticket · "+b2.tickets.toFixed(1)+" tickets a day · "+fmtNum(b2.deals)+" deals in 12 months"),
             ev("Exceedance","×"+over.toFixed(2)+" of this trader's own threshold — marginal",true),
             ev("Rule test",rule.logic),
             ev("Context on the day",choice(["Month-end roll — the whole cohort ran hot",
               "Single client order worked in pieces, instruction on file",
               "Covering for a colleague on block leave",
               "Quarterly index rebalance in the underlying",
               "System failover — tickets re-entered by hand"]))];
        sum=rule.name+" — this trader ran ×"+over.toFixed(2)+" over their own threshold, marginally past the test";
      }
      const al=mkAlert(rule,day,tr,[t],evs,sum,{sev:rule.sev==="Critical"?"High":rule.sev==="High"?"Medium":"Low",scoreAdj:-12});
      al.noise=true;   // benign by construction — these are the ones that get passed
    }
  });
})();

/* Chronological ids, so an alert number reads as a position in the year. */
ALERTS.sort((a,b)=>a.day-b.day||SEV_RANK[b.sev]-SEV_RANK[a.sev]||a.ruleId.localeCompare(b.ruleId));
ALERTS.forEach((a,i)=>{ a.id="ALT-"+String(i+1).padStart(5,"0"); a.n=i; });
const ALERT_BY_ID={}; ALERTS.forEach(a=>ALERT_BY_ID[a.id]=a);

/* Revenue is assigned here rather than beside the model, because the pattern
   generators above add trades of their own — a wash pair, a split ticket, a
   layered burst — and a pass that ran before them would leave every planted
   deal earning nothing.

   Client revenue plus the risk the desk carried. The second term is what makes
   a P&L chart look like a P&L chart rather than a rescaled volume chart: a desk
   that warehouses risk has losing days, and a trader whose every month is a
   clean multiple of their turnover is not running a book. It is seeded, so the
   same deal gives the same answer on every reload.

   On a stream of its own. This pass was added after the review history below
   was written, and drawing its sixty thousand numbers from the shared stream
   reshuffled every seeded disposition and the prior-year series that follow
   it — the same alerts, decided differently. */
withStream(20260917,()=>{
  TRADES.forEach(t=>{
    const client=dealRevenue(t);
    // Wide enough to turn a ticket negative: a desk that warehouses risk loses
    // money on some of it, and a book where every deal earns is not a book.
    const risk=client*rand(-1.6,1.75)*0.80;
    t.clientRevenue=+client.toFixed(3);
    t.revenue=+(client+risk).toFixed(3);
  });
});
