/* ============================================================
   DEMO DATA — revenue and margin alerts (TS-51 … TS-58)
   The eight revenue rules test what the desk charged its clients, so they can
   only be planted once every deal carries revenue — which is after the alert
   construction above and after the review history has been seeded.

   Three things keep the rest of the book exactly as it was:
     · They draw from a random stream of their own (withStream). Every draw
       taken from the shared one would shift the prior-year series generated
       after it, and the existing alerts would quietly change underneath.
     · The figures each alert is measured against — a trader's own margin,
       what comparable clients pay, the cohort's rate — are taken once, from
       the book before any of these patterns is planted.
     · A pattern claims the trader and the days it occupies. No later pattern
       may touch the same trader inside that window, so the revenue an alert's
       evidence quotes is still the revenue on the deals when the page renders.
   Their alerts are numbered after the existing ones, as a newly deployed rule's
   would be: the ids already in the queue, and any decision recorded against
   one, stay where they were.
============================================================ */
/* trade id -> {c,r} as the deal stood before a pattern changed it; created
   deals are marked so a check can rebuild the unplanted book. */
const REV_ORIG=new Map();
(function revenueAlerts(){
withStream(20261015,()=>{
  const isExt=t=>!t.internal&&t.channel!=="Internal booking";
  const mgn=(rev,nl)=>nl>0?rev*1000/nl:0;        // revenue $k over notional $m → $ per $1m
  const mg=v=>"$"+fmtNum(Math.round(v))+" per $1m";
  const sum=(a,f)=>a.reduce((x,t)=>x+f(t),0);
  const med=a=>{ const x=a.slice().sort((p,q)=>p-q), n=x.length; return n?(n%2?x[n>>1]:(x[n/2-1]+x[n/2])/2):0; };
  const xf=v=>v.toFixed(1)+"×";
  // The window an alert was measured over, stated so the figures can be rebuilt.
  const win=(lo,hi,n)=>fmtDate(dateForIdx(lo))+" – "+fmtDate(dateForIdx(hi))+" · "+n+" business days";
  const ELEC=["eComm single-dealer","Multi-dealer platform","API / Algo"];
  const EXT_CH=CHANNELS.filter(c=>c[0]!=="Internal booking");
  const CT=Object.create(null); COUNTERPARTIES.forEach(c=>{ CT[c.name]=c; });
  const NB=BIZ_DAYS.length;
  const bizIx=d=>BIZ_DAYS.indexOf(d);
  const calSum=(m,lo,hi)=>{ let x=0; for(let d=lo;d<=hi;d++) x+=m[d]||0; return x; };
  const monthBiz=me=>{ const dt=dateForIdx(me), ym=dt.getFullYear()*12+dt.getMonth();
    return BIZ_DAYS.filter(d=>{ const x=dateForIdx(d); return x.getFullYear()*12+x.getMonth()===ym; }); };
  const tradesIn=(tr,lo,hi,f)=>{
    const out=[];
    for(let d=lo;d<=hi;d++) (byTraderDay.get(tr.id+"|"+d)||[]).forEach(t=>{ if(!f||f(t)) out.push(t); });
    return out;
  };

  /* ---- what each alert is measured against, from the unplanted book ---- */
  const RB={}; TRADERS.forEach(tr=>{ RB[tr.id]={c:0,nl:0,n:0,day:{},risk:{},fo:{},cli:{}}; });
  const C3={}, C2={}, C1={}, COH={}, TP={}, TPT={}, TPTC={};
  const add=(m,k,c,nl)=>{ const o=m[k]||(m[k]={c:0,nl:0}); o.c+=c; o.nl+=nl; };
  TRADES.forEach(t=>{
    const b=RB[t.traderId]; if(!b) return;
    b.risk[t.dayIdx]=(b.risk[t.dayIdx]||0)+(t.revenue-t.clientRevenue);
    b.fo[t.dayIdx]=(b.fo[t.dayIdx]||0)+t.revenue;
    if(!isExt(t)) return;
    const tr=TRADER_BY_ID[t.traderId], m=mgn(t.clientRevenue,t.notional);
    b.c+=t.clientRevenue; b.nl+=t.notional; b.n++;
    b.day[t.dayIdx]=(b.day[t.dayIdx]||0)+t.clientRevenue;
    b.cli[t.ctpy]=(b.cli[t.ctpy]||0)+t.clientRevenue;
    const band=sizeBandOf(t.notional);
    (C3[t.product+"|"+t.ctpyType+"|"+band]||(C3[t.product+"|"+t.ctpyType+"|"+band]=[])).push(m);
    (C2[t.product+"|"+t.ctpyType]||(C2[t.product+"|"+t.ctpyType]=[])).push(m);
    (C1[t.product]||(C1[t.product]=[])).push(m);
    add(COH,tr.cohort+"|"+t.product,t.clientRevenue,t.notional);
    add(TP,t.traderId+"|"+t.product,t.clientRevenue,t.notional);
    add(TPT,t.traderId+"|"+t.product+"|"+t.ctpyType,t.clientRevenue,t.notional);
    add(TPTC,t.traderId+"|"+t.product+"|"+t.ctpy,t.clientRevenue,t.notional);
  });
  const FLOOR={}; Object.keys(COH).forEach(k=>add(FLOOR,k.slice(k.indexOf("|")+1),COH[k].c,COH[k].nl));
  TRADERS.forEach(tr=>{
    const b=RB[tr.id];
    b.margin=mgn(b.c,b.nl);
    b.nlPerBiz=b.nl/NB; b.nPerBiz=b.n/NB; b.cPerBiz=b.c/NB;
    const rd=Object.keys(b.risk).map(k=>b.risk[k]);
    const mu=rd.reduce((x,v)=>x+v,0)/(rd.length||1);
    b.riskSd=Math.sqrt(rd.reduce((x,v)=>x+(v-mu)*(v-mu),0)/Math.max(1,rd.length-1));
    const fo=Object.keys(b.fo).map(k=>Math.abs(b.fo[k]));
    b.meanAbsDay=fo.reduce((x,v)=>x+v,0)/(fo.length||1);
    // The share of each month's client revenue booked in its last two business
    // days. Calendar spans, not business-day lists: the month is its first
    // business day to its last, and anything booked on a weekend inside that
    // span counts — exactly as the alert below measures it.
    const sh=[];
    MONTH_END.forEach(me=>{
      const days=monthBiz(me);
      if(days.length<15) return;                         // a part-month at the edge of the year
      const tot=calSum(b.day,days[0],me);
      if(tot>0) sh.push(calSum(b.day,bizBack(me,1),me)/tot);
    });
    b.pe=sh.length?sh.reduce((x,v)=>x+v,0)/sh.length:0;
    const cs=Object.keys(b.cli).map(k=>b.cli[k]).sort((p,q)=>q-p);
    b.topShare=b.c>0&&cs.length?cs[0]/b.c:0;
  });
  // What clients of the same type pay for the same product, as narrowly as the
  // book will support: product, type and size band if there are enough deals
  // to make a median mean something, otherwise widened a step at a time.
  function norm(prod,type,band){
    const a=C3[prod+"|"+type+"|"+band]; if(a&&a.length>=15) return a._m!=null?a._m:(a._m=med(a));
    const b=C2[prod+"|"+type];          if(b&&b.length>=15) return b._m!=null?b._m:(b._m=med(b));
    const c=C1[prod]||[];               return c._m!=null?c._m:(c._m=med(c));
  }
  // The cohort's rate on a product, without the trader being measured in it.
  function cohortMargin(tr,prod){
    const c=COH[tr.cohort+"|"+prod]||{c:0,nl:0}, s=TP[tr.id+"|"+prod]||{c:0,nl:0};
    if(c.nl-s.nl>=25) return mgn(c.c-s.c,c.nl-s.nl);
    const f=FLOOR[prod]||{c:0,nl:0};
    return mgn(f.c-s.c,f.nl-s.nl);
  }
  const cohortSize=tr=>TRADERS.filter(x=>x.cohort===tr.cohort&&x.id!==tr.id).length;
  /* A trader's own margin on one product. A blended margin is no baseline for a
     handful of deals: a credit trader's bonds earn thirty times their FX hedges,
     so "twice their own margin" on a day of bond deals is the product mix, not a
     mark-up. Where the trader has too little history in a product to say, the
     cohort's rate stands in. */
  function ownMargin(tr,prod){
    const s=TP[tr.id+"|"+prod];
    return s&&s.nl>=25?mgn(s.c,s.nl):cohortMargin(tr,prod);
  }
  const ownMix=(tr,ts)=>{ const nl=sum(ts,t=>t.notional); return nl>0?sum(ts,t=>ownMargin(tr,t.product)*t.notional)/nl:0; };

  /* ---- claims, revenue edits and new deals ---- */
  let CUR="";            // the rule being planted, recorded against every deal it changes
  const CLAIM={};
  const free=(tr,lo,hi)=>!(CLAIM[tr.id]||[]).some(w=>lo<=w[1]+3&&hi>=w[0]-3);
  const claim=(tr,lo,hi)=>(CLAIM[tr.id]||(CLAIM[tr.id]=[])).push([lo,hi]);
  // Client revenue changes; the risk the deal carried stays as it was unless
  // the pattern is itself about risk.
  function setRev(t,client,risk){
    if(!REV_ORIG.has(t.id)) REV_ORIG.set(t.id,{c:t.clientRevenue,r:t.revenue,rule:CUR});
    const rk=risk==null?t.revenue-t.clientRevenue:risk;
    t.clientRevenue=+client.toFixed(3);
    t.revenue=+(t.clientRevenue+rk).toFixed(3);
  }
  // A deal the pattern needs and the book does not have: an approved product,
  // inside the trader's own ticket authorisation, on an external channel, priced
  // the way every other deal in the book was.
  function newDeal(day,tr,prod,o){
    o=o||{};
    const t=makeTrade(day,tr,prod,{ctpy:o.ctpy,channel:o.channel||weightedChoice(EXT_CH),execMin:o.execMin,
      notional:o.notional!=null?o.notional:Math.max(0.5,Math.min(tr.ticketLimit*0.9,trBase(tr).medSize*rand(0.55,1.6)))});
    const client=dealRevenue(t);
    t.clientRevenue=+client.toFixed(3);
    t.revenue=+(client+client*rand(-1.6,1.75)*0.80).toFixed(3);
    REV_ORIG.set(t.id,{c:t.clientRevenue,r:t.revenue,created:true,rule:CUR});
    return t;
  }
  const endDay=minBiz=>rng()<0.06?pickDay(Math.max(minBiz,DAYS-45),DAYS-1):pickDay(minBiz,DAYS-1);
  const clientsOf=(tr,ok)=>(tr.ctpys||[]).filter(c=>CT[c.name]&&ok(c)).map(c=>CT[c.name]);
  const names=ts=>uniq(ts.map(t=>t.ctpy));
  const cite=(ts,n,key)=>ts.slice().sort(key).slice(0,n);

  const GEN={};

  /* TS-51 — one client paying several times what comparable clients pay. */
  GEN["TS-51"]=function(rule){
    for(let k=0;k<60;k++){
      const tr=pickActor(rule), hi=endDay(BIZ_DAYS[22]), lo=bizBack(hi,19);
      if(!free(tr,lo,hi)) continue;
      const cands=clientsOf(tr,c=>c.type!=="Bank"&&c.type!=="Broker");
      if(!cands.length) continue;
      const cl=weightedChoice(cands.map(c=>[c,c.type==="Private Client"||c.type==="Corporate"?3:c.type==="Insurer"?2:1]));
      const mine=tradesIn(tr,lo,hi,t=>isExt(t)&&t.ctpy===cl.name);
      const pc={}; mine.forEach(t=>{ pc[t.product]=(pc[t.product]||0)+1; });
      const prod=Object.keys(pc).sort((a,b)=>pc[b]-pc[a])[0]||choice(tr.products);
      const deals=mine.filter(t=>t.product===prod);
      if(deals.length>10) continue;
      const want=randInt(5,8);
      while(deals.length<want) deals.push(newDeal(pickDay(lo,hi),tr,prod,{ctpy:cl}));
      deals.forEach(t=>setRev(t,norm(prod,cl.type,sizeBandOf(t.notional))*rand(2.65,3.6)*t.notional/1000));
      claim(tr,lo,hi);
      const nl=sum(deals,t=>t.notional), rev=sum(deals,t=>t.clientRevenue);
      const fair=sum(deals,t=>norm(prod,cl.type,sizeBandOf(t.notional))*t.notional/1000);
      const m=mgn(rev,nl), mc=mgn(fair,nl);
      const all=TPT[tr.id+"|"+prod+"|"+cl.type]||{c:0,nl:0}, me=TPTC[tr.id+"|"+prod+"|"+cl.name]||{c:0,nl:0};
      const oNl=all.nl-me.nl;
      return mkAlert(rule,hi,tr,deals,[
        ev("Client",cl.name+" · "+cl.type),
        ev("Product",prod),
        ev("Window",win(lo,hi,20)),
        ev("Deals with this client in the window",deals.length+" · "+fmtM(nl)+" notional",true),
        ev("Margin charged on those deals",mg(m),true),
        ev("What "+cl.type.toLowerCase()+" clients pay for the same deals",mg(mc)+" — floor median, matched on product and size band"),
        ev("Multiple of the comparable rate",xf(m/mc)+" — rule threshold 2.5×",true),
        ev("Revenue above the comparable rate",fmtK(rev-fair),true),
        ev("This trader's margin with other "+cl.type.toLowerCase()+" clients in "+prod,
           oNl>=5?mg(mgn(all.c-me.c,oNl))+" over the prior 12 months":"Too little other business of this type to compare"),
        ev("Channels",uniq(deals.map(t=>t.channel)).join(", ")),
      ],cl.name+" ("+cl.type+") charged "+xf(m/mc)+" the comparable margin on "+deals.length+" "+prod+" deals");
    }
    return null;
  };

  /* TS-52 — the same client, the same product, a wider price on the phone. */
  GEN["TS-52"]=function(rule){
    for(let k=0;k<60;k++){
      const tr=pickActor(rule), hi=endDay(BIZ_DAYS[62]), lo=bizBack(hi,59);
      if(!free(tr,lo,hi)) continue;
      const cands=clientsOf(tr,c=>c.type!=="Bank"&&c.type!=="Broker");
      if(!cands.length) continue;
      const cl=choice(cands);
      const mine=tradesIn(tr,lo,hi,t=>isExt(t)&&t.ctpy===cl.name);
      const pc={}; mine.forEach(t=>{ pc[t.product]=(pc[t.product]||0)+1; });
      const prod=Object.keys(pc).sort((a,b)=>pc[b]-pc[a])[0]||choice(tr.products);
      const voice=mine.filter(t=>t.product===prod&&t.channel==="Voice");
      const elec=mine.filter(t=>t.product===prod&&ELEC.indexOf(t.channel)>=0);
      if(voice.length>10||elec.length>10) continue;
      while(voice.length<6) voice.push(newDeal(pickDay(lo,hi),tr,prod,{ctpy:cl,channel:"Voice"}));
      while(elec.length<6)  elec.push(newDeal(pickDay(lo,hi),tr,prod,{ctpy:cl,channel:choice(ELEC)}));
      elec.forEach(t=>setRev(t,norm(prod,cl.type,sizeBandOf(t.notional))*rand(0.75,1.1)*t.notional/1000));
      const me=mgn(sum(elec,t=>t.clientRevenue),sum(elec,t=>t.notional));
      voice.forEach(t=>setRev(t,me*rand(2.4,3.8)*t.notional/1000));
      claim(tr,lo,hi);
      const vNl=sum(voice,t=>t.notional), vRev=sum(voice,t=>t.clientRevenue), eNl=sum(elec,t=>t.notional);
      const mv=mgn(vRev,vNl);
      const deals=voice.concat(elec);
      return mkAlert(rule,hi,tr,deals,[
        ev("Client",cl.name+" · "+cl.type),
        ev("Product",prod),
        ev("Margin on voice",mg(mv)+" over "+voice.length+" deals · "+fmtM(vNl),true),
        ev("Margin on electronic channels",mg(me)+" over "+elec.length+" deals · "+fmtM(eNl)),
        ev("Voice against electronic",xf(mv/me)+" — rule threshold 2×",true),
        ev("Revenue on voice above the client's own electronic rate",fmtK(vRev-me*vNl/1000),true),
        ev("Window",win(lo,hi,60)),
        ev("Voice recordings for these deals",choice(["Retained — not yet reviewed","Retained for 6 of the "+voice.length+" calls","Not located for the two largest"])),
      ],cl.name+" paid "+xf(mv/me)+" on voice what it paid electronically for "+prod);
    }
    return null;
  };

  /* TS-53 — a client small by notional and large by revenue. */
  GEN["TS-53"]=function(rule){
    for(let k=0;k<60;k++){
      const tr=pickActor(rule), hi=endDay(BIZ_DAYS[62]), lo=bizBack(hi,59);
      if(!free(tr,lo,hi)) continue;
      const ext0=tradesIn(tr,lo,hi,isExt);
      if(ext0.length<40) continue;
      const N0=sum(ext0,t=>t.notional);
      const byC={}; ext0.forEach(t=>{ (byC[t.ctpy]||(byC[t.ctpy]=[])).push(t); });
      const small=Object.keys(byC).filter(c=>CT[c]&&CT[c].type!=="Bank"&&byC[c].length<=8&&sum(byC[c],t=>t.notional)<N0*0.05);
      let cl, deals;
      if(small.length){ cl=CT[choice(small)]; deals=byC[cl.name].slice(); }
      else{
        const fresh=clientsOf(tr,c=>c.type!=="Bank"&&!byC[c.name]);
        if(!fresh.length) continue;
        cl=choice(fresh); deals=[];
      }
      const want=randInt(3,5);
      while(deals.length<want) deals.push(newDeal(pickDay(lo,hi),tr,choice(tr.products),
        {ctpy:cl,notional:Math.max(0.5,trBase(tr).medSize*rand(0.25,0.6))}));
      const ext=tradesIn(tr,lo,hi,isExt), N=sum(ext,t=>t.notional), nC=sum(deals,t=>t.notional);
      if(nC/N>=0.085) continue;
      const rest=ext.filter(t=>t.ctpy!==cl.name), Rother=sum(rest,t=>t.clientRevenue);
      if(Rother<=0) continue;
      const s=rand(0.37,0.46), Rc=s/(1-s)*Rother;
      // each deal keeps its own shape — a bond ticket still out-earns an FX one
      const c0=sum(deals,t=>t.clientRevenue);
      deals.forEach(t=>setRev(t,c0>0?t.clientRevenue*Rc/c0:Rc*t.notional/nC));
      claim(tr,lo,hi);
      const R=sum(ext,t=>t.clientRevenue), rc=sum(deals,t=>t.clientRevenue);
      const byC2={}; rest.forEach(t=>{ byC2[t.ctpy]=(byC2[t.ctpy]||0)+t.clientRevenue; });
      const next=Object.keys(byC2).sort((a,b)=>byC2[b]-byC2[a])[0];
      return mkAlert(rule,hi,tr,deals,[
        ev("Client",cl.name+" · "+cl.type),
        ev("Window",win(lo,hi,60)),
        ev("Share of this trader's client revenue",fmtPct(rc/R)+" — "+fmtK(rc)+" of "+fmtK(R)+" · rule threshold 35%",true),
        ev("Share of this trader's notional",fmtPct(nC/N)+" — "+fmtM(nC)+" of "+fmtM(N)+" · rule ceiling 10%",true),
        ev("Margin on this client",mg(mgn(rc,nC))+" against "+mg(mgn(Rother,N-nC))+" on the rest of the book",true),
        ev("Deals with this client",deals.length+" in the window"),
        ev("Next-largest client by revenue",next?next+" · "+fmtPct(byC2[next]/R):"—"),
        ev("This trader's largest client share over the prior 12 months",fmtPct(RB[tr.id].topShare)),
      ],cl.name+" is "+fmtPct(rc/R,0)+" of this trader's revenue on "+fmtPct(nC/N,0)+" of the notional");
    }
    return null;
  };

  /* TS-54 — earning far more per million than the cohort, on the same products. */
  GEN["TS-54"]=function(rule){
    for(let k=0;k<60;k++){
      const tr=pickActor(rule), hi=endDay(BIZ_DAYS[22]), lo=bizBack(hi,19);
      if(!free(tr,lo,hi)||cohortSize(tr)<2) continue;
      const ext=tradesIn(tr,lo,hi,isExt);
      if(ext.length<15) continue;
      const exp=sum(ext,t=>cohortMargin(tr,t.product)*t.notional/1000), act=sum(ext,t=>t.clientRevenue);
      if(!(exp>0)||!(act>0)) continue;
      const kf=rand(2.65,3.2)*exp/act;
      ext.forEach(t=>setRev(t,t.clientRevenue*kf));
      claim(tr,lo,hi);
      const N=sum(ext,t=>t.notional), R=sum(ext,t=>t.clientRevenue), m=mgn(R,N), mc=mgn(exp,N);
      const exc={}; ext.forEach(t=>{ exc[t.product]=(exc[t.product]||0)+t.clientRevenue-cohortMargin(tr,t.product)*t.notional/1000; });
      const topP=Object.keys(exc).sort((a,b)=>exc[b]-exc[a])[0];
      const xs=t=>t.clientRevenue-cohortMargin(tr,t.product)*t.notional/1000;
      const cited=cite(ext,16,(a,b)=>xs(b)-xs(a));
      return mkAlert(rule,hi,tr,cited,[
        ev("Window",win(lo,hi,20)),
        ev("Margin over the window",mg(m)+" on "+fmtM(N)+" across "+ext.length+" deals",true),
        ev("Cohort margin on the same product mix",mg(mc)+" — "+tr.cohort+", "+cohortSize(tr)+" peers"),
        ev("Multiple of the cohort",xf(m/mc)+" — rule threshold 2.5×",true),
        ev("Revenue above the cohort rate",fmtK(R-exp),true),
        ev("Largest contributor",topP+" · "+fmtK(exc[topP])+" above the cohort rate"),
        ev("This trader's own 12-month margin",mg(RB[tr.id].margin)),
        ev("Deals cited",cited.length+" with the largest excess, of "+ext.length+" in the window"),
      ],"Earning "+xf(m/mc)+" the cohort's margin on the same product mix over 20 business days");
    }
    return null;
  };

  /* TS-55 — a month's revenue bunched into its last two days. */
  GEN["TS-55"]=function(rule){
    for(let k=0;k<60;k++){
      const tr=pickActor(rule), me=choice(MONTH_END_REV), dt=dateForIdx(me), mdays=monthBiz(me);
      if(mdays.length<15) continue;
      const lo=mdays[0], d1=bizBack(me,1), nx=bizFwd(me,10);
      if(!free(tr,lo,nx)) continue;
      const b=RB[tr.id].pe; if(!(b>0)||b>0.24) continue;
      const last=tradesIn(tr,d1,me,isExt);
      while(last.length<3) last.push(newDeal(rng()<0.5?d1:me,tr,choice(tr.products),{}));
      const rest=tradesIn(tr,lo,d1-1,isExt), Rrest=sum(rest,t=>t.clientRevenue);
      if(Rrest<=0) continue;
      const s=Math.min(0.7,Math.max(0.28,b*rand(2.8,4.2)));
      if(s/b<2.6) continue;
      const nl=sum(last,t=>t.notional), Rl=s/(1-s)*Rrest, added=Rl-sum(last,t=>t.clientRevenue);
      const c0=sum(last,t=>t.clientRevenue);
      last.forEach(t=>setRev(t,c0>0?t.clientRevenue*Rl/c0:Rl*t.notional/nl));
      // Pulled forward is pulled from somewhere: the first ten business days of
      // the next month give up what the last two days gained, as far as they can
      // without a deal earning less than nothing.
      const next=tradesIn(tr,bizFwd(me,1),nx,isExt), Rn=sum(next,t=>t.clientRevenue);
      if(Rn>0&&added>0){ const keep=1-Math.min(0.75,added/Rn); next.forEach(t=>setRev(t,t.clientRevenue*keep)); }
      claim(tr,lo,nx);
      const RL=sum(last,t=>t.clientRevenue), RM=RL+Rrest, share=RL/RM;
      const after=tradesIn(tr,bizFwd(me,1),nx,isExt), Rafter=sum(after,t=>t.clientRevenue);
      const late=last.filter(t=>t.execMin>=16*60).length;
      return mkAlert(rule,me,tr,last,[
        ev("Month",MONTHS[dt.getMonth()]+" "+dt.getFullYear()),
        ev("Client revenue in the last two business days",fmtK(RL)+" on "+last.length+" deals · "+fmtM(nl),true),
        ev("Client revenue for the month",fmtK(RM)),
        ev("Share booked in the last two days",fmtPct(share)+" — rule floor 25%",true),
        ev("This trader's own 12-month rate",fmtPct(b)+" — this month is "+xf(share/b)+" · rule threshold 2.5×",true),
        ev("Deals executed after 16:00 local on those days",late+" of "+last.length),
        ev("Revenue in the first ten business days of the next month",fmtK(Rafter)+" against a normal "+fmtK(RB[tr.id].cPerBiz*10),
           Rafter<RB[tr.id].cPerBiz*10*0.6),
      ],fmtPct(share,0)+" of "+MONTHS[dt.getMonth()]+"'s revenue booked in its last two business days");
    }
    return null;
  };

  /* TS-56 — volume up, margin given away. */
  GEN["TS-56"]=function(rule){
    for(let k=0;k<60;k++){
      const tr=pickActor(rule), hi=endDay(BIZ_DAYS[22]), lo=bizBack(hi,19);
      if(!free(tr,lo,hi)) continue;
      const B=RB[tr.id]; if(!(B.margin>0)) continue;
      const ext=tradesIn(tr,lo,hi,isExt), days=BIZ_DAYS.slice(bizIx(lo),bizIx(hi)+1);
      const baseNl=B.nlPerBiz*20, target=baseNl*rand(1.55,1.9);
      let N=sum(ext,t=>t.notional), guard=0;
      while(N<target&&guard++<300){ const t=newDeal(choice(days),tr,choice(tr.products),{}); ext.push(t); N+=t.notional; }
      if(N<target) continue;
      ext.forEach(t=>setRev(t,ownMargin(tr,t.product)*rand(0.05,0.27)*t.notional/1000));
      claim(tr,lo,hi);
      const R=sum(ext,t=>t.clientRevenue), m=mgn(R,N), own=ownMix(tr,ext);
      const byC={}; ext.forEach(t=>{ byC[t.ctpy]=(byC[t.ctpy]||0)+t.notional; });
      const top=Object.keys(byC).sort((a,b)=>byC[b]-byC[a]).slice(0,3);
      const cited=cite(ext,16,(a,b)=>b.notional-a.notional);
      return mkAlert(rule,hi,tr,cited,[
        ev("Window",win(lo,hi,20)),
        ev("Margin on external flow",mg(m),true),
        ev("This trader's own margin on the same product mix",mg(own)+" over 12 months — the window is "+fmtPct(m/own,0)+" of it · rule ceiling 30%",true),
        ev("Notional in the window",fmtM(N)+" against a normal "+fmtM(baseNl)+" — "+xf(N/baseNl)+" · rule threshold 1.5×",true),
        ev("Deals in the window",ext.length+" against a normal "+Math.round(B.nPerBiz*20)),
        ev("Revenue forgone at this trader's own margin",fmtK(own*N/1000-R),true),
        ev("Clients taking the most notional at this rate",top.map(c=>c+" · "+fmtM(byC[c])).join("; ")),
        ev("Deals cited",cited.length+" largest, of "+ext.length+" in the window"),
      ],"Margin at "+fmtPct(m/own,0)+" of this trader's own norm on "+xf(N/baseNl)+" their usual volume");
    }
    return null;
  };

  /* TS-57 — front office and product control a long way apart on one day. */
  GEN["TS-57"]=function(rule){
    for(let k=0;k<60;k++){
      const tr=pickActor(rule), d=endDay(BIZ_DAYS[5]), nd=bizFwd(d,1);
      if(nd===d||!free(tr,d,nd)) continue;
      const deals=tradesIn(tr,d,d,isExt);
      while(deals.length<2) deals.push(newDeal(d,tr,choice(tr.products),{}));
      const FO0=sum(tradesIn(tr,d,d),t=>t.revenue);
      const mb=RB[tr.id].meanAbsDay*rand(0.05,0.11);
      const thr=Math.max(250,3*mb);
      const up=rng()<0.5, B=thr*rand(1.35,1.9)*(up?1:-1);
      // A break this size belongs on a book big enough to produce one. On a
      // trader whose whole year earns less than a few of them, it would not be
      // a reconciliation break; it would be the year.
      if(Object.keys(RB[tr.id].fo).reduce((x,k)=>x+RB[tr.id].fo[k],0)<4*Math.abs(B)) continue;
      const nl=sum(deals,t=>t.notional);
      deals.forEach(t=>setRev(t,t.clientRevenue,(t.revenue-t.clientRevenue)+B*t.notional/nl));
      claim(tr,d,nd);
      const FO=sum(tradesIn(tr,d,d),t=>t.revenue);
      const PC=FO0-mb*rand(-0.8,0.8), brk=FO-PC;
      const big=deals.slice().sort((a,b)=>Math.abs(b.revenue)-Math.abs(a.revenue))[0];
      return mkAlert(rule,d,tr,deals,[
        ev("Business date",fmtDate(dateForIdx(d))),
        ev("Front-office revenue",fmtK(FO),true),
        ev("Product-control P&L",fmtK(PC)),
        ev("Break",fmtK(brk)+(up?" — front office above product control":" — front office below product control"),true),
        ev("Rule threshold",fmtK(thr)+" — the greater of $250k and 3× this trader's own mean break"),
        ev("This trader's mean daily break, prior 60 days",fmtK(mb)),
        ev("Largest deal carrying it",big.id+" · "+big.product+" · "+fmtK(big.revenue)),
        ev("Reserve or price-verification adjustment raised for it",rng()<0.25?"Yes — raised after the close, not yet approved":"None on file",false),
        ev("Front-office revenue the next business day",fmtK(sum(tradesIn(tr,nd,nd),t=>t.revenue))),
      ],"Front office "+(up?"above":"below")+" product control by "+fmtK(Math.abs(brk))+" on one day");
    }
    return null;
  };

  /* TS-58 — a loss on the book, then the clients pay for it. */
  GEN["TS-58"]=function(rule){
    for(let k=0;k<60;k++){
      const tr=pickActor(rule), d=endDay(BIZ_DAYS[5]);
      if(!free(tr,d,d)) continue;
      const B=RB[tr.id]; if(!(B.riskSd>0)||!(B.margin>0)) continue;
      const h=DESK_HOURS[DESK_BY_ID[tr.deskId].region], open=Math.round(h[0]*60), close=Math.round(h[1]*60);
      const day=tradesIn(tr,d,d,isExt).sort((a,b)=>a.execMin-b.execMin);
      let loss=day.filter(t=>t.execMin<=close-240).slice(0,Math.min(2,day.length));
      if(!loss.length) loss=[newDeal(d,tr,choice(tr.products),{execMin:open+randInt(30,150)})];
      const tL=Math.max(...loss.map(t=>t.execMin));
      const after=day.filter(t=>loss.indexOf(t)<0&&t.execMin>tL);
      while(after.length<3) after.push(newDeal(d,tr,choice(tr.products),{execMin:tL+randInt(15,Math.max(20,close-tL-15))}));
      const L=B.riskSd*rand(2.4,3.6), lnl=sum(loss,t=>t.notional);
      // the loss sits on the first deals; everything else that day carries no risk
      tradesIn(tr,d,d).forEach(t=>{ if(loss.indexOf(t)<0&&t.revenue!==t.clientRevenue) setRev(t,t.clientRevenue,0); });
      loss.forEach(t=>setRev(t,t.clientRevenue,-L*t.notional/lnl));
      after.forEach(t=>setRev(t,ownMargin(tr,t.product)*rand(2.4,3.6)*t.notional/1000,0));
      claim(tr,d,d);
      const risk=sum(tradesIn(tr,d,d),t=>t.revenue-t.clientRevenue);
      const aNl=sum(after,t=>t.notional), aRev=sum(after,t=>t.clientRevenue), ma=mgn(aRev,aNl), own=ownMix(tr,after);
      const excess=aRev-own*aNl/1000;
      const first=after.reduce((a,t)=>t.execMin<a.execMin?t:a,after[0]);
      const cl=uniq(after.map(t=>t.ctpy+" · "+t.ctpyType));
      return mkAlert(rule,d,tr,loss.concat(after),[
        ev("Business date",fmtDate(dateForIdx(d))),
        ev("Risk result on the day",fmtK(risk)+" — taken on "+loss.map(t=>t.id).join(", ")+" by "+fmtTime(tL),true),
        ev("This trader's own daily risk-result swing",fmtK(B.riskSd)+" (1σ) — the day is "+xf(Math.abs(risk)/B.riskSd)+" · rule threshold 2×",true),
        ev("Client margin on the "+after.length+" deals after the loss",mg(ma),true),
        ev("This trader's own margin on the same products",mg(own)+" over 12 months — after the loss "+xf(ma/own)+" · rule threshold 2×",true),
        ev("Revenue above their own margin, after the loss",fmtK(excess)+" — "+fmtPct(excess/Math.abs(risk),0)+" of the loss recovered",excess/Math.abs(risk)>0.3),
        ev("First marked-up deal",first.id+" at "+fmtTime(first.execMin)+", "+(first.execMin-tL)+" minutes after the loss"),
        ev("Clients charged",cl.join("; ")),
      ],"Loss of "+fmtK(Math.abs(risk))+" followed by client deals at "+xf(ma/own)+" the trader's own margin on those products");
    }
    return null;
  };

  /* ---- run, number after the existing alerts, seed their history ---- */
  const before=ALERTS.length, made=[];
  RULES.filter(r=>r.stream==="revenue").forEach(r=>{
    const f=GEN[r.id];
    if(!f) throw new Error("no generator for "+r.id);
    CUR=r.id;
    for(let i=0;i<scaled(r.plants);i++){ const a=f(r); if(a) made.push(a); }
  });
  const order=(a,b)=>a.day-b.day||SEV_RANK[b.sev]-SEV_RANK[a.sev]||a.ruleId.localeCompare(b.ruleId);
  made.sort(order).forEach((a,i)=>{ a.n=before+i; a.id="ALT-"+String(before+i+1).padStart(5,"0"); ALERT_BY_ID[a.id]=a; });
  seedReviews(made);
  // Back into date order. The sort is stable and the existing alerts were
  // already in this order, so their relative positions do not move.
  ALERTS.sort(order);
});
})();
// Decisions recorded against these alerts are applied here: the pass above the
// banner ran before they existed.
applyReviews();
