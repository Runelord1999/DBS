/* ============================================================
   Per-trader behavioural baselines
   Measured off each trader's own book once it exists. Every rule that asks "is
   this unusual?" resolves the question here — against this trader's ordinary
   week, and against the cohort doing the same job — never against a desk total,
   where one junior's whole year is a rounding error on the head trader's month.
============================================================ */
const BASE={};
(function traderBaselines(){
  TRADERS.forEach(t=>{
    const own=TRADES.filter(x=>x.traderId===t.id);
    const byDay={}; own.forEach(x=>{ (byDay[x.dayIdx]=byDay[x.dayIdx]||[]).push(x); });
    const dk=Object.keys(byDay);
    const tickets=dk.map(k=>byDay[k].length);
    const notion=dk.map(k=>byDay[k].reduce((a,x)=>a+x.notional,0));
    const ctpy={}; own.forEach(x=>{ ctpy[x.ctpy]=(ctpy[x.ctpy]||0)+1; });
    const ctpyNames=Object.keys(ctpy).sort((a,b)=>ctpy[b]-ctpy[a]);
    const sizes=own.map(x=>x.notional);
    const dayPnl=dk.map(k=>byDay[k].reduce((a,x)=>a+x.pnl,0));
    BASE[t.id]={
      deals:own.length, activeDays:dk.length,
      tickets:mean(tickets), ticketsSd:sd(tickets), ticketsP95:pctile(tickets,0.95),
      dayNotional:mean(notion), dayNotionalSd:sd(notion),
      medSize:median(sizes), p95Size:pctile(sizes,0.95),
      ctpyCount:ctpyNames.length, topCtpy:ctpyNames[0]||"—",
      topCtpyShare:own.length?ctpy[ctpyNames[0]]/own.length:0,
      products:uniq(own.map(x=>x.product)),
      execMean:mean(own.map(x=>x.execMin)), execSd:sd(own.map(x=>x.execMin)),
      pnlMean:mean(dayPnl), pnlSd:sd(dayPnl),
      lossDays:dayPnl.filter(v=>v<0).length/Math.max(1,dayPnl.length),
      amendRate:own.filter(x=>x.amends>0).length/Math.max(1,own.length),
      amendsPerDeal:own.reduce((a,x)=>a+x.amends,0)/Math.max(1,own.length),
    };
  });
  // Cohort medians: what the same grade doing the same job looks like.
  TRADERS.forEach(t=>{
    const ms=t.peers;
    BASE[t.id].cohort={tickets:median(ms.map(x=>BASE[x.id].tickets)),
             dayNotional:median(ms.map(x=>BASE[x.id].dayNotional)),
             medSize:median(ms.map(x=>BASE[x.id].medSize)),
             ctpyCount:median(ms.map(x=>BASE[x.id].ctpyCount)),
             topCtpyShare:median(ms.map(x=>BASE[x.id].topCtpyShare)),
             amendRate:median(ms.map(x=>BASE[x.id].amendRate)),
             amendsPerDeal:median(ms.map(x=>BASE[x.id].amendsPerDeal)),
             lossDays:median(ms.map(x=>BASE[x.id].lossDays)),
             n:ms.length};
  });
})();
const trBase=tr=>BASE[tr.id];
/* "×N of this trader's own baseline" — the phrase every trader-level rule is
   argued in, so it is computed once and quoted verbatim on the evidence. */
const xBase=(v,b)=>(b>0?(v/b).toFixed(1):"—")+"×";
