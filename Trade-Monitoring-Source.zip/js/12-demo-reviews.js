/* ============================================================
   Seeded review history
   An officer logging in on day one should not face a year of untouched alerts.
   Everything older than a fortnight has already been worked — mostly by the
   officer, partly by colleagues — and the pass rate follows each rule's benign
   rate, so the backlog looks like a book that has been under review all year.
============================================================ */
const PASS_REASONS=[
  "Client-authorised order — instruction on file",
  "Documented hedge for an existing position",
  "Market dislocation corroborated by TCA",
  "System or feed latency — data quality issue",
  "Personal mandate exception approved for this trader",
  "Trader explanation verified with the desk head",
  "Duplicate of an existing case",
  "Benign — thin liquidity at the time of execution",
  "Baseline distorted — trader covering a colleague on block leave",
  "Trader's baseline reset after a book transfer this quarter",
];
const SUSP_REASONS=[
  "Unexplained off-market pricing",
  "Pattern consistent with mark manipulation",
  "Concealment of a loss position",
  "Potential personal benefit or undisclosed conflict",
  "Indicators of information misuse",
  "Control circumvention — authorisation defeated",
  "Repeat pattern by the same trader",
  "Sustained departure from the trader's own baseline",
];
const PASS_NOTES=[
  "Spoke to the desk head. Order was pre-agreed with the client at a fixed rate the previous session; instruction sighted.",
  "Reviewed against the hedge register — offsetting position booked the same morning under the same strategy ID.",
  "TCA for the window shows the whole street printed away from the composite. No trader-specific advantage.",
  "Confirmed with Technology: the booking gateway queued for the session. Affected 30+ deals across three desks.",
  "Personal mandate exception approved by Market Risk for this trader earlier in the quarter and still valid. Filed against the case.",
  "Checked against the trader's own 90-day profile: the week they covered the desk single-handed accounts for the whole exceedance.",
  "Trader provided the client tape. Sequence and sizing are consistent with the recording.",
];
const SUSP_NOTES=[
  "No commercial rationale offered. Pricing sits outside anything the desk printed that week. Referred to Investigations.",
  "Explanation does not reconcile with the booking timestamps. Escalating with a hold on the trader's system access.",
  "Third occurrence for this trader on the same typology this quarter. Pattern, not coincidence.",
  "Counterparty connection matches the related-party register. Conflicts declaration does not disclose it.",
  "Position built ahead of the announcement and closed straight after. Requesting comms review for the period.",
];
function seedReviews(){
  ALERTS.forEach(a=>{
    const age=DAYS-1-a.day;
    const tr=TRADER_BY_ID[a.traderId];
    const rule=RULE_BY_ID[a.ruleId];
    if(age<=2) return;                                   // still in today's queue
    // Nothing survives unreviewed past six weeks: the backlog an officer inherits
    // is a few weeks deep, not a year. Beyond that the queue is always cleared.
    const worked=age>45?true:age<=10?rng()<0.42:rng()<0.75;
    if(!worked){ if(rng()<0.4) setStatusSeed(a,"In Review",tr); return; }
    // Most alerts are explained: threshold noise on a legitimate book. What is not
    // explained away clusters on the traders running an actual pattern.
    const passP=a.noise?0.93:Math.max(0.05,Math.min(0.85,rule.fp*(tr.risk>0.7?0.5:2.0)*(a.sev==="Critical"?0.6:1)));
    const passed=rng()<passP;
    const status=passed?"Passed":(rng()<0.58?"Suspicious":"Escalated");
    setStatusSeed(a,status,tr);
  });
}
function setStatusSeed(a,status,tr){
  const reviewer=rng()<0.46?OFFICER:choice(PEERS);
  const lag=randInt(1,Math.min(9,Math.max(2,DAYS-1-a.day)));
  const rd=dateForIdx(Math.min(DAYS-1,a.day+lag));
  a.status=status; a.reviewer=reviewer; a.reviewedStr=fmtDate(rd)+" "+fmtTime(randInt(8,18)*60+randInt(0,59));
  a.reviewDay=Math.min(DAYS-1,a.day+lag);
  a.audit.push({ts:fmtDate(dateForIdx(a.day+1))+" 07:15",actor:"Case management",action:"Assigned",detail:"Queued to "+reviewer});
  if(status==="In Review"){
    a.audit.push({ts:a.reviewedStr,actor:reviewer,action:"Opened for review",detail:"Evidence pack requested from the desk"});
    a.reviewedStr=""; a.reviewDay=null;
    return;
  }
  a.reason=status==="Passed"?choice(PASS_REASONS):choice(SUSP_REASONS);
  a.note=status==="Passed"?choice(PASS_NOTES):choice(SUSP_NOTES);
  a.audit.push({ts:a.reviewedStr,actor:reviewer,action:status==="Passed"?"Passed — not suspicious":status==="Suspicious"?"Tagged suspicious":"Escalated to Investigations",detail:a.reason});
  if(status==="Escalated") a.audit.push({ts:a.reviewedStr,actor:"Financial Crime Investigations",action:"Case opened",detail:"CASE-"+String(2600+a.n%400)});
  if(status==="Suspicious") a.audit.push({ts:a.reviewedStr,actor:"Regulatory Reporting",action:"STR drafted",detail:"STR-"+dateForIdx(a.day).getFullYear()+"-"+String(1000+a.n%900)});
}
seedReviews();

/* Officer decisions persist locally and are re-applied over the seed, so the
   queue an officer worked yesterday stays worked after a reload. */
const REV_KEY="ts-dash-reviews-v1";
function loadLS(k,d){ try{const v=localStorage.getItem(k); return v?JSON.parse(v):d;}catch(e){return d;} }
function saveLS(k,v){ try{localStorage.setItem(k,JSON.stringify(v));}catch(e){} }
let REVIEWS=loadLS(REV_KEY,{});
function applyReviews(){
  Object.keys(REVIEWS).forEach(id=>{
    const a=ALERT_BY_ID[id]; if(!a) return;
    const r=REVIEWS[id];
    a.status=r.status; a.reason=r.reason||""; a.note=r.note||"";
    a.reviewer=OFFICER; a.reviewedStr=r.ts; a.reviewDay=DAYS-1; a.mine=true;
    if(!a.audit.some(x=>x.mine)) a.audit.push({ts:r.ts,actor:OFFICER,action:r.action,detail:r.reason||"—",mine:true});
    else a.audit=a.audit.filter(x=>!x.mine).concat([{ts:r.ts,actor:OFFICER,action:r.action,detail:r.reason||"—",mine:true}]);
  });
}
applyReviews();
