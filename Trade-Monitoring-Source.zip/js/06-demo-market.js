/* ============================================================
   Market data — one instrument universe, one price path each
   An instrument exists once and carries a seeded daily mid for the whole year,
   so two deals in the same name on the same day are measured against the same
   mark. That is what makes "22 bps off mid" a statement about the trade rather
   than about the random number generator, and it is what lets the alert drawer
   plot the market the trade was struck into.

   Every family also declares its own dealing spread and its own materiality
   floor, because "off market" is not one number across a book: half a basis
   point is a wide market in EUR/USD spot and invisible in a high-yield bond.
============================================================ */
const FAM_MKT={
  /* spread  — typical half-spread on the devBps scale
     omFloor — the deviation at which a print is material; 0 means the family is
               not price-tested, because its economics live in the volatility
     bpW     — what one bp on the devBps scale is worth in bps of notional. A bp
               of an FX rate is a bp of the deal; a bp of swap yield is worth
               roughly four and a half at typical duration; a bp of overnight
               repo rate a fifth; and a bp of an option premium quoted at about
               1.5% of notional, a sixty-sixth. Without this the option book
               prints P&L two orders of magnitude too large.
     noiseBps— ordinary mark movement on a ticket, in bps of notional */
  fx:   {spread:0.55, omFloor:22, volPct:0.0040, bpW:1.0,   noiseBps:3.4},
  ndf:  {spread:4.20, omFloor:38, volPct:0.0055, bpW:1.0,   noiseBps:4.2},
  fxopt:{spread:170,  omFloor:0,  volPct:0.0190, bpW:0.015, noiseBps:8.5},
  rate: {spread:0.45, omFloor:6,  volAbs:0.028,  bpW:4.5,   noiseBps:3.6},
  bondg:{spread:1.10, omFloor:14, volAbs:0.21,   bpW:1.0,   noiseBps:2.9},
  bondc:{spread:20,   omFloor:60, volAbs:0.33,   bpW:1.0,   noiseBps:6.0},
  repo: {spread:1.60, omFloor:12, volAbs:0.010,  bpW:0.2,   noiseBps:0.62},
  eqopt:{spread:210,  omFloor:0,  volPct:0.0280, bpW:0.015, noiseBps:10.5},
  eq:   {spread:3.20, omFloor:30, volPct:0.0110, bpW:1.0,   noiseBps:5.2},
  cds:  {spread:3.50, omFloor:25, volAbs:4.0,    bpW:4.5,   noiseBps:5.4},
  cdsi: {spread:0.50, omFloor:4,  volAbs:0.85,   bpW:4.5,   noiseBps:3.4},
  trs:  {spread:4.50, omFloor:28, volAbs:2.9,    bpW:4.5,   noiseBps:5.8},
};
/* The value of a deviation, in $k. One bp of notional on $1m is $100, so this is
   arithmetic an officer can redo by hand off the evidence: 200 bps off mid on
   $60m of FX is $1.2m, and the alert says exactly that. */
const bpValue=(fam,notionalM,bps)=>+(notionalM*0.1*Math.abs(bps)*FAM_MKT[fam].bpW).toFixed(1);
/* Deterministic bell-shaped noise from a coordinate triple. The intraday path
   has to be reproducible without storing a value per minute per instrument. */
function hashUnit(a,b,c){
  let h=Math.imul((a*2654435761)^(b*40503)^(c*2246822519),2654435761);
  h^=h>>>15; h=Math.imul(h,2246822507); h^=h>>>13; h=Math.imul(h,3266489909); h^=h>>>16;
  return (h>>>0)/4294967296;
}
const hashNoise=(a,b,c)=>hashUnit(a,b,c)+hashUnit(a+7919,b,c)+hashUnit(a,b+104729,c)-1.5;

let _instIdx=0;
/* One seeded path per instrument: a random walk pulled gently back to its
   reference, so a year of trading drifts like a market instead of wandering
   off to a level nobody would quote. */
function makeInstrument(o){
  const fam=FAM_MKT[o.fam];
  const dv=(fam.volAbs!=null?fam.volAbs:o.ref*fam.volPct)*(o.volMult==null?1:o.volMult);
  const inst={i:++_instIdx, key:o.key||o.name, name:o.name, fam:o.fam, unit:o.unit, dp:o.dp,
    ref:o.ref, dv, spreadBps:fam.spread*rand(0.75,1.35), omFloor:fam.omFloor,
    rating:o.rating||"", collateral:o.collateral||"", tenors:o.tenors||null, path:new Array(DAYS)};
  let x=o.ref;
  const floor=o.floor!=null?o.floor:(o.unit==="bps"||o.unit==="%"?o.ref*0.25:o.ref*0.55);
  for(let d=0;d<DAYS;d++){
    x+=(rng()+rng()+rng()-1.5)*2*dv-(x-o.ref)*0.013;
    if(x<floor) x=floor+(floor-x)*0.4;
    inst.path[d]=x;
  }
  if(o.volRef!=null){
    // Implied volatility walks on its own, so an option's premium and the
    // surface it is checked against move together rather than independently.
    inst.volRef=o.volRef; inst.volPath=new Array(DAYS);
    let v=o.volRef;
    for(let d=0;d<DAYS;d++){ v+=(rng()+rng()+rng()-1.5)*2*o.volDv-(v-o.volRef)*0.02; inst.volPath[d]=Math.max(o.volRef*0.35,v); }
  }
  return inst;
}
/* The mid at a moment. The session runs from yesterday's close to today's, and
   in between it walks: a Brownian bridge pinned at both ends, so the day has a
   real high and a real low without the close drifting away from the daily path.
   Independent noise per bucket would draw a sawtooth no market ever printed. */
const SESSION_OPEN=420, SESSION_CLOSE=1140, SESSION_BUCKETS=145;
const _bridge=new Map();
function dayBridge(inst,d){
  const k=inst.i+"|"+d;
  let w=_bridge.get(k);
  if(w) return w;
  w=new Array(SESSION_BUCKETS); let acc=0;
  for(let b=0;b<SESSION_BUCKETS;b++){ acc+=hashNoise(inst.i,d,b); w[b]=acc; }
  const end=w[SESSION_BUCKETS-1];
  for(let b=0;b<SESSION_BUCKETS;b++) w[b]=(w[b]-end*b/(SESSION_BUCKETS-1))*inst.dv*0.16;
  _bridge.set(k,w);
  return w;
}
function midAt(inst,day,min){
  const d=Math.max(0,Math.min(DAYS-1,day));
  const m=min==null?SESSION_CLOSE:min;
  const prev=inst.path[Math.max(0,d-1)], close=inst.path[d];
  const f=Math.max(0,Math.min(1,(m-SESSION_OPEN)/(SESSION_CLOSE-SESSION_OPEN)));
  const b=Math.max(0,Math.min(SESSION_BUCKETS-1,Math.round((m-SESSION_OPEN)/5)));
  return prev+(close-prev)*f+dayBridge(inst,d)[b];
}
function volAt(inst,day){
  if(!inst.volPath) return null;
  return inst.volPath[Math.max(0,Math.min(DAYS-1,day))];
}
/* The session's own high and low, sampled at the five-minute grid the intraday
   noise is defined on. */
function dayRange(inst,day){
  let lo=Infinity,hi=-Infinity;
  for(let m=SESSION_OPEN;m<=SESSION_CLOSE;m+=5){ const v=midAt(inst,day,m); if(v<lo)lo=v; if(v>hi)hi=v; }
  return {lo,hi};
}
/* Materiality: eight times the instrument's own dealing spread, never below the
   family floor. A rule that says "25 bps" for every product on the book is a
   rule that cannot fire on a corporate bond and cannot stop firing on a CDS
   index — the threshold has to come from the instrument. */
const omThreshold=inst=>Math.max(inst.omFloor,inst.spreadBps*8);
/* How far the market itself moved between two moments, in bps. Every rule that
   claims a benchmark moved, a close was pushed or a burst walked the level has
   to read that claim off the same path the alert chart draws — otherwise the
   evidence and the picture disagree in front of the officer. */
function mktMove(inst,day,fromMin,toMin){
  const a=midAt(inst,day,fromMin), b=midAt(inst,day,toMin);
  return devBpsOf(inst.unit,b,a);
}
const priceTested=inst=>inst.omFloor>0;

const INSTRUMENTS=[];
const INST_BY_KEY={};
const INST_BY_FAM={};
function addInstrument(o){
  const inst=makeInstrument(o);
  INSTRUMENTS.push(inst); INST_BY_KEY[inst.key]=inst;
  (INST_BY_FAM[inst.fam]=INST_BY_FAM[inst.fam]||[]).push(inst);
  return inst;
}
(function buildUniverse(){
  const fxDp=r=>r>500?2:r>50?3:5;
  CCY_PAIRS.forEach(c=>addInstrument({fam:"fx",name:c[0],ref:c[1],unit:"rate",dp:fxDp(c[1]),volMult:c[2]}));
  CCY_PAIRS.forEach(c=>addInstrument({fam:"fx",key:c[0]+" future",name:c[0]+" future",ref:c[1],unit:"rate",dp:fxDp(c[1]),volMult:c[2]}));
  NDF_PAIRS.forEach(c=>addInstrument({fam:"ndf",name:c[0]+" NDF",ref:c[1],unit:"rate",dp:fxDp(c[1]),volMult:NDF_VOL[c[0]]||1}));
  // One vol surface per pair; the premium walks with it.
  CCY_PAIRS.concat(NDF_PAIRS).forEach(c=>addInstrument({fam:"fxopt",key:c[0]+" vol",name:c[0],
    ref:rand(0.42,2.9),unit:"% prem",dp:3,volRef:rand(5.4,12.6),volDv:0.14}));
  RATE_CCY.forEach(c=>["IRS","OIS","FRA","Swaption","Cap/Floor","Inflation Swap","CCS","Cross-Ccy Basis Swap"].forEach(p=>
    addInstrument({fam:"rate",key:c[0]+" "+p,name:c[0]+" "+p,ref:c[1]+rand(-0.3,0.3),unit:"%",dp:4})));
  GOVT_ISSUERS.forEach(g=>["2Y","5Y","10Y","30Y"].forEach(t=>
    addInstrument({fam:"bondg",key:g[0]+" "+t,name:g[0]+" "+t,ref:rand(96.6,104.1),unit:"px",dp:3,tenors:[t]})));
  CORP_ISSUERS.forEach(c=>addInstrument({fam:"bondc",name:c[0],ref:rand(88.6,106.4),unit:"px",dp:3,rating:c[1]}));
  RATE_CCY.forEach(c=>{ const g=choice(GOVT_ISSUERS);
    addInstrument({fam:"repo",key:c[0]+" repo vs "+g[0],name:c[0]+" repo vs "+g[0],ref:c[1]-rand(0.03,0.15),unit:"%",dp:4,collateral:g[0]}); });
  EQ_UNDERLYINGS.forEach(e=>addInstrument({fam:"eqopt",key:e[0]+" vol",name:e[0]+" ("+e[1]+")",
    ref:rand(1.3,9.4),unit:"prem",dp:3,volRef:rand(17,41),volDv:0.55}));
  EQ_UNDERLYINGS.forEach(e=>addInstrument({fam:"eq",key:e[0],name:e[0]+" ("+e[1]+")",ref:rand(4.4,178),unit:"px",dp:3}));
  EQ_INDICES.forEach(x=>addInstrument({fam:"eq",key:x,name:x,ref:rand(3300,26600),unit:"px",dp:2}));
  CDS_NAMES.forEach(c=>addInstrument({fam:"cds",key:c[0]+" 5Y CDS",name:c[0]+" 5Y CDS",ref:rand(62,455),unit:"bps",dp:1,rating:c[1]}));
  CDS_INDICES.forEach(x=>addInstrument({fam:"cdsi",key:x,name:x,ref:rand(54,116),unit:"bps",dp:2}));
  CORP_ISSUERS.forEach(c=>addInstrument({fam:"trs",key:"TRS on "+c[0],name:"TRS on "+c[0],ref:rand(88,315),unit:"bps",dp:1,rating:c[1]}));
})();

/* An instrument for a product: drawn from that product's family, with the
   quoting label the product actually uses bolted on at trade time. */
function instrumentFor(prod){
  const fam=PROD_BY_NAME[prod].fam;
  const pool=INST_BY_FAM[fam]||INSTRUMENTS;
  if(fam==="fx") return choice(pool.filter(x=>prod==="FX Futures"?x.key.indexOf(" future")>0:x.key.indexOf(" future")<0));
  if(fam==="rate") return choice(pool.filter(x=>x.key.indexOf(" "+prod)>0))||choice(pool);
  return choice(pool);
}
/* The name that goes on the ticket. Options carry the structure; rates and repo
   already carry their convention in the instrument key. */
function instrumentLabel(inst,prod){
  const s=STRUCTURES[prod];
  return s?inst.name+" "+choice(s):inst.name;
}
/* The same label every time for a given instrument and product. A caller that
   picked the instrument itself is building legs that have to match — an
   offsetting pair whose two legs read "25d call" and "ATM straddle" is not a
   pair, it is two different trades. */
function stableLabel(inst,prod){
  const s=STRUCTURES[prod];
  return s?inst.name+" "+s[Math.floor(hashUnit(inst.i,prod.length,7)*s.length)%s.length]:inst.name;
}
/* One scale for every convention: rate/price families measure distance in bps of
   the level, yield/spread families in outright bps. */
function devBpsOf(unit,px,mid){
  if(unit==="%"||unit==="bps") return (px-mid)*(unit==="%"?100:1);
  return mid?((px-mid)/Math.abs(mid))*10000:0;
}
/* Push a trade this many bps away from mid, keeping the sign convention — and
   keeping the result quotable. A yield or a credit spread driven through zero
   is not an aggressive print, it is a broken one. */
function applyDev(t,bps){
  const u=t.unit, sgn=t.dir==="Buy"||t.dir==="Pay"||t.dir==="Borrow"?1:-1;
  if(u==="%"||u==="bps"){
    const step=(u==="%"?bps/100:bps)*sgn;
    const lo=t.mktPx>0?t.mktPx*0.12:t.mktPx;
    t.px=Math.max(lo,t.mktPx+step);
  } else {
    t.px=t.mktPx*(1+Math.max(-0.85,bps/10000*sgn));
  }
  t.devBps=devBpsOf(u,t.px,t.mktPx);
  return t;
}
/* An off-market move sized for the instrument: a multiple of its materiality
   threshold, never more than a sensible fraction of the level it is quoted at.
   Eighty basis points is an aggressive print on a 400 bps credit and nonsense
   on a 56 bps index. */
function devFor(inst,mult){
  // Premium-quoted names have no price floor to work from, so the move is sized
  // off the premium's own spread instead.
  if(inst.omFloor<=0) return inst.spreadBps*Math.max(1.2,mult*0.8);
  const raw=omThreshold(inst)*mult;
  // Six times the materiality floor is already a scandal; beyond that the print
  // stops being off-market and starts being unquotable.
  let cap=inst.omFloor*6;
  if(inst.unit==="bps") cap=Math.min(cap,Math.abs(inst.ref)*0.55);
  if(inst.unit==="%")   cap=Math.min(cap,Math.abs(inst.ref)*100*0.55);
  return Math.min(raw,cap);
}
/* A planted deal is sized against the trader who booked it. Unless the rule is
   itself about breaching an authorisation, nothing in the book should be a
   ticket the trader could not have written. */
function sizeFor(tr,lo,hi){
  const b=BASE[tr.id];
  return Math.min(tr.ticketLimit*0.97,Math.max(0.4,(b?b.medSize:8)*rand(lo,hi)));
}

/* A swap is paid or received and a repo is borrowed or lent — a planted pattern
   that says "Buy" on an IRS reads as a data error, not as a finding. */
const DIR_WORDS={rate:["Pay","Receive"],repo:["Borrow","Lend"],dflt:["Buy","Sell"]};
function dirFor(fam){ const w=DIR_WORDS[fam]||DIR_WORDS.dflt; return rng()<0.5?w[0]:w[1]; }
const longDir=prod=>(DIR_WORDS[PROD_BY_NAME[prod].fam]||DIR_WORDS.dflt)[0];
const shortDir=prod=>(DIR_WORDS[PROD_BY_NAME[prod].fam]||DIR_WORDS.dflt)[1];
const oppDir=d=>({Buy:"Sell",Sell:"Buy",Pay:"Receive",Receive:"Pay",Borrow:"Lend",Lend:"Borrow"}[d]||d);

/* Desks sit in different time zones; the surveillance clock is desk-local, which
   is what makes "booked at 23:40" meaningful rather than a timezone artefact. */
const DESK_HOURS={Singapore:[8,18.5],"Hong Kong":[8.5,18.5],London:[7,19]};
function execMinFor(desk){
  const h=DESK_HOURS[desk.region]||[8,18];
  // Two humps: the local open and the London/NY overlap late in the session.
  const r=rng();
  const hr=r<0.42?rand(h[0],h[0]+3.2):r<0.75?rand(h[0]+3.2,h[1]-3):rand(h[1]-3,h[1]);
  return Math.round(hr*60+rand(0,59)%60);
}
const SETTLE_DAYS={"FX Spot":2,"FX Forward":30,"FX Swap":30,"NDF":30,"Govt Bond":2,"Corp Bond":2,"Repo":1,"Reverse Repo":1};
