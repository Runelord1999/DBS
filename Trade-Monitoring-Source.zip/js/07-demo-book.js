/* ============================================================
   The book — one year of daily trading across every desk
============================================================ */
const TRADES=[];
const TRADES_BY_ID={};
const byTraderDay=new Map();          // traderId|dayIdx -> [trade]
const dayTrades=Array.from({length:DAYS},()=>[]);
let _seq=0;
function tid(){ _seq++; return "TRD-"+String(_seq).padStart(6,"0"); }

function makeTrade(dayIdx,trader,prod,opts){
  opts=opts||{};
  const desk=DESK_BY_ID[trader.deskId];
  const meta=PROD_BY_NAME[prod];
  const inst=opts.inst||instrumentFor(prod);
  const date=dateForIdx(dayIdx);
  const notional=opts.notional!=null?opts.notional:Math.max(0.4,lognorm(meta.med,meta.sig));
  const dir=opts.dir||dirFor(meta.fam);
  const execMin=opts.execMin!=null?opts.execMin:execMinFor(desk);
  // The market mid at the moment of execution, off the instrument's own path.
  // Two deals in the same name in the same minute see the same mark.
  const mktPx=midAt(inst,dayIdx,execMin);
  // Ordinary execution sits inside that instrument's own bid/offer, sign
  // following the direction of the trade — the desk earns the spread.
  const spreadBps=opts.spreadBps!=null?opts.spreadBps:inst.spreadBps*rand(0.3,1.55);
  const lag=opts.captureLag!=null?opts.captureLag:weightedChoice([[rand(0,3),70],[rand(3,15),22],[rand(15,60),7],[rand(60,210),1]]);
  const ctpy=opts.ctpy||choice(trader.ctpys||COUNTERPARTIES);
  const t={
    id:tid(), dayIdx, date, dateStr:fmtDate(date), iso:isoDate(date),
    deskId:desk.id, deskName:desk.name, deskShort:desk.short, region:desk.region,
    traderId:trader.id, trader:trader.name, book:opts.book||trader.book,
    product:prod, ac:meta.ac, fam:meta.fam, instKey:inst.key,
    instrument:opts.label||(opts.inst?stableLabel(inst,prod):instrumentLabel(inst,prod)), rating:inst.rating||"",
    tenor:opts.tenor||choice(meta.tenors), notional, dir,
    unit:inst.unit, dp:inst.dp, mktPx, px:0, devBps:0,
    vol:null, mktVol:null,
    ctpy:ctpy.name, ctpyType:ctpy.type, ctpyCountry:ctpy.country,
    channel:opts.channel||weightedChoice(CHANNELS), venue:opts.venue||choice(VENUES),
    execMin, captureLag:Math.round(lag),
    amends:rng()<0.045?1:0, cancelled:false,
    status:"", pnl:0, ssiChanged:false, internal:!!opts.internal,
    valueDate:new Date(date.getTime()+(SETTLE_DAYS[prod]||90)*dayMs),
    flags:[], alerts:[],
  };
  const sv=volAt(inst,dayIdx);
  if(sv!=null){ t.mktVol=+sv.toFixed(2); t.vol=+(sv+rand(-0.28,0.28)).toFixed(2); }
  applyDev(t,spreadBps);
  if(opts.px!=null){ t.px=opts.px; t.devBps=devBpsOf(t.unit,t.px,t.mktPx); }
  // P&L is the value captured against mid plus ordinary mark movement, both in
  // bps of notional, so the number on the ticket reconciles to the deviation
  // printed next to it.
  const M=FAM_MKT[meta.fam];
  t.pnl=opts.pnl!=null?opts.pnl
    :+(t.notional*0.1*(Math.abs(t.devBps)*M.bpW+rand(-1,1)*M.noiseBps)).toFixed(1);
  const age=DAYS-1-dayIdx;
  t.status=opts.status||(rng()<0.014?"Amended":age>SETTLE_DAYS[prod]?"Settled":"Live");
  if(t.status==="Amended") t.amends=Math.max(1,t.amends);
  TRADES.push(t); TRADES_BY_ID[t.id]=t;
  dayTrades[dayIdx].push(t);
  const k=trader.id+"|"+dayIdx;
  if(!byTraderDay.has(k)) byTraderDay.set(k,[]);
  byTraderDay.get(k).push(t);
  return t;
}

(function buildBook(){
  for(let d=0; d<DAYS; d++){
    const date=dateForIdx(d);
    if(!isBiz(date)) continue;
    const dom=date.getDate(), eom=new Date(date.getFullYear(),date.getMonth()+1,0).getDate();
    // Quarter and month ends are genuinely busier; so is the run into a roll date.
    const eomBoost=dom>=eom-1?1.35:dom>=eom-3?1.15:1;
    const seasonal=0.86+0.28*Math.sin(d/58);
    DESKS.forEach(desk=>{
      const n=Math.max(1,Math.round(desk.traders.length*desk.dpt*seasonal*eomBoost*rand(0.72,1.28)));
      for(let i=0;i<n;i++){
        const trader=weightedChoice(desk.traders.map(t=>[t,t.grade==="Associate"?1.35:t.grade==="Senior"?1.15:0.85]));
        // Traders keep to their own approved list in the ordinary course, and to
        // their own ticket authorisation — so a breach of either is the trader's
        // exception, not a desk-wide artefact.
        const prod=choice(trader.products);
        makeTrade(d,trader,prod,{notional:Math.min(trader.ticketLimit*0.94,Math.max(0.4,lognorm(PROD_BY_NAME[prod].med,PROD_BY_NAME[prod].sig)))});
      }
    });
  }
})();

/* ============================================================
   Desk revenue — what the floor earned, deal by deal

   The Trade Activity tab can be read in transactions or in P&L. Transactions
   come straight off the book; P&L has to be modelled, because a booking system
   records what was traded, not what the desk made on it.

   The model is the one a markets business actually runs on: revenue is the
   spread captured on the way through, not a mark-to-market. It is built from
   the instrument's own dealing spread, which is already modelled per instrument
   and is what the pricing rules test against — so the P&L view and the
   surveillance thresholds are reading the same number, and a wide-spread name
   earns more here for the same reason an off-market print there is harder to
   call.

   Calibration, with real-world anchors:
     FX spot        0.5 bps spread  ->  ~25 USD per million traded. Interbank
                    EUR/USD quotes around 0.1-0.5 pips on a 1.08 handle, which
                    is 0.1-0.5 bps, so the floor of the range.
     Govt bonds     ~1.2 bps        ->  ~60 per million.
     Corporate      ~21 bps         ->  ~1,000 per million. Median investment
                    grade bid-ask has been reported around 8-10 bps of par on
                    electronic platforms and wider by voice for size.
     Repo           ~1.9 bps        ->  ~10 per million after the financing
                    adjustment. Repo is a balance-sheet business, not a spread
                    one, so it is deliberately damped.
     FX options     quoted on premium, not notional. Spread is applied to the
                    premium and the premium is a few per cent of notional.

   For contrast, retail FX brokers report revenue per million traded of roughly
   60-100 USD. An institutional desk earns a fraction of that per unit, on
   volumes several orders of magnitude larger.

   Four things move the margin on an individual ticket, all of them real:
   electronic flow prices tighter than voice, a bank counterparty prices tighter
   than a corporate, a larger ticket prices tighter per million, and a longer
   tenor earns more because the risk carried is larger.
============================================================ */
/* Premium as a fraction of notional, for products whose spread is quoted on the
   premium rather than on the notional. An option on 10m notional does not trade
   on 10m of value. */
const PREMIUM_FRAC={fxopt:0.022,eqopt:0.028};
/* How much of the quoted spread the desk actually keeps, as a fraction of the
   full bid-offer. Never all of it: the quoted mid is not where risk is recycled,
   and the hedge costs something. */
const SPREAD_CAPTURE=0.85;
/* Electronic flow is priced tighter than voice, and an internal transfer earns
   nothing — it moves risk between two of the bank's own books. */
const CHANNEL_MARGIN={"Voice":1.30,"eComm single-dealer":0.95,
  "Multi-dealer platform":0.60,"API / Algo":0.48,"Internal booking":0.05};
/* A corporate hedging an exposure pays more than a bank recycling risk. */
const CTPY_MARGIN={"Corporate":1.50,"Private Client":1.65,"Insurer":1.20,
  "Asset Manager":1.00,"Bank":0.70,"Hedge Fund":0.78,"Broker":0.60};
/* Per-family calibration. The quoted spread and the duration conversion get the
   shape right; this brings each family onto the revenue per million a markets
   business of this kind actually reports, which the spread alone does not,
   because some products are priced on the spread and earned on something else.
   Repo is financing — the earnings are in the rate, not in the bid-offer.
   Credit and equity flow is recycled far more cheaply than the screen spread
   suggests.

   Calibrated on the finished book, not the unplanted one: the revenue rules
   plant mark-ups and pull-forwards that are real revenue the desk booked, and
   a floor whose reported margin excluded them would not be the floor the P&L
   view draws. They come to about eight per cent of the year's revenue. The
   target each factor is calibrated to, in USD per million traded:

     FX spot and forward   20      Govt bonds       30
     NDF                   70      Corporate bonds 700
     FX options           200      Repo              4
     Interest rate swaps   55      CDS single name 280
     Equity swaps          60      CDS index        40
     Equity options       220      Total return     90                        */
const FAM_MARGIN={fx:1.03,ndf:0.45,fxopt:1.20,rate:0.75,bondg:0.84,bondc:0.88,
  repo:0.62,cds:0.42,cdsi:0.35,eq:0.51,eqopt:1.06,trs:0.50};

/* Which families quote their spread in RATE basis points rather than in price.
   This is the difference between a rough model and a wrong one. A 0.45 bp
   bid-offer on a ten-year swap is not 0.45 bp of notional — it is 0.45 bp of
   rate, and its cash value is that multiplied by the duration of the trade,
   which is why the long end of a swap book earns many times what the front end
   does on the same notional. Bonds and equities already quote in price, and FX
   in the rate itself, so they convert one for one. */
const RATE_QUOTED={rate:1,cds:1,cdsi:1,repo:1};
function cashDuration(t){
  if(!RATE_QUOTED[t.fam]) return 1;
  const y=tenorYears(t.tenor);
  const yrs=isFinite(y)&&y>0?y:1;
  // Modified duration, flattened at the long end where convexity and the
  // shape of the curve stop it growing one for one with maturity.
  return Math.min(16,Math.max(0.02,yrs<=1?yrs*0.9:1+(yrs-1)*0.82));
}

/* Revenue on one ticket, in USD thousands to match the rest of the book. */
function dealRevenue(t){
  const inst=INST_BY_KEY[t.instKey];
  if(!inst||t.internal) return 0;
  const half=(inst.spreadBps||0.5)/2*SPREAD_CAPTURE;      // bps of the quoted measure
  // Options quote on premium; everything else on notional.
  const pf=PREMIUM_FRAC[t.fam];
  const value=pf?t.notional*pf:t.notional;                 // USD millions exposed to the spread
  // Larger tickets price finer. Flattened, not linear: a 100m ticket is not a
  // hundred times cheaper per million than a 1m one.
  const sizeMult=Math.min(1.35,Math.max(0.45,Math.pow(12/Math.max(0.5,t.notional),0.13)));
  const mult=(CHANNEL_MARGIN[t.channel]??1)*(CTPY_MARGIN[t.ctpyType]??1)*
             (FAM_MARGIN[t.fam]??1)*sizeMult*cashDuration(t);
  // bps of value, in USD thousands: value is already in millions, so one basis
  // point of a million is 100 dollars, which is 0.1 thousand.
  return value*half*0.1*mult;
}
