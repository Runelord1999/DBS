/* ============================================================
   The book — one year of daily trading across every desk
============================================================ */
const TRADES=[];
const TRADES_BY_ID={};
const byTraderDay=new Map();          // traderId|dayIdx -> [trade]
const dayTrades=Array.from({length:DAYS},()=>[]);
let _seq=0;
function tid(){ _seq++; return "TRD-"+String(_seq).padStart(6,"0"); }

function makeTrade(dayIdx,trader,prod,opts){
  opts=opts||{};
  const desk=DESK_BY_ID[trader.deskId];
  const meta=PROD_BY_NAME[prod];
  const inst=opts.inst||instrumentFor(prod);
  const date=dateForIdx(dayIdx);
  const notional=opts.notional!=null?opts.notional:Math.max(0.4,lognorm(meta.med,meta.sig));
  const dir=opts.dir||dirFor(meta.fam);
  const execMin=opts.execMin!=null?opts.execMin:execMinFor(desk);
  // The market mid at the moment of execution, off the instrument's own path.
  // Two deals in the same name in the same minute see the same mark.
  const mktPx=midAt(inst,dayIdx,execMin);
  // Ordinary execution sits inside that instrument's own bid/offer, sign
  // following the direction of the trade — the desk earns the spread.
  const spreadBps=opts.spreadBps!=null?opts.spreadBps:inst.spreadBps*rand(0.3,1.55);
  const lag=opts.captureLag!=null?opts.captureLag:weightedChoice([[rand(0,3),70],[rand(3,15),22],[rand(15,60),7],[rand(60,210),1]]);
  const ctpy=opts.ctpy||choice(trader.ctpys||COUNTERPARTIES);
  const t={
    id:tid(), dayIdx, date, dateStr:fmtDate(date), iso:isoDate(date),
    deskId:desk.id, deskName:desk.name, deskShort:desk.short, region:desk.region,
    traderId:trader.id, trader:trader.name, book:opts.book||trader.book,
    product:prod, ac:meta.ac, fam:meta.fam, instKey:inst.key,
    instrument:opts.label||(opts.inst?stableLabel(inst,prod):instrumentLabel(inst,prod)), rating:inst.rating||"",
    tenor:opts.tenor||choice(meta.tenors), notional, dir,
    unit:inst.unit, dp:inst.dp, mktPx, px:0, devBps:0,
    vol:null, mktVol:null,
    ctpy:ctpy.name, ctpyType:ctpy.type, ctpyCountry:ctpy.country,
    channel:opts.channel||weightedChoice(CHANNELS), venue:opts.venue||choice(VENUES),
    execMin, captureLag:Math.round(lag),
    amends:rng()<0.045?1:0, cancelled:false,
    status:"", pnl:0, ssiChanged:false, internal:!!opts.internal,
    valueDate:new Date(date.getTime()+(SETTLE_DAYS[prod]||90)*dayMs),
    flags:[], alerts:[],
  };
  const sv=volAt(inst,dayIdx);
  if(sv!=null){ t.mktVol=+sv.toFixed(2); t.vol=+(sv+rand(-0.28,0.28)).toFixed(2); }
  applyDev(t,spreadBps);
  if(opts.px!=null){ t.px=opts.px; t.devBps=devBpsOf(t.unit,t.px,t.mktPx); }
  // P&L is the value captured against mid plus ordinary mark movement, both in
  // bps of notional, so the number on the ticket reconciles to the deviation
  // printed next to it.
  const M=FAM_MKT[meta.fam];
  t.pnl=opts.pnl!=null?opts.pnl
    :+(t.notional*0.1*(Math.abs(t.devBps)*M.bpW+rand(-1,1)*M.noiseBps)).toFixed(1);
  const age=DAYS-1-dayIdx;
  t.status=opts.status||(rng()<0.014?"Amended":age>SETTLE_DAYS[prod]?"Settled":"Live");
  if(t.status==="Amended") t.amends=Math.max(1,t.amends);
  TRADES.push(t); TRADES_BY_ID[t.id]=t;
  dayTrades[dayIdx].push(t);
  const k=trader.id+"|"+dayIdx;
  if(!byTraderDay.has(k)) byTraderDay.set(k,[]);
  byTraderDay.get(k).push(t);
  return t;
}

(function buildBook(){
  for(let d=0; d<DAYS; d++){
    const date=dateForIdx(d);
    if(!isBiz(date)) continue;
    const dom=date.getDate(), eom=new Date(date.getFullYear(),date.getMonth()+1,0).getDate();
    // Quarter and month ends are genuinely busier; so is the run into a roll date.
    const eomBoost=dom>=eom-1?1.35:dom>=eom-3?1.15:1;
    const seasonal=0.86+0.28*Math.sin(d/58);
    DESKS.forEach(desk=>{
      const n=Math.max(1,Math.round(desk.traders.length*desk.dpt*seasonal*eomBoost*rand(0.72,1.28)));
      for(let i=0;i<n;i++){
        const trader=weightedChoice(desk.traders.map(t=>[t,t.grade==="Associate"?1.35:t.grade==="Senior"?1.15:0.85]));
        // Traders keep to their own approved list in the ordinary course, and to
        // their own ticket authorisation — so a breach of either is the trader's
        // exception, not a desk-wide artefact.
        const prod=choice(trader.products);
        makeTrade(d,trader,prod,{notional:Math.min(trader.ticketLimit*0.94,Math.max(0.4,lognorm(PROD_BY_NAME[prod].med,PROD_BY_NAME[prod].sig)))});
      }
    });
  }
})();
