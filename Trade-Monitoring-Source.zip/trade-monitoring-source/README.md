# Trade Monitoring — source

The dashboard as editable source. It is plain HTML, CSS and JavaScript: no
framework, no package manager, no build step and no runtime dependencies. The
only tool here is a shell script that concatenates the files back into one
`.html`, and even that is a convenience — `index.html` runs the modules
directly.

## Layout

    index.html            markup shell; loads the stylesheet and the modules in order
    css/dashboard.css     all styling, themed through CSS custom properties
    js/01 … js/32         the application, in load order
    build.sh              concatenate back into a single self-contained .html

## Load order matters

These are **classic scripts sharing one top-level scope**, not ES modules.
A `const` declared in `js/09-rules.js` is visible to `js/20-pane-overview.js`
because they execute in sequence into the same scope. The numeric prefixes are
the execution order, and reordering them will break the file. If you move to a
bundler, keep the order and concatenate rather than treating each file as an
independent module.

## What is demo data

Six modules carry the synthetic book and nothing else:

    js/03-demo-desks.js         desks and traders
    js/04-demo-instruments.js   instrument universe (and, from line 59, the
                                product taxonomy — configuration, not data)
    js/06-demo-market.js        a generated price path per instrument
    js/07-demo-book.js          a year of trades
    js/11-demo-alerts.js        the alert generator — the 20 pattern plants
    js/12-demo-reviews.js       a seeded review history

`./build.sh --no-demo-data` omits them, but the result will not run on its own:
the application still expects the globals those modules declared. The
production shell in the companion archive is that build with a data adapter
already written against the contract.

## Rebuilding

    ./build.sh                      -> trade-monitoring-app.html
    ./build.sh --no-demo-data       -> trade-monitoring-nodata.html

The concatenation is lossless: rebuilding from these sources reproduces the
original single-file dashboard byte for byte in CSS, markup and script.

## Theming

Everything visual is a CSS custom property on `:root` in `css/dashboard.css`,
redefined per theme under `[data-theme="…"]`. Three themes ship — light, dark
and a red corporate one. Charts read the same variables through `var(--…)` in
their SVG attributes, so retheming the charts means editing the variables, not
the chart code.

## Browser support

Modern evergreen browsers. The code uses `color-mix()`, CSS custom properties,
`IntersectionObserver`-free rendering and plain ES2020 syntax. There is no
transpilation step and no polyfill; if you must support an older estate, run it
through your own toolchain.

## A note on the brand link

The heading in the rail links to `index.html`, which in this archive is the
application itself. Point it wherever your deployment wants.
