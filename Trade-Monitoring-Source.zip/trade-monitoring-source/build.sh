#!/bin/sh
# Rebuild the single-file dashboard from these sources.
#   ./build.sh                       -> trade-monitoring-app.html  (with demo data)
#   ./build.sh --no-demo-data OUT    -> omits every js/*-demo-*.js module
#
# Output is one self-contained .html making no external requests: openable from
# a file share or an intranet path with no build step and no server.
set -e
SKIP_DEMO=0
OUT=trade-monitoring-app.html
if [ "$1" = "--no-demo-data" ]; then SKIP_DEMO=1; shift; OUT=trade-monitoring-nodata.html; fi
[ -n "$1" ] && OUT="$1"
{
  sed -n '1,/<title>/p' index.html
  printf '<style>\n'; cat css/dashboard.css; printf '</style>\n</head>\n'
  sed -n '/<body>/,$p' index.html | sed '/<script src=/d; /<\/body>/d; /<\/html>/d'
  printf '<script>\n'
  for f in js/*.js; do
    case "$f" in *-demo-*) [ "$SKIP_DEMO" = "1" ] && continue ;; esac
    cat "$f"; printf '\n'
  done
  printf '</script>\n</body>\n</html>\n'
} > "$OUT"
echo "wrote $OUT ($(wc -c < "$OUT") bytes)"
