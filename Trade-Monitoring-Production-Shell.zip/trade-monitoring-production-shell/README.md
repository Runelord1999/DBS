# Trade Monitoring — production shell

The same application with every demo-data generator removed. It holds no data
of its own: it reads one payload through a single adapter and renders.

## What is different from the demo build

Removed — roughly 1,900 lines of generator:

    desks and traders, the instrument universe, the generated price paths,
    a year of synthetic trades, the alert generator, the seeded review history

Kept, because none of it is sample data:

    js/03-config-taxonomy.js      products, asset classes, tenor and size bands
    js/04-config-market-context.js  market-context maths for the case file
    js/05-config-review.js        reason codes and decision persistence
    js/09-rules.js                the 58 typologies
    js/10-data-dictionary.js      the 62 data elements and per-rule requirements

Added:

    js/06-data-adapter.js         the only file that touches bank data
    js/07-derive.js               indices, built after the payload arrives
    js/99-data-boot.js            start-up

## Running it

    python3 -m http.server 8080     # any static server will do
    open http://localhost:8080/

It needs a server because it fetches `data.json`. Opening `index.html` straight
off disk will have the browser block that fetch, and the page will say so.

To avoid the fetch entirely, set `window.TM_DATA` from a script your own server
renders before `js/06-data-adapter.js` loads. The adapter prefers it.

## The payload

`DATA-CONTRACT.md` specifies it field by field. `data.json` in this folder is a
working example: 60 days drawn from the demo generator, 8,931 trades and 759
alerts across 68 traders. It also carries every older deal an alert in the window
cites — a rule measured over 60 business days reaches back past a 60-day cut —
so every tradeId in it resolves. Every one of the eight panes renders from it, which
is how the contract was verified — swap the file for your own and the same
code path serves real data.

Field-level specifications, lengths, nullability and the rule-by-rule
dependency matrix are in *Trade-Surveillance-Data-Schema.xlsx*. Where to find
each field in the bank's own systems is in
*Trade-Monitoring-Source-Data-Checklist.xlsx*.

## When data is missing

The shell does not render an empty dashboard, because a dashboard showing
nothing looks exactly like a quiet trading day. It states what went wrong and
names the missing keys:

    The payload was found but could not be read.
    payload is missing: instruments, baselines

## Market data

`quotes` in the payload is FACT_MARKET_QUOTE, and it drives the two market
charts inside the alert case file. `midAt()` in
`js/04-config-market-context.js` reads it through an index the adapter builds —
one mid series per instrument per day — interpolating between observations
rather than snapping to the last one, so the line reads as a market rather than
a staircase.

It is the one optional part of the payload. Without it every panel still
renders and every case file still opens; the chart is replaced by a line naming
the instrument it has no quotes for. That path is tested, not assumed.

One thing to get right: a deal's `mktPx` and the chart's series must come from
the same tick store, or the case file will state a deviation the chart does not
show, in front of a reviewer about to act on it. DATA-CONTRACT.md covers the
resolution the charts actually read, which is lower than a full tick feed.

## Tables and paging

Every table that can outgrow a screen pages, and the long card grids (the rule
library, the trader risk index, trading activity by trader) load in batches as
the reader scrolls. The rules are the same everywhere: the full set is filtered
and sorted first and only then cut to a page, so every count, total and
highlight describes all the matching rows; a changed filter, search or sort
returns to page one; nothing is cut off at a fixed count. The helpers are
`pager()`, `localPaged()` and `lazyGrid()` in `js/19-panel-guidance.js`.

Here the paging happens in the browser, over the whole payload. That is
comfortable at the demo's scale — the example `data.json` is 13.6 MB for 60
days — but a payload far larger than that should not be shipped to the browser
whole. Move the paging to your server then: the endpoint behind each table must
apply the same filter and sort to the full set, return the total, and accept a
page offset and size. The pager's "of N" has to be that server total, or a
heatmap cell will open into a queue that disagrees with it.

## Flattening

    ./build.sh      -> trade-monitoring-shell.html

One self-contained file, still expecting `window.TM_DATA` or a served
`data.json`.
