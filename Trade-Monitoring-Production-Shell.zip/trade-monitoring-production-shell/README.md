# Trade Monitoring — production shell

The same application with every demo-data generator removed. It holds no data
of its own: it reads one payload through a single adapter and renders.

## What is different from the demo build

Removed — roughly 1,900 lines of generator:

    desks and traders, the instrument universe, the generated price paths,
    a year of synthetic trades, the alert generator, the seeded review history

Kept, because none of it is sample data:

    js/03-config-taxonomy.js      products, asset classes, tenor and size bands
    js/04-config-market-context.js  market-context maths for the case file
    js/05-config-review.js        reason codes and decision persistence
    js/09-rules.js                the 50 typologies
    js/10-data-dictionary.js      the 60 data elements and per-rule requirements

Added:

    js/06-data-adapter.js         the only file that touches bank data
    js/07-derive.js               indices, built after the payload arrives
    js/99-data-boot.js            start-up

## Running it

    python3 -m http.server 8080     # any static server will do
    open http://localhost:8080/

It needs a server because it fetches `data.json`. Opening `index.html` straight
off disk will have the browser block that fetch, and the page will say so.

To avoid the fetch entirely, set `window.TM_DATA` from a script your own server
renders before `js/06-data-adapter.js` loads. The adapter prefers it.

## The payload

`DATA-CONTRACT.md` specifies it field by field. `data.json` in this folder is a
working example: 60 days drawn from the demo generator, 8,463 trades and 719
alerts across 68 traders. Every one of the eight panes renders from it, which
is how the contract was verified — swap the file for your own and the same
code path serves real data.

Field-level specifications, lengths, nullability and the rule-by-rule
dependency matrix are in *Trade-Surveillance-Data-Schema.xlsx*. Where to find
each field in the bank's own systems is in
*Trade-Monitoring-Source-Data-Checklist.xlsx*.

## When data is missing

The shell does not render an empty dashboard, because a dashboard showing
nothing looks exactly like a quiet trading day. It states what went wrong and
names the missing keys:

    The payload was found but could not be read.
    payload is missing: instruments, baselines

## Known limitation

`midAt()` in `js/04-config-market-context.js` returns the market mid at a
moment. The demo walked a generated price path, which is not part of the
payload. Only the two market charts inside the alert case file depend on it;
every other panel runs without it. Point it at the tick store to bring them up.

## Flattening

    ./build.sh      -> trade-monitoring-shell.html

One self-contained file, still expecting `window.TM_DATA` or a served
`data.json`.
