# Data contract

The production shell declares no data of its own. It reads one payload, hydrates
it, and renders. This file specifies that payload exactly: every field below was
taken from a working example (`data.json`), not drafted by hand.

## Supplying it

Either set `window.TM_DATA` before `js/06-data-adapter.js` loads — a `<script>`
your server renders is the usual way — or serve `data.json` next to the page.
The second needs a web server; opening the page from disk will have the browser
block the fetch, and the page says so rather than rendering empty.

## Top level

| key | type | required | holds |
|---|---|---|---|
| `meta` | object | no | provenance; ignored by the app |
| `desks` | array | **yes** | DIM_DESK |
| `traders` | array | **yes** | DIM_TRADER, with the mandate and limits on each row |
| `counterparties` | array | **yes** | DIM_COUNTERPARTY |
| `instruments` | array | **yes** | DIM_INSTRUMENT |
| `trades` | array | **yes** | FACT_TRADE |
| `alerts` | array | **yes** | FACT_ALERT, each citing trade ids |
| `baselines` | object | **yes** | AGG_TRADER_BASELINE, keyed by trader id |
| `quotes` | array | no | FACT_MARKET_QUOTE — the tick store behind the market chart |

Table names refer to *Trade-Surveillance-Data-Schema.xlsx*, which carries the
full specification — lengths, nullability, keys, domains and the rule-by-rule
dependency matrix. This file is only the wire format.

## What the adapter builds for you

The payload carries facts only. Nothing in it points at anything else, because
JSON cannot hold a cycle and a hand-maintained cross-reference goes stale. The
adapter rebuilds, on load:

- `DESK_BY_ID`, `TRADER_BY_ID`, `INST_BY_KEY`, `TRADES_BY_ID`, `ALERT_BY_ID`
- `desk.traders` — from each trader's `deskId`
- `trader.peers` — the cohort, grouped on `trader.cohort`
- `trade.alerts` — the back-reference, from each alert's `tradeIds`
- `trade.flags` — the rule ids citing that trade
- `byTraderDay` — a `traderId|dayIdx` index the activity charts read
- `QUOTES` — one mid series per instrument per day, sorted by minute
- `trade.date`, `alert.date` — `Date` objects parsed from the `iso` strings

Send the facts and let it index them. Do not try to pre-build these.

## Date handling

Every row carries `iso` (`YYYY-MM-DD`) and `dayIdx`, an integer offset where 0
is the first day of the window and `DAYS-1` is today. `dayIdx` is what the
charts bin on, so it must be consistent across trades, alerts and quotes.

## Records

### `desks[]`

One per reporting desk.

| field | type | example |
|---|---|---|
| `id` | string | `"D1"` |
| `name` | string | `"G10 FX Spot & Forwards"` |
| `region` | string | `"Singapore"` |
| `short` | string | `"G10 FX"` |
| `dpt` | number | `4` |
| `mandate` | array | `["FX Spot", "FX Forward", "FX Swap"]` |

### `traders[]`

One per trader. The authorisation fields — `ticketLimit`, `posLimit`, `tenorYrs`, `ctpyCap`, `products` — come from the mandate register and are what the limits rules test against. `leave` is `[firstDayIdx, lastDayIdx]` of mandatory block leave. Send every field: the case file reads most of them.

| field | type | example |
|---|---|---|
| `id` | string | `"T01"` |
| `name` | string | `"Adrian Koh"` |
| `deskId` | string | `"D1"` |
| `grade` | string | `"Senior"` |
| `risk` | number | `0.1` |
| `arc` | null | `null` |
| `book` | string | `"D1-BK01"` |
| `leave` | array | `[29, 42]` |
| `ticketLimit` | number | `40` |
| `posLimit` | number | `250` |
| `tenorYrs` | number | `10` |
| `ctpyCap` | number | `0.38` |
| `products` | array | `["FX Spot", "FX Forward", "FX Swap"]` |
| `ctpys` | array | `[{"name": "Helios Atlantic Bank", "type": "Bank",…` |
| `supervisor` | string | `"Nadia Farrell"` |
| `fineKey` | string | `"Senior \u00b7 FX & Options"` |
| `cohort` | string | `"Senior \u00b7 FX & Options"` |

### `counterparties[]`

One per legal entity.

| field | type | example |
|---|---|---|
| `name` | string | `"Meridian Global Bank"` |
| `type` | string | `"Bank"` |
| `country` | string | `"London"` |

### `instruments[]`

One per instrument. `spreadBps` and `omFloor` set the per-instrument materiality threshold the pricing rules use. `key` is what `quotes.instrumentId` joins on.

| field | type | example |
|---|---|---|
| `i` | number | `1` |
| `key` | string | `"EUR/USD"` |
| `name` | string | `"EUR/USD"` |
| `fam` | string | `"fx"` |
| `unit` | string | `"rate"` |
| `dp` | number | `5` |
| `ref` | number | `1.0842` |
| `dv` | number | `0.0043368` |
| `spreadBps` | number | `0.49550211153924467` |
| `omFloor` | number | `22` |
| `rating` | string | `""` |
| `collateral` | string | `""` |
| `tenors` | null | `null` |

### `trades[]`

One per deal. The largest array by far.

**Three money fields, three meanings.** `pnl` is the money value of the deal's
own price deviation — notional against `devBps` — and is what the mismarking and
loss-day rules measure; it is a surveillance quantity, not a revenue one.
`clientRevenue` is the dealing revenue earned on the ticket, and `revenue` is
that plus the result of holding the risk, which is what the Trade Activity tab's
P&L view sums. In the demo the last two are modelled from each instrument's
quoted spread; at the bank they come from revenue attribution or product
control, and `pnl` from the same place it does today. In the data schema the
three are `FACT_TRADE.deal_pnl_usd`, `FACT_TRADE.client_revenue_usd` and
`FACT_TRADE.total_revenue_usd`. A deployment that cannot source `revenue` and
`clientRevenue` should leave them off: the P&L view then reads zero throughout,
and nothing else on the page is affected.

| field | type | example |
|---|---|---|
| `id` | string | `"TRD-044200"` |
| `dayIdx` | number | `305` |
| `date` | string | `"2026-06-05T00:00:00.000Z"` |
| `dateStr` | string | `"05 Jun 2026"` |
| `iso` | string | `"2026-06-05"` |
| `deskId` | string | `"D1"` |
| `deskName` | string | `"G10 FX Spot & Forwards"` |
| `deskShort` | string | `"G10 FX"` |
| `region` | string | `"Singapore"` |
| `traderId` | string | `"T37"` |
| `trader` | string | `"Aaron Whitfield"` |
| `book` | string | `"D1-BK37"` |
| `product` | string | `"FX Swap"` |
| `ac` | string | `"FX Cash"` |
| `fam` | string | `"fx"` |
| `instKey` | string | `"USD/JPY"` |
| `instrument` | string | `"USD/JPY"` |
| `rating` | string | `""` |
| `tenor` | string | `"3M"` |
| `notional` | number | `26.53787747828484` |
| `dir` | string | `"Sell"` |
| `unit` | string | `"rate"` |
| `dp` | number | `3` |
| `mktPx` | number | `146.40363629319558` |
| `px` | number | `146.39597372820853` |
| `devBps` | number | `-0.5233862478455247` |
| `vol` | null | `null` |
| `mktVol` | null | `null` |
| `ctpy` | string | `"Zenith Capital Bank"` |
| `ctpyType` | string | `"Bank"` |
| `ctpyCountry` | string | `"London"` |
| `channel` | string | `"API / Algo"` |
| `venue` | string | `"Exchange (SGX)"` |
| `execMin` | number | `1106` |
| `captureLag` | number | `103` |
| `amends` | number | `0` |
| `cancelled` | boolean | `false` |
| `status` | string | `"Settled"` |
| `pnl` | number | `3.4` |
| `ssiChanged` | boolean | `false` |
| `internal` | boolean | `false` |
| `valueDate` | string | `"2026-07-05T00:00:00.000Z"` |
| `clientRevenue` | number | `0.214` |
| `revenue` | number | `-0.02` |

### `alerts[]`

One per alert. `tradeIds` is what links it to the book.

| field | type | example |
|---|---|---|
| `id` | string | `"ALT-02835"` |
| `ruleId` | string | `"TS-22"` |
| `rule` | string | `"Persistent price improvement to one counterparty"` |
| `cat` | string | `"Pricing"` |
| `day` | number | `305` |
| `date` | string | `"2026-06-05T00:00:00.000Z"` |
| `dateStr` | string | `"05 Jun 2026"` |
| `iso` | string | `"2026-06-05"` |
| `raisedStr` | string | `"06 Jun 2026 06:40"` |
| `traderId` | string | `"T08"` |
| `trader` | string | `"Marcus Vellacourt"` |
| `deskId` | string | `"D3"` |
| `deskShort` | string | `"FX Options"` |
| `deskName` | string | `"FX Options & Exotics"` |
| `region` | string | `"Hong Kong"` |
| `sev` | string | `"Critical"` |
| `score` | number | `93` |
| `notional` | number | `75.15686444287658` |
| `tradeIds` | array | `["TRD-055242", "TRD-055243", "TRD-055244", "TRD-0…` |
| `acs` | array | `["FX Derivatives"]` |
| `products` | array | `["FX Variance Swap"]` |
| `summary` | string | `"8 fills to Blue Lantern Ventures averaging 6.4 b…` |
| `evidence` | array | `[{"k": "Counterparty", "v": "Blue Lantern Venture…` |
| `why` | string | `"No single fill breaches anything. The pattern is…` |
| `status` | string | `"Escalated"` |
| `reason` | string | `"Potential personal benefit or undisclosed conflict"` |
| `note` | string | `"Third occurrence for this trader on the same typ…` |
| `reviewer` | string | `"A. Fitzgerald"` |
| `reviewedStr` | string | `"09 Jun 2026 09:32"` |
| `audit` | array | `[{"ts": "06 Jun 2026 06:40", "actor": "Surveillan…` |
| `n` | number | `2834` |
| `reviewDay` | number | `309` |
| `hour` | number | `9` |
| `ctpys` | array | `["Blue Lantern Ventures"]` |
| `channels` | array | `["Multi-dealer platform", "Voice", "API / Algo", …` |
| `tenorBands` | array | `["1\u201312 months"]` |
| `sizeBands` | array | `["$5\u201310m", "$10\u201325m", "$1\u20135m"]` |

### `baselines{traderId}`

One per trader, keyed by trader id. Supply it from AGG_TRADER_BASELINE; where a trader is absent the shell computes a rough one from the delivered book.

| field | type | example |
|---|---|---|
| `deals` | number | `913` |
| `activeDays` | number | `244` |
| `tickets` | number | `3.7418032786885247` |
| `ticketsSd` | number | `1.9231464343765012` |
| `ticketsP95` | number | `7` |
| `dayNotional` | number | `64.73537219484864` |
| `dayNotionalSd` | number | `37.67935139716791` |
| `medSize` | number | `15.341469379441456` |
| `p95Size` | number | `37.599999999999994` |
| `ctpyCount` | number | `10` |
| `topCtpy` | string | `"Helios Atlantic Bank"` |
| `topCtpyShare` | number | `0.12705366922234393` |
| `products` | array | `["FX Swap", "FX Spot", "FX Forward"]` |
| `execMean` | number | `788.7382256297919` |
| `execSd` | number | `189.21950852862162` |
| `pnlMean` | number | `3.5397540983606577` |
| `pnlSd` | number | `7.535437372852948` |
| `lossDays` | number | `0.3155737704918033` |
| `amendRate` | number | `0.05585980284775466` |
| `amendsPerDeal` | number | `0.05585980284775466` |
| `cohort` | object | `{"tickets": 3.629032258064516, "dayNotional": 57.…` |

### `quotes[]`

The tick store, one row per observation. Optional — see below. `dayHigh`, `dayLow` and `impliedVol` are read from the first row of each instrument-day and may be omitted from the rest.

| field | type | example |
|---|---|---|
| `instrumentId` | string | `"USD/IDR vol"` |
| `dayIdx` | number | `281` |
| `m` | number | `420` |
| `mid` | number | `2.68678329` |
| `dayHigh` | number | `2.71598664` |
| `dayLow` | number | `2.66031055` |
| `impliedVol` | number | `10.4145` |

## The market chart and `quotes`

`quotes` drives the two market charts inside the alert case file: where a deal
printed against the market it was struck into. It is the only optional key.
Without it every panel still renders and every case file still opens; the chart
is replaced by a line naming the instrument it has no quotes for.

**Resolution.** The intraday chart samples across the session and interpolates
between observations, so it does not need every tick — but it cannot invent
movement between two points far apart. The multi-day chart reads one mid per
day at the close. The example file uses 15-minute intraday sampling for the
instrument-days an alert cites, and a single close for the surrounding days.

**One source, or the evidence contradicts the picture.** A deal's `mktPx` and
the chart's series must come from the same tick store. If they do not, the case
file will state a deviation the chart does not show, in front of a reviewer who
is about to act on it. In the example file the two differ by up to 1.2%, purely
because the sample is 15-minute while `mktPx` was struck against a continuous
series — a real deployment reading both from FACT_MARKET_QUOTE at execution
granularity has no such gap.

## Not in the payload

The 58 rule definitions, the data dictionary, the product taxonomy, severity and
status vocabularies and the review reason codes all ship with the application as
configuration, in `js/09-rules.js`, `js/10-data-dictionary.js`,
`js/03-config-taxonomy.js` and `js/05-config-review.js`. Tune them there.
