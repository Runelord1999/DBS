# Data contract

The production shell declares no data of its own. It reads one payload, hydrates
it, and renders. This file specifies that payload exactly: every field below was
taken from a working example (`data.json`), not drafted by hand.

## Supplying it

Either set `window.TM_DATA` before `js/06-data-adapter.js` loads — a `<script>`
your server renders is the usual way — or serve `data.json` next to the page.
The second needs a web server; opening the page from disk will have the browser
block the fetch.

## Top level

| key | type | required | holds |
|---|---|---|---|
| `meta` | object | no | provenance; ignored by the app |
| `desks` | array | **yes** | DIM_DESK |
| `traders` | array | **yes** | DIM_TRADER, with the mandate and limits on each row |
| `counterparties` | array | **yes** | DIM_COUNTERPARTY |
| `instruments` | array | **yes** | DIM_INSTRUMENT |
| `trades` | array | **yes** | FACT_TRADE |
| `alerts` | array | **yes** | FACT_ALERT, each citing trade ids |
| `baselines` | object | **yes** | AGG_TRADER_BASELINE, keyed by trader id |

Table names refer to *Trade-Surveillance-Data-Schema.xlsx*, which carries the
full specification — lengths, nullability, keys, domains and the rule-by-rule
dependency matrix. This file is only the wire format.

## What the adapter builds for you

The payload carries facts only. Nothing in it points at anything else, because
JSON cannot hold a cycle and a hand-maintained cross-reference goes stale. The
adapter rebuilds, on load:

- `DESK_BY_ID`, `TRADER_BY_ID`, `INST_BY_KEY`, `TRADES_BY_ID`, `ALERT_BY_ID`
- `desk.traders` — from each trader's `deskId`
- `trader.peers` — the cohort, grouped on `trader.cohort`
- `trade.alerts` — the back-reference, from each alert's `tradeIds`
- `trade.flags` — the rule ids citing that trade
- `byTraderDay` — a `traderId|dayIdx` index the activity charts read
- `trade.date`, `alert.date` — `Date` objects parsed from the `iso` strings

## Date handling

Every row carries `iso` (`YYYY-MM-DD`) and `dayIdx`, an integer offset where 0
is the first day of the window and `DAYS-1` is today. `dayIdx` is what the
charts bin on, so it must be consistent across trades and alerts.

## Records

### `desks[]`

One per reporting desk.

| field | type | example |
|---|---|---|
| `id` | string | `"D1"` |
| `name` | string | `"G10 FX Spot & Forwards"` |
| `region` | string | `"Singapore"` |
| `short` | string | `"G10 FX"` |
| `dpt` | number | `4` |
| `mandate` | array | `["FX Spot", "FX Forward", "FX Swap"]` |

### `traders[]`

One per trader. The authorisation fields — `ticketLimit`, `posLimit`, `tenorYrs`, `ctpyCap`, `products` — come from the mandate register and are what the limits rules test against.

| field | type | example |
|---|---|---|
| `id` | string | `"T01"` |
| `name` | string | `"Adrian Koh"` |
| `deskId` | string | `"D1"` |
| `grade` | string | `"Senior"` |
| `risk` | number | `0.1` |
| `book` | string | `"D1-BK01"` |
| `ticketLimit` | number | `40` |
| `posLimit` | number | `250` |
| `tenorYrs` | number | `10` |
| `ctpyCap` | number | `0.38` |
| `products` | array | `["FX Spot", "FX Forward", "FX Swap"]` |
| `supervisor` | string | `"Nadia Farrell"` |
| `cohort` | string | `"Senior \u00b7 FX & Options"` |

### `counterparties[]`

One per legal entity.

| field | type | example |
|---|---|---|
| `name` | string | `"Meridian Global Bank"` |
| `type` | string | `"Bank"` |
| `country` | string | `"London"` |

### `instruments[]`

One per instrument. `spreadBps` and `omFloor` set the per-instrument materiality threshold the pricing rules use.

| field | type | example |
|---|---|---|
| `i` | number | `1` |
| `key` | string | `"EUR/USD"` |
| `name` | string | `"EUR/USD"` |
| `fam` | string | `"fx"` |
| `unit` | string | `"rate"` |
| `dp` | number | `5` |
| `ref` | number | `1.0842` |
| `dv` | number | `0.0043368` |
| `spreadBps` | number | `0.49550211153924467` |
| `omFloor` | number | `22` |
| `rating` | string | `""` |
| `collateral` | string | `""` |

### `trades[]`

One per deal. The largest array by far.

| field | type | example |
|---|---|---|
| `id` | string | `"TRD-044200"` |
| `dayIdx` | number | `305` |
| `dateStr` | string | `"05 Jun 2026"` |
| `iso` | string | `"2026-06-05"` |
| `deskId` | string | `"D1"` |
| `deskName` | string | `"G10 FX Spot & Forwards"` |
| `deskShort` | string | `"G10 FX"` |
| `region` | string | `"Singapore"` |
| `traderId` | string | `"T37"` |
| `trader` | string | `"Aaron Whitfield"` |
| `book` | string | `"D1-BK37"` |
| `product` | string | `"FX Swap"` |
| `ac` | string | `"FX Cash"` |
| `fam` | string | `"fx"` |
| `instKey` | string | `"USD/JPY"` |
| `instrument` | string | `"USD/JPY"` |
| `rating` | string | `""` |
| `tenor` | string | `"3M"` |
| `notional` | number | `26.53787747828484` |
| `dir` | string | `"Sell"` |
| `unit` | string | `"rate"` |
| `dp` | number | `3` |
| `mktPx` | number | `146.40363629319558` |
| `px` | number | `146.39597372820853` |
| `devBps` | number | `-0.5233862478455247` |
| `vol` | null | `null` |
| `mktVol` | null | `null` |
| `ctpy` | string | `"Zenith Capital Bank"` |
| `ctpyType` | string | `"Bank"` |
| `ctpyCountry` | string | `"London"` |
| `channel` | string | `"API / Algo"` |
| `venue` | string | `"Exchange (SGX)"` |
| `execMin` | number | `1106` |
| `captureLag` | number | `103` |
| `amends` | number | `0` |
| `cancelled` | boolean | `false` |
| `status` | string | `"Settled"` |
| `pnl` | number | `3.4` |
| `ssiChanged` | boolean | `false` |
| `internal` | boolean | `false` |

### `alerts[]`

One per alert. `tradeIds` is what links it to the book.

| field | type | example |
|---|---|---|
| `id` | string | `"ALT-02835"` |
| `ruleId` | string | `"TS-22"` |
| `rule` | string | `"Persistent price improvement to one counterparty"` |
| `cat` | string | `"Pricing"` |
| `day` | number | `305` |
| `dateStr` | string | `"05 Jun 2026"` |
| `iso` | string | `"2026-06-05"` |
| `raisedStr` | string | `"06 Jun 2026 06:40"` |
| `traderId` | string | `"T08"` |
| `trader` | string | `"Marcus Vellacourt"` |
| `deskId` | string | `"D3"` |
| `deskShort` | string | `"FX Options"` |
| `deskName` | string | `"FX Options & Exotics"` |
| `region` | string | `"Hong Kong"` |
| `sev` | string | `"Critical"` |
| `score` | number | `93` |
| `notional` | number | `75.15686444287658` |
| `tradeIds` | array | `["TRD-055242", "TRD-055243", "TRD-055244", "TRD-0…` |
| `acs` | array | `["FX Derivatives"]` |
| `products` | array | `["FX Variance Swap"]` |
| `summary` | string | `"8 fills to Blue Lantern Ventures averaging 6.4 b…` |
| `evidence` | array | `[{"k": "Counterparty", "v": "Blue Lantern Venture…` |
| `why` | string | `"No single fill breaches anything. The pattern is…` |
| `status` | string | `"Escalated"` |
| `reason` | string | `"Potential personal benefit or undisclosed conflict"` |
| `note` | string | `"Third occurrence for this trader on the same typ…` |
| `reviewer` | string | `"A. Fitzgerald"` |
| `reviewedStr` | string | `"09 Jun 2026 09:32"` |
| `audit` | array | `[{"ts": "06 Jun 2026 06:40", "actor": "Surveillan…` |
| `n` | number | `2834` |
| `reviewDay` | number | `309` |
| `hour` | number | `9` |
| `ctpys` | array | `["Blue Lantern Ventures"]` |
| `channels` | array | `["Multi-dealer platform", "Voice", "API / Algo", …` |
| `tenorBands` | array | `["1\u201312 months"]` |
| `sizeBands` | array | `["$5\u201310m", "$10\u201325m", "$1\u20135m"]` |

### `baselines{traderId}`

One per trader, keyed by trader id. Supply it from AGG_TRADER_BASELINE; if omitted per trader, the shell computes a rough one from the delivered book and says so.

| field | type | example |
|---|---|---|
| `deals` | number | `913` |
| `activeDays` | number | `244` |
| `tickets` | number | `3.7418032786885247` |
| `ticketsSd` | number | `1.9231464343765012` |
| `ticketsP95` | number | `7` |
| `dayNotional` | number | `64.73537219484864` |
| `dayNotionalSd` | number | `37.67935139716791` |
| `medSize` | number | `15.341469379441456` |
| `p95Size` | number | `37.599999999999994` |
| `ctpyCount` | number | `10` |
| `topCtpy` | string | `"Helios Atlantic Bank"` |
| `topCtpyShare` | number | `0.12705366922234393` |
| `products` | array | `["FX Swap", "FX Spot", "FX Forward"]` |
| `execMean` | number | `788.7382256297919` |
| `execSd` | number | `189.21950852862162` |
| `pnlMean` | number | `3.5397540983606577` |
| `pnlSd` | number | `7.535437372852948` |
| `lossDays` | number | `0.3155737704918033` |
| `amendRate` | number | `0.05585980284775466` |
| `amendsPerDeal` | number | `0.05585980284775466` |

## Not in the payload

The 50 rule definitions, the data dictionary, the product taxonomy, severity and
status vocabularies and the review reason codes all ship with the application as
configuration, in `js/09-rules.js`, `js/10-data-dictionary.js`,
`js/03-config-taxonomy.js` and `js/05-config-review.js`. Tune them there.

## Known limitation

`midAt(instrument, dayIdx, minute)` in `js/04-config-market-context.js` returns
the market mid at a moment, and the demo implementation walked a generated price
path that is not in this payload. Only the two market charts inside the alert
case file use it; everything else runs without it. Point it at the tick store
(FACT_MARKET_QUOTE) to bring those two charts up.
