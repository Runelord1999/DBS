/* ============================================================
   Data Highlight (brushing & linking)
   The population is the alert book. Every panel tags its elements with the
   dimensions each alert belongs to; hovering any one of them rewrites a single
   <style> rule, so the browser does the matching and the cost is the same
   whether twenty elements or two thousand are on screen.
============================================================ */
const HL_KEYS={trader:"data-hl-trader",desk:"data-hl-desk",rule:"data-hl-rule",cat:"data-hl-cat",
  sev:"data-hl-sev",status:"data-hl-status",ac:"data-hl-ac",hour:"data-hl-hour",month:"data-hl-month",
  product:"data-hl-product",ctpy:"data-hl-ctpy",channel:"data-hl-channel",
  tenorb:"data-hl-tenorb",sizeb:"data-hl-sizeb"};
/* Dimensions an alert can hold more than one value of. */
const HL_MULTI={ac:1,product:1,ctpy:1,channel:1,tenorb:1,sizeb:1};
const HL_NOUN={trader:"Trader",desk:"Desk",rule:"Rule",cat:"Category",
  sev:"Severity",status:"Disposition",ac:"Asset class",hour:"Booking hour",month:"Month",
  product:"Product",ctpy:"Counterparty",channel:"Booking channel",tenorb:"Tenor band",sizeb:"Ticket size"};
const AGE_BUCKETS=[["0–2 days",0,2,"var(--pass)"],["3–5 days",3,5,"var(--agent)"],["6–10 days",6,10,"var(--warn)"],
  ["11–20 days",11,20,"var(--fail)"],["20+ days",21,9999,"var(--violet)"]];
const ageBucketOf=a=>{ const g=ageOf(a); for(const b of AGE_BUCKETS) if(g>=b[1]&&g<=b[2]) return b[0]; return AGE_BUCKETS[0][0]; };
function hlMatches(a,key,val){
  switch(key){
    case "trader": return a.traderId===val;
    case "desk":   return a.deskId===val;
    case "rule":   return a.ruleId===val;
    case "cat":    return a.cat===val;
    case "sev":    return a.sev===val;
    case "status": return a.status===val;
    case "ac":      return a.acs.indexOf(val)>=0;
    case "product": return a.products.indexOf(val)>=0;
    case "ctpy":    return (a.ctpys||[]).indexOf(val)>=0;
    case "channel": return (a.channels||[]).indexOf(val)>=0;
    case "tenorb":  return (a.tenorBands||[]).indexOf(val)>=0;
    case "sizeb":   return (a.sizeBands||[]).indexOf(val)>=0;
    case "hour":   return a.hour===+val;
    case "month":  return monthIdxOf(a.date)===+val;
  }
  return false;
}
/* What the selection contributes to every OTHER dimension. Without this, hovering
   a trader would leave the severity donut and the monthly columns dark — those
   are different cuts of the same alerts, not members of the selection. One pass
   over the book, memoised per selection. */
let HL_AGG=new Map();
function hlAggregate(spec){
  if(HL_AGG.has(spec)) return HL_AGG.get(spec);
  const [key,val]=spec.split("|");
  const r={trader:{},desk:{},rule:{},cat:{},sev:{},status:{},ac:{},hour:{},age:{},
           product:{},ctpy:{},channel:{},tenorb:{},sizeb:{},
           // A heatmap cell is a pair, not a value, so it needs a key of its own.
           // All four row × column combinations the matrix can be switched to.
           cell:{},
           month:Array(12).fill(0),days:Array(DAYS).fill(0),n:0,nPeriod:0,notional:0,
           // Panels scoped to the review period need their own cut: sharing the
           // 12-month one would size a marker against the wrong denominator.
           period:{sev:{},status:{},cat:{},rule:{},trader:{},desk:{}}};
  ALERTS.forEach(a=>{
    if(!matchRail(a)||!hlMatches(a,key,val)) return;
    r.n++; r.notional+=a.notional;
    if(alertInRange(a)){
      r.nPeriod++;
      const P=r.period;
      P.sev[a.sev]=(P.sev[a.sev]||0)+1;
      P.status[a.status]=(P.status[a.status]||0)+1;
      P.cat[a.cat]=(P.cat[a.cat]||0)+1;
      P.rule[a.ruleId]=(P.rule[a.ruleId]||0)+1;
      P.trader[a.traderId]=(P.trader[a.traderId]||0)+1;
      P.desk[a.deskId]=(P.desk[a.deskId]||0)+1;
    }
    r.trader[a.traderId]=(r.trader[a.traderId]||0)+1;
    r.desk[a.deskId]=(r.desk[a.deskId]||0)+1;
    r.rule[a.ruleId]=(r.rule[a.ruleId]||0)+1;
    r.cat[a.cat]=(r.cat[a.cat]||0)+1;
    r.sev[a.sev]=(r.sev[a.sev]||0)+1;
    r.status[a.status]=(r.status[a.status]||0)+1;
    a.acs.forEach(x=>{ r.ac[x]=(r.ac[x]||0)+1; });
    a.products.forEach(x=>{ r.product[x]=(r.product[x]||0)+1; });
    (a.ctpys||[]).forEach(x=>{ r.ctpy[x]=(r.ctpy[x]||0)+1; });
    (a.channels||[]).forEach(x=>{ r.channel[x]=(r.channel[x]||0)+1; });
    (a.tenorBands||[]).forEach(x=>{ r.tenorb[x]=(r.tenorb[x]||0)+1; });
    (a.sizeBands||[]).forEach(x=>{ r.sizeb[x]=(r.sizeb[x]||0)+1; });
    if(a.hour!=null) r.hour[a.hour]=(r.hour[a.hour]||0)+1;
    if(isOpen(a)){ const b=ageBucketOf(a); r.age[b]=(r.age[b]||0)+1; }
    const C=r.cell, S="\u0001";
    C[a.ruleId+S+a.traderId]=(C[a.ruleId+S+a.traderId]||0)+1;
    C[a.ruleId+S+a.deskId]  =(C[a.ruleId+S+a.deskId]  ||0)+1;
    C[a.cat+S+a.traderId]   =(C[a.cat+S+a.traderId]   ||0)+1;
    C[a.cat+S+a.deskId]     =(C[a.cat+S+a.deskId]     ||0)+1;
    const mi=monthIdxOf(a.date); if(mi>=0) r.month[mi]++;
    r.days[a.day]++;
  });
  HL_AGG.set(spec,r);
  return r;
}
/* The same selection, counted in deals instead of alerts, with a parallel cut in
   notional so a volume chart is marked in the currency it is drawn in. Rule,
   category, severity and disposition are properties of an alert rather than of a
   ticket, so for those the selection resolves to the set of deals the matching
   alerts cite. */
let HL_TAGG=new Map();
function hlTradeAggregate(spec){
  if(HL_TAGG.has(spec)) return HL_TAGG.get(spec);
  const [key,val]=spec.split("|");
  const mk=()=>({trader:{},desk:{},ac:{},product:{},ctpy:{},channel:{},tenorb:{},sizeb:{},
                 hour:{},month:{}});
  const r=mk(); r.vol=mk(); r.pl=mk(); r.n=0; r.notional=0;
  let ids=null;
  if(key==="rule"||key==="cat"||key==="sev"||key==="status"){
    ids=Object.create(null);
    ALERTS.forEach(a=>{ if(matchRail(a)&&hlMatches(a,key,val)) a.tradeIds.forEach(id=>{ids[id]=1;}); });
  }
  const hit=t=>{
    switch(key){
      case "trader":  return t.traderId===val;
      case "desk":    return t.deskId===val;
      case "ac":      return t.ac===val;
      case "product": return t.product===val;
      case "ctpy":    return t.ctpy===val;
      case "channel": return t.channel===val;
      case "tenorb":  return tenorBandOf(t.tenor)===val;
      case "sizeb":   return sizeBandOf(t.notional)===val;
      case "hour":    return Math.min(23,Math.floor(t.execMin/60))===+val;
      case "month":   return monthIdxOf(t.date)===+val;
      default:        return !!ids[t.id];
    }
  };
  const bump=(dim,k,nl,pl)=>{ r[dim][k]=(r[dim][k]||0)+1; r.vol[dim][k]=(r.vol[dim][k]||0)+nl;
                              r.pl[dim][k]=(r.pl[dim][k]||0)+pl; };
  TRADES.forEach(t=>{
    if(!tradeMatchesRail(t)||!hit(t)) return;
    r.n++; r.notional+=t.notional;
    const nl=t.notional, pl=t.revenue;
    bump("trader",t.traderId,nl,pl);
    bump("desk",t.deskId,nl,pl);
    bump("ac",t.ac,nl,pl);
    bump("product",t.product,nl,pl);
    bump("ctpy",t.ctpy,nl,pl);
    bump("channel",t.channel,nl,pl);
    bump("tenorb",tenorBandOf(t.tenor),nl,pl);
    bump("sizeb",sizeBandOf(t.notional),nl,pl);
    bump("hour",Math.min(23,Math.floor(t.execMin/60)),nl,pl);
    const mi=monthIdxOf(t.date); if(mi>=0) bump("month",mi,nl,pl);
  });
  HL_TAGG.set(spec,r);
  return r;
}
/* Paint every aggregate: keep it lit when the selection is present in it, and
   size its marker to the share the selection accounts for. Four passes, one per
   marker shape — a div bar, a horizontal SVG bar, a vertical SVG column, and
   the daily series. */
/* An aggregate names the cut it reads from with a prefix. "sev|Critical" is the
   12-month alert count, "P:sev|Critical" the review-period one, "T:product|FX Spot"
   the deal count, "V:product|FX Spot" the notional. The activity charts are drawn
   from deals, so they have to be measured in deals — a marker sized in alerts
   over a bar sized in deals is a ratio of two different populations, and at
   1,727 alerts against 27,565 deals it renders as no marker at all. */
const HL_CUT={"P:":a=>a.a.period,"T:":a=>a.t,"V:":a=>a.t.vol,"R:":a=>a.t.pl};
const hlSplit=spec=>{
  const i=spec.indexOf("|"), d=spec.slice(0,i);
  return spec.charAt(1)===":"?[d.slice(0,2),d.slice(2),spec.slice(i+1)]:["",d,spec.slice(i+1)];
};
const hlSub=(aggs,spec)=>{
  if(!aggs) return 0;
  const p=hlSplit(spec), cut=HL_CUT[p[0]];
  return (((cut?cut(aggs):aggs.a)||{})[p[1]]||{})[p[2]]||0;
};
/* Is this aggregate the selection itself? A bar the cursor is on is already
   lit and already 100% of itself, so drawing a share marker over it would
   simply repaint it in the marker colour — which reads as the chart changing
   colour under the mouse rather than as a measurement. */
const hlIsSelf=(spec,sel)=>{
  if(!sel) return false;
  const a=hlSplit(spec), b=hlSplit(sel);
  return a[1]===b[1]&&a[2]===b[2];
};
/* Whether a bar stays lit is not "does the selection touch it". Selecting FX Spot
   must not light FX Swap: they are siblings on the same axis, and because a deal
   set spans several products, several counterparties and several size bands, any
   overlap test lights nearly the whole chart — which reads as the chart selecting
   things the user did not click. So within the selection's own dimension only the
   exact match survives, and its siblings go dark like any other unselected member.
   Across other dimensions a bar stays lit wherever the selection is present, which
   is what lets picking a trader redraw the execution-hour profile. */
const hlSameDim=(spec,sel)=>!!sel&&hlSplit(spec)[1]===hlSplit(sel)[1];
function hlPaintAggregates(aggs,sel){
  /* Revenue is the one cut that can come back negative — a selection can be
     loss-making inside a profitable bar — and a marker has no negative width,
     so a losing selection reads as no marker rather than as a bar drawn
     backwards. */
  const shareOf=(spec,sub,total)=>
    hlSameDim(spec,sel)||total<=0?0:Math.max(0,Math.min(1,sub/total));
  $$("[data-hl-agg]").forEach(el=>{
    const spec=el.getAttribute("data-hl-agg");
    const sub=hlSub(aggs,spec);
    el.classList.toggle("hl-has",!!aggs&&(hlSameDim(spec,sel)?hlIsSelf(spec,sel):sub>0));
    const mark=el.querySelector&&el.querySelector(".hlmark");
    if(mark) mark.style.width=(shareOf(spec,sub,+el.getAttribute("data-hl-total")||0)*
      (+el.getAttribute("data-hl-rate")||100)).toFixed(1)+"%";
  });
  $$("rect.hlmark-svg").forEach(r=>{
    const spec=r.getAttribute("data-hl-for");
    r.setAttribute("width",(shareOf(spec,hlSub(aggs,spec),+r.getAttribute("data-hl-total")||0)*
      (+r.getAttribute("data-hl-len")||0)).toFixed(1));
  });
  $$("rect.hlshare").forEach(r=>{
    const spec=r.getAttribute("data-hl-for");
    const sub=hlSameDim(spec,sel)?0:hlSub(aggs,spec);
    const px=+r.getAttribute("data-hl-px")||0, base=+r.getAttribute("data-hl-base")||0;
    const h=Math.max(0,sub*px);
    r.setAttribute("height",h.toFixed(1));
    r.setAttribute("y",(base-h).toFixed(1));
  });
  $$("path.hlseries").forEach(pth=>{
    if(!aggs){ pth.setAttribute("d",""); return; }
    const x0=+pth.getAttribute("data-x0"), dx=+pth.getAttribute("data-dx");
    const base=+pth.getAttribute("data-base"), py=+pth.getAttribute("data-py"), n=+pth.getAttribute("data-n");
    const off=DAYS-n;
    let d="M"+x0.toFixed(1)+","+base.toFixed(1);
    for(let i=0;i<n;i++) d+=" "+(x0+i*dx).toFixed(1)+","+(base-aggs.a.days[off+i]*py).toFixed(1);
    pth.setAttribute("d",d+" "+(x0+(n-1)*dx).toFixed(1)+","+base.toFixed(1)+"Z");
  });
}
let hlStyleEl=null, hlPinned=null;
/* The selection in force right now, pinned or merely hovered. hlPinned only
   knows about the locked one. */
let hlCurrent=null;
function hlStyle(){ if(!hlStyleEl){ hlStyleEl=document.createElement("style"); document.head.appendChild(hlStyleEl); } return hlStyleEl; }
function hlApply(spec){
  // Every path that changes the selection passes through here, so this is the
  // one place that can tell a tooltip what is currently selected.
  hlCurrent=spec||null;
  TIPGEN_EPOCH++;
  // Esc, a second click on the dot, or a pin from anywhere else all land here, so
  // the menu is synced from the one place every path passes through.
  const hlSel=$("#ts-hltrader");
  if(hlSel){ const v=spec&&spec.slice(0,7)==="trader|"?spec.slice(7):""; if(hlSel.value!==v) hlSel.value=v; }
  const st=hlStyle();
  const [key,val]=spec?spec.split("|"):[];
  const attr=spec?HL_KEYS[key]:null;
  if(!spec||!attr||!state.highlight){
    st.textContent=""; document.body.classList.remove("hl-active"); hlPaintAggregates(null); hlLabel(null); return;
  }
  /* Several dimensions are multi-valued on an alert — a deal set can span two
     asset classes, three counterparties, two tenor bands. Those are written as
     pipe-delimited lists and matched on a delimited substring, because the
     word-match selector splits on spaces and almost every value here contains
     one: "FX Cash", "Meridian Global Bank", "1–12 months". */
  const multi=HL_MULTI[key];
  const sel="["+attr+(multi?'*='+JSON.stringify("|"+val+"|"):"="+JSON.stringify(val))+"]";
  st.textContent=
    ".hl-active "+sel+"{opacity:1 !important;filter:none !important}"+
    ".hl-active .mcell"+sel+",.hl-active .tcard"+sel+",.hl-active .rulecard"+sel+
      "{outline:2px solid var(--ink);outline-offset:-2px;z-index:6;position:relative}"+
    ".hl-active .hlrow"+sel+",.hl-active tr"+sel+
      "{background:color-mix(in srgb,var(--brand) 16%,transparent)}"+
    /* Every shape a mark can be drawn as, not just the two the first charts used.
       The time series draws a dot as one of nine shapes — six of them polygons and
       one a path — so a selector naming only rect and circle outlined a trader
       whose asset classes happened to land on a circle or a square and silently
       skipped everyone else. */
    /* Outlines go on filled marks only. A stroke-drawn mark — a donut arc is a
       circle with fill="none" whose colour and 19px thickness are both carried
       by its stroke — would have that stroke rewritten to a 1.6px dark line,
       which is how selecting Critical turned the red arc into a thin dark
       thread. Those marks already read as selected: the aggregate machinery
       holds them at full opacity while everything else fades. */
    ".hl-active rect"+sel+':not([fill="none"]),.hl-active circle'+sel+':not([fill="none"])'+
      ',.hl-active ellipse'+sel+':not([fill="none"]),.hl-active polygon'+sel+':not([fill="none"])'+
      ',.hl-active path'+sel+':not([fill="none"]){stroke:var(--ink);stroke-width:1.6}';
  document.body.classList.add("hl-active");
  const aggs={a:hlAggregate(spec),t:hlTradeAggregate(spec)};
  hlPaintAggregates(aggs,spec);
  hlLabel(spec,aggs);
}
function hlLabel(spec,aggs){
  let el=$("#hl-pin");
  if(!el){ el=document.createElement("div"); el.id="hl-pin"; el.className="hlpin"; document.body.appendChild(el); }
  if(!spec||!state.highlight){ el.classList.remove("on"); return; }
  const [k,v]=spec.split("|");
  const label=k==="trader"?(TRADER_BY_ID[v]||{}).name||v
    :k==="desk"?(DESK_BY_ID[v]||{}).name||v
    :k==="rule"?v+" "+((RULE_BY_ID[v]||{}).name||"")
    :k==="hour"?pad2(v)+":00–"+pad2((+v+1)%24)+":00"
    :k==="month"?(MONTH_KEYS[+v]||{}).full||v:v;
  el.innerHTML='<b></b><span></span>';
  el.querySelector("b").textContent=(HL_NOUN[k]||k)+" · "+label;
  el.querySelector("span").textContent="· "+fmtNum(aggs?aggs.t.n:0)+" deals · "+
    fmtNum(aggs?aggs.a.n:0)+" alerts in scope"+
    (hlPinned?" · pinned, click again or press Esc to release":"");
  el.classList.add("on");
}
function hlSet(spec){ if(!hlPinned) hlApply(spec); }
function hlClear(){ if(!hlPinned) hlApply(null); }
function hlPin(spec){ hlPinned=hlPinned===spec?null:spec; hlApply(hlPinned); }
/* Set rather than toggle: a menu says what it wants, so re-choosing the name
   already showing must leave it locked, not clear it. */
function hlLock(spec){ hlPinned=spec||null; hlApply(hlPinned); }
/* The selection survives a re-render: panes are rebuilt from scratch on every
   filter change, so the pinned rule has to be re-attached to the new nodes. */
function hlRefresh(){ HL_AGG=new Map(); HL_TAGG=new Map(); hlApply(hlPinned); }
document.addEventListener("mouseover",e=>{
  if(!state.highlight) return;
  /* Marks that exist only because something is selected must not be able to
     clear that selection. The share overlay inside a column is drawn by the
     highlight and grows under the cursor: letting it clear on hover set up a
     loop — overlay appears, takes the pointer, clears the selection, vanishes,
     the segment behind is hovered again, and the chart flickers. It reports the
     selection rather than setting one, so it leaves it alone. */
  if(e.target.closest("[data-hlkeep]")) return;
  const src=e.target.closest("[data-hlsrc]");
  if(src) hlSet(src.getAttribute("data-hlsrc")); else hlClear();
});
document.addEventListener("mouseout",e=>{
  if(!state.highlight) return;
  const to=e.relatedTarget;
  if(!to||!to.closest) { hlClear(); return; }
  // Leaving a source for a mark that only exists because of the selection is not
  // leaving the selection — see the note on the mouseover handler.
  if(to.closest("[data-hlkeep]")||to.closest("[data-hlsrc]")) return;
  hlClear();
});
/* Attribute bundle every alert-bearing element carries, so one selector lights
   them all whichever dimension is hovered. */
const hlList=v=>"|"+(v||[]).join("|")+"|";
function hlAttrs(a){
  return 'data-hl-trader="'+a.traderId+'" data-hl-desk="'+a.deskId+'" data-hl-rule="'+a.ruleId+
    '" data-hl-cat="'+esc(a.cat)+'" data-hl-sev="'+a.sev+'" data-hl-status="'+esc(a.status)+
    '" data-hl-hour="'+(a.hour==null?"":a.hour)+'" data-hl-month="'+monthIdxOf(a.date)+
    '" data-hl-ac="'+esc(hlList(a.acs))+'" data-hl-product="'+esc(hlList(a.products))+
    '" data-hl-ctpy="'+esc(hlList(a.ctpys))+'" data-hl-channel="'+esc(hlList(a.channels))+
    '" data-hl-tenorb="'+esc(hlList(a.tenorBands))+'" data-hl-sizeb="'+esc(hlList(a.sizeBands))+'"';
}
/* Aggregate bar: dims when the selection is absent from it, carries a marker
   sized to the selection's share when present. */
/* The member attribute for one value of one dimension, written in whichever
   form that dimension's selector expects. */
const hlDim=(dim,val)=>"data-hl-"+dim+'="'+esc(HL_MULTI[dim]?"|"+val+"|":val)+'"';
function hlAgg(dim,key,total,ratePct){
  return 'data-hl-agg="'+esc(dim+"|"+key)+'" data-hl-total="'+total+'" data-hl-rate="'+(ratePct==null?100:ratePct)+'"';
}
/* Same, for a panel that only shows the selected review period. */
const hlAggP=(dim,key,total,ratePct)=>hlAgg("P:"+dim,key,total,ratePct);
/* And for the activity panels, which are drawn from deals: T counts tickets,
   V measures them in notional, so a volume bar is marked in notional and a count
   bar in deals rather than both being marked in alerts. */
const hlAggT=(dim,key,total,ratePct)=>hlAgg("T:"+dim,key,total,ratePct);
const hlAggV=(dim,key,total,ratePct)=>hlAgg("V:"+dim,key,total,ratePct);
/* R measures the same selection in revenue, for the P&L view of those panels. */
const hlAggR=(dim,key,total,ratePct)=>hlAgg("R:"+dim,key,total,ratePct);
