"use strict";
const $=(s,r=document)=>r.querySelector(s);
const $$=(s,r=document)=>Array.from(r.querySelectorAll(s));
const esc=s=>String(s).replace(/[&<>"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));

/* ============================================================
   Tooltip engine — one floating box, driven by data-tip attributes.

   Most elements carry their tooltip as markup. A few cannot afford to: the
   time series draws thousands of dots, and a hundred-odd characters of label
   and detail table on each one is megabytes of attribute text rebuilt on every
   scroll frame. Those elements instead carry data-tipgen naming a generator,
   which is called once, on hover, against the element that is actually under
   the cursor. Generators are registered later, once the data they read exists.
============================================================ */
const TIPGEN={};
/* Bumped whenever something a generator reads has changed. A generated tooltip
   is cached against the element it came from, and the share overlay is the same
   element from one selection to the next — without this it would keep showing
   the previous selection's numbers while the cursor rested on it. */
let TIPGEN_EPOCH=0;
(function(){
  let box=null,lastEl=null,lastEpoch=-1;
  function ensure(){ if(!box){box=document.createElement("div");box.className="tt";document.body.appendChild(box);} return box; }
  function place(x,y){
    const el=ensure(),pad=14;
    let left=x+pad, top=y-el.offsetHeight-pad;
    if(left+el.offsetWidth>window.innerWidth-8) left=Math.max(8,x-el.offsetWidth-pad);
    if(top<8) top=y+pad;
    /* Flipping below the cursor can push a tall box off the bottom, which at the
       largest font setting a ten-row table will do on a short window. Clamp both
       edges, preferring the top when the box is taller than the viewport. */
    top=Math.min(top,window.innerHeight-el.offsetHeight-8);
    el.style.left=Math.max(8,left)+"px"; el.style.top=Math.max(8,top)+"px";
  }
  document.addEventListener("mousemove",e=>{
    const t=e.target.closest("[data-tip],[data-tipgen]");
    const el=ensure();
    if(!t){el.classList.remove("show");lastEl=null;return;}
    const gen=t.getAttribute("data-tipgen");
    if(t!==lastEl||(gen&&lastEpoch!==TIPGEN_EPOCH)){
      lastEpoch=TIPGEN_EPOCH;
      let title=t.getAttribute("data-tip")||"";
      let sub=t.getAttribute("data-tipsub");
      let rows=t.getAttribute("data-tiptable");
      if(gen&&TIPGEN[gen]){
        const d=TIPGEN[gen](t)||{};
        if(d.title!=null) title=d.title;
        if(d.sub!=null) sub=d.sub;
        if(d.rows!=null) rows=d.rows;
      }
      // A generator that found nothing must show nothing. Without this an
      // element whose data has gone would sit under an empty floating box.
      if(!title&&!rows){ el.classList.remove("show"); lastEl=t; return; }
      el.innerHTML="";
      if(rows){
        // Built with textContent, never innerHTML — values come straight from data.
        el.classList.add("rich");
        const h=document.createElement("div"); h.className="tt-t"; h.textContent=title; el.appendChild(h);
        if(sub){ const sd=document.createElement("div"); sd.className="tt-s"; sd.textContent=sub; el.appendChild(sd); }
        const g=document.createElement("div"); g.className="tt-g";
        rows.split("§").forEach(line=>{
          if(!line) return;
          const i=line.indexOf("|"); if(i<0) return;
          const k=document.createElement("div"); k.className="tt-k"; k.textContent=line.slice(0,i);
          const v=document.createElement("div"); v.className="tt-v"; v.textContent=line.slice(i+1);
          g.appendChild(k); g.appendChild(v);
        });
        el.appendChild(g);
      }else{
        el.classList.remove("rich");
        el.textContent=title;
      }
      el.classList.add("show");
      lastEl=t;
    }
    place(e.clientX,e.clientY);
  },true);
  document.addEventListener("mouseleave",()=>{const el=ensure();el.classList.remove("show");lastEl=null;});
  window.addEventListener("scroll",()=>{const el=ensure();el.classList.remove("show");lastEl=null;},true);
})();

/* ============================================================
   Theme + font-size engines — same contract as the sibling dashboards.
============================================================ */
const THEME_KEY="ts-dash-theme", FS_KEY="ts-dash-fontsize", MSR_KEY="ts-dash-measure";
/* Two extra steps on the large end for high-resolution monitors and for anyone
   reading the page from a distance. Nothing added below 12px: the smallest step
   is already at the floor of what the dense tables stay legible at. */
const FS_LEVELS=[12,14,16,18,20,22,24];
const THEMES=["light","dark","dbs"], DEFAULT_THEME="light";
function normTheme(t){return THEMES.includes(t)?t:DEFAULT_THEME;}
function applyTheme(t){t=normTheme(t);document.documentElement.setAttribute("data-theme",t);try{localStorage.setItem(THEME_KEY,t);}catch(e){}return t;}
/* Chart text is drawn inside an SVG viewBox, so it is measured in user units and
   a change to the root font size does not reach it — every hand-rolled chart kept
   its 8.5px axis labels while the prose around them grew to 20px. The charts are
   rebuilt on every render, so the label sizes are multiplied at build time by the
   same ratio the control applies to everything else. */
let CHART_FS=1;
const cf=n=>+(n*CHART_FS).toFixed(2);
function applyFontSize(i){
  document.documentElement.style.fontSize=FS_LEVELS[i]+"px";
  CHART_FS=FS_LEVELS[i]/16;
  try{localStorage.setItem(FS_KEY,i);}catch(e){}
}
/* Transactions or P&L. The per-trader cards on the same tab carry their own
   three-way measure, and the first of those three is whichever one the page is
   in — so switching the page switches that button with it rather than leaving
   the cards counting deals under a set of P&L charts. Notional and tenor are
   deliberate picks and survive the switch untouched. */
const MEASURES=["txn","pnl"];
/* Read where state is built rather than in initChrome below: that initialiser
   runs thousands of lines before the state object is declared, and touching
   state from there is a temporal-dead-zone error that takes the whole page
   down — for exactly the readers who had chosen P&L last time. */
function storedMeasure(){
  let m=null; try{m=localStorage.getItem(MSR_KEY);}catch(e){}
  return MEASURES.includes(m)?m:"txn";
}
function setMeasure(m){
  if(!MEASURES.includes(m)||state.measure===m) return;
  state.measure=m;
  try{localStorage.setItem(MSR_KEY,m);}catch(e){}
  if(m==="pnl"&&state.act.metric==="count") state.act.metric="pnl";
  if(m==="txn"&&state.act.metric==="pnl") state.act.metric="count";
  syncMeasureBtns();
  render();
}
function syncMeasureBtns(){
  const box=$("#msr-sel"); if(!box) return;
  // Only the Trade Activity panels read the measure, so the control lives with them.
  box.classList.toggle("on",state.tab==="activity");
  $$("button[data-measure]",box).forEach(b=>
    b.setAttribute("aria-pressed",String(b.dataset.measure===state.measure)));
}
(function initChrome(){
  let t=DEFAULT_THEME;try{t=normTheme(localStorage.getItem(THEME_KEY));}catch(e){}
  applyTheme(t);
  const tsel=$("#theme-sel");
  if(tsel){tsel.value=t;tsel.addEventListener("change",e=>applyTheme(e.target.value));}
  let fi=2;try{const v=localStorage.getItem(FS_KEY);if(v!==null)fi=+v;}catch(e){}
  if(!(fi>=0&&fi<FS_LEVELS.length)) fi=2;   // a stored index from an older scale
  applyFontSize(fi);
  const fsel=$("#fs-sel");
  /* Redrawn on change, not inside applyFontSize: this runs before the book is
     built, and render() is a hoisted declaration, so calling it here would fire
     against data that does not exist yet. */
  /* The root size applies on every input event so the prose responds as the
     slider moves; the charts are rebuilt once the slider settles, because a full
     redraw per pixel of drag is a stutter nobody asked for. */
  let fsT=null;
  if(fsel){fsel.value=fi;fsel.addEventListener("input",e=>{
    applyFontSize(+e.target.value);
    clearTimeout(fsT); fsT=setTimeout(()=>render(),120);
  });}
})();

/* ============================================================
   Seeded RNG — the whole book is deterministic across reloads, so an
   alert reviewed yesterday is the same alert today.
============================================================ */
function mulberry32(seed){return function(){seed|=0;seed=seed+0x6D2B79F5|0;let t=Math.imul(seed^seed>>>15,1|seed);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296;};}
/* One seeded stream drives the whole demo book, so a reload reproduces it
   exactly. It is reached through a holder rather than bound directly because a
   generator added later must not draw from it: every draw it took would shift
   every value generated after it — the review history, the prior year — and
   the alerts already in the book would silently change. withStream() lends such
   a generator a stream of its own and hands the original back untouched. */
let RNG_SRC=mulberry32(20260803);
const rng=()=>RNG_SRC();
function withStream(seed,fn){
  const prev=RNG_SRC; RNG_SRC=mulberry32(seed);
  try{ return fn(); } finally{ RNG_SRC=prev; }
}
const rand=(a,b)=>a+rng()*(b-a);
const randInt=(a,b)=>Math.floor(rand(a,b+1));
const choice=a=>a[Math.floor(rng()*a.length)];
const shuffle=a=>{const x=a.slice();for(let i=x.length-1;i>0;i--){const j=Math.floor(rng()*(i+1));const t=x[i];x[i]=x[j];x[j]=t;}return x;};
// Weights need not sum to 1 — normalised here so tables read as percentages.
const weightedChoice=pairs=>{const tot=pairs.reduce((a,p)=>a+p[1],0)||1;const r=rng()*tot;let acc=0;for(const pr of pairs){acc+=pr[1];if(r<=acc)return pr[0];}return pairs[pairs.length-1][0];};
// Log-normal-ish draw: trade sizes cluster small with a long tail of blocks.
const lognorm=(med,sigma)=>med*Math.exp(sigma*(rng()+rng()+rng()+rng()-2));
/* Small descriptive statistics. Every "is this unusual?" rule resolves against a
   trader's own distribution, so mean/σ/percentile are part of the data model. */
const mean=a=>a.length?a.reduce((x,y)=>x+y,0)/a.length:0;
const sd=a=>{ if(a.length<2) return 0; const m=mean(a); return Math.sqrt(a.reduce((x,y)=>x+(y-m)*(y-m),0)/(a.length-1)); };
const pctile=(a,p)=>{ if(!a.length) return 0; const s=a.slice().sort((x,y)=>x-y); return s[Math.min(s.length-1,Math.max(0,Math.round(p*(s.length-1))))]; };
const median=a=>pctile(a,0.5);
/* Set, not indexOf. The filter/indexOf idiom is O(n²), and on a blotter held in
   day order the first occurrence of a late day sits ~58,000 elements in, so
   uniq(dayIdx) alone ran to a billion comparisons and cost two seconds a render.
   Insertion order is preserved, and every value passed here is a primitive. */
const uniq=a=>[...new Set(a)];
const plural=(n,one,many)=>n+" "+(n===1?one:(many||one+"s"));
