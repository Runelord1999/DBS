/* ============================================================
   Chart primitives — hand-rolled SVG, themed through CSS variables
============================================================ */
function donut(segs,cTop,cBot,size,thick){
  size=size||160; thick=thick||24;
  const r=(size-thick)/2,cx=size/2,cy=size/2,C=2*Math.PI*r;
  const tot=segs.reduce((a,s)=>a+s.v,0)||1;
  let off=0,arcs="";
  segs.forEach(s=>{
    const len=Math.max(0,s.v)/tot*C;
    /* The arc carries the aggregate itself rather than leaning on the legend row
       beside it: an arc that only lights when the selection names its own series
       is a slice that goes blank the moment you select anything else. */
    arcs+='<circle cx="'+cx+'" cy="'+cy+'" r="'+r+'" fill="none" stroke="'+s.color+'" stroke-width="'+thick+
      '" stroke-dasharray="'+len.toFixed(2)+" "+(C-len).toFixed(2)+'" stroke-dashoffset="'+(-off).toFixed(2)+
      '" transform="rotate(-90 '+cx+" "+cy+')" '+(s.hl||"")+" "+(s.agg||"")+'><title>'+esc(s.label)+" "+((s.v/tot)*100).toFixed(1)+"%</title></circle>";
    off+=len;
  });
  return '<svg class="donut" width="'+size+'" height="'+size+'" viewBox="0 0 '+size+" "+size+'">'+
    '<circle cx="'+cx+'" cy="'+cy+'" r="'+r+'" fill="none" stroke="var(--hair)" stroke-width="'+thick+'" opacity=".4"/>'+arcs+
    '<text x="'+cx+'" y="'+(cy-3)+'" text-anchor="middle" fill="var(--ink)" font-size="'+cf(19)+'" font-weight="750" font-family="var(--mono)">'+esc(cTop)+"</text>"+
    '<text x="'+cx+'" y="'+(cy+16)+'" text-anchor="middle" fill="var(--ink-3)" font-size="'+cf(10)+'">'+esc(cBot)+"</text></svg>";
}
function donutLegend(segs,tot,clickAttr){
  const t=tot||segs.reduce((a,s)=>a+s.v,0)||1;
  const max=Math.max(1,...segs.map(s=>s.v));
  return '<div class="dlegend"><div class="dhd"><span style="flex:1">Series</span><span class="damt">Count</span><span class="dpct">Share</span></div>'+
    segs.map(s=>'<div class="drow" '+(clickAttr?clickAttr(s):"")+" "+(s.hl||"")+" "+(s.agg||"")+">"+
      '<span class="dot" style="background:'+s.color+'"></span>'+
      '<span class="dlabel">'+esc(s.label)+'</span><span class="damt">'+fmtNum(s.v)+'</span>'+
      '<span class="dpct" style="color:'+s.color+'">'+((s.v/t)*100).toFixed(1)+"%</span>"+
      '<span class="dtrack bar-mini"><i style="width:'+(s.v/max*100).toFixed(1)+"%;background:"+s.color+'"></i><i class="hlmark"></i></span>'+
      "</div>").join("")+"</div>";
}
/* Stacked monthly columns. Rendered in a fixed viewBox and scaled by the well,
   so the same function fits a full-width panel and a drawer block. */
function stackedBars(cats,series,opts){
  opts=opts||{};
  const W=opts.w||560,H=opts.h||236,padL=34,padB=30,padT=12,padR=6;
  const max=Math.max(1,...cats.map(c=>c.parts.reduce((a,p)=>a+p.v,0)));
  const niceMax=Math.ceil(max/5)*5;
  const bw=(W-padL-padR)/cats.length, bar=Math.min(34,bw*0.62);
  const Y=v=>H-padB-(v/niceMax)*(H-padB-padT);
  let g="";
  for(let i=0;i<=4;i++){
    const v=niceMax*i/4, y=Y(v);
    g+='<line x1="'+padL+'" y1="'+y.toFixed(1)+'" x2="'+(W-padR)+'" y2="'+y.toFixed(1)+'" stroke="var(--hair)" stroke-dasharray="'+(i?"2 3":"0")+'"/>'+
       '<text x="'+(padL-6)+'" y="'+(y+3.5).toFixed(1)+'" text-anchor="end" font-size="'+cf(8.5)+'" fill="var(--ink-3)" font-family="var(--mono)">'+Math.round(v)+"</text>";
  }
  const px=(H-padB-padT)/niceMax;   // pixels per alert, for the highlight overlay
  cats.forEach((c,i)=>{
    const x=padL+i*bw+(bw-bar)/2; let acc=0;
    const tot=c.parts.reduce((a,p)=>a+p.v,0);
    const tip=c.parts.filter(p=>p.v>0).map(p=>p.label+"|"+p.v).join("§");
    c.parts.forEach(p=>{
      if(p.v<=0) return;
      const y=Y(acc+p.v),h=Y(acc)-Y(acc+p.v);
      const dim=opts.dim||"sev";
      g+='<rect class="hlctx" x="'+x.toFixed(1)+'" y="'+y.toFixed(1)+'" width="'+bar.toFixed(1)+'" height="'+Math.max(0.6,h).toFixed(1)+
        '" fill="'+p.color+'" rx="1.5" style="cursor:pointer" data-monthbar="'+i+
        '" data-hl-'+dim+'="'+esc(HL_MULTI[dim]?"|"+p.label+"|":p.label)+
        '" data-hlsrc="'+esc(dim+"|"+p.label)+
        (opts.hlMonth?'" data-hl-month="'+i:"")+'" data-tip="'+esc(c.label)+'" data-tipsub="'+tot+
        " "+esc(opts.unitLabel||"alerts")+'" data-tiptable="'+esc(tip)+'"/>';
      acc+=p.v;
    });
    // The selection's own count for this month, drawn from the baseline up: the
    // month a trader's pattern started is visible as a step in this overlay.
    /* Carries enough to describe itself on hover: which month it belongs to, the
       month's own total, and the scale it was drawn at, so the tooltip can read
       the count back out of the height rather than recomputing it. Hit-testing is
       switched on in CSS only while a selection is live — with none, the bar has
       no height and nothing to say. */
    if(opts.hlMonth) g+='<rect class="hlshare" data-hl-for="'+(opts.cut||"")+'month|'+i+'" data-hl-px="'+px.toFixed(4)+'" data-hl-base="'+(H-padB)+
      '" data-tipgen="hlshare" data-hlkeep="1" data-hl-mtot="'+tot+'" data-hl-mlabel="'+esc(c.label+(c.sub?" "+c.sub:""))+
      '" data-hl-unit="'+esc(opts.unitLabel||"alerts")+
      '" x="'+(x+bar*0.28).toFixed(1)+'" y="'+(H-padB)+'" width="'+(bar*0.44).toFixed(1)+'" height="0" rx="1.5" fill="var(--ink)"/>';
    if(tot>0) g+='<text class="hlctx" x="'+(x+bar/2).toFixed(1)+'" y="'+(Y(tot)-4).toFixed(1)+'" text-anchor="middle" font-size="'+cf(8.5)+'" font-family="var(--mono)" fill="var(--ink-3)">'+tot+"</text>";
    g+='<text x="'+(x+bar/2).toFixed(1)+'" y="'+(H-padB+13)+'" text-anchor="middle" font-size="'+cf(8.5)+'" fill="var(--ink-3)">'+esc(c.label)+"</text>";
    if(c.sub) g+='<text x="'+(x+bar/2).toFixed(1)+'" y="'+(H-padB+23)+'" text-anchor="middle" font-size="'+cf(7.5)+'" fill="var(--ink-3)" opacity=".8">'+esc(c.sub)+"</text>";
  });
  return '<svg viewBox="0 0 '+W+" "+H+'" preserveAspectRatio="xMidYMid meet" role="img">'+g+"</svg>";
}
/* Daily alert counts with a 7-day mean — the volume line an officer watches for
   a step change in the floor's behaviour. */
function dailyTrend(vals,opts){
  opts=opts||{};
  const W=opts.w||900,H=opts.h||240,padL=30,padB=30,padT=12,padR=8;
  const n=vals.length, max=Math.max(3,...vals);
  const niceMax=Math.ceil(max/4)*4;
  const X=i=>padL+(i/(n-1||1))*(W-padL-padR);
  const Y=v=>H-padB-(v/niceMax)*(H-padB-padT);
  let g="";
  for(let i=0;i<=4;i++){
    const v=niceMax*i/4,y=Y(v);
    g+='<line x1="'+padL+'" y1="'+y.toFixed(1)+'" x2="'+(W-padR)+'" y2="'+y.toFixed(1)+'" stroke="var(--hair)" stroke-dasharray="'+(i?"2 3":"0")+'"/>'+
       '<text x="'+(padL-5)+'" y="'+(y+3.5).toFixed(1)+'" text-anchor="end" font-size="'+cf(8.5)+'" fill="var(--ink-3)" font-family="var(--mono)">'+Math.round(v)+"</text>";
  }
  // Month gridlines and labels, driven off the calendar rather than the index.
  for(let i=0;i<n;i++){
    const d=dateForIdx(DAYS-n+i);
    if(d.getDate()===1){
      g+='<line x1="'+X(i).toFixed(1)+'" y1="'+padT+'" x2="'+X(i).toFixed(1)+'" y2="'+(H-padB)+'" stroke="var(--hair)" opacity=".7"/>'+
         '<text x="'+(X(i)+3).toFixed(1)+'" y="'+(H-padB+13)+'" font-size="'+cf(8.5)+'" fill="var(--ink-3)">'+MONTHS[d.getMonth()]+"</text>";
    }
  }
  const area="M"+X(0).toFixed(1)+","+(H-padB)+" "+vals.map((v,i)=>X(i).toFixed(1)+","+Y(v).toFixed(1)).join(" ")+" L"+X(n-1).toFixed(1)+","+(H-padB)+"Z";
  g+='<path class="hlctx" d="'+area+'" fill="color-mix(in srgb,var(--run) 16%,transparent)"/>';
  g+='<polyline class="hlctx" points="'+vals.map((v,i)=>X(i).toFixed(1)+","+Y(v).toFixed(1)).join(" ")+'" fill="none" stroke="var(--run)" stroke-width="1.1" opacity=".85"/>';
  const ma=vals.map((_,i)=>{ const lo=Math.max(0,i-6); let s=0; for(let j=lo;j<=i;j++) s+=vals[j]; return s/(i-lo+1); });
  g+='<polyline class="hlctx" points="'+ma.map((v,i)=>X(i).toFixed(1)+","+Y(v).toFixed(1)).join(" ")+'" fill="none" stroke="var(--violet)" stroke-width="2.2"/>';
  /* The selection's own daily counts, filled against the same axis. Against the
     floor's volume it answers the question the total cannot: is this name's
     activity constant, or did it start on a date? */
  g+='<path class="hlseries" d="" fill="var(--ink)" fill-opacity=".62" stroke="var(--ink)" stroke-width="1" pointer-events="none"'+
     ' data-x0="'+padL+'" data-dx="'+((W-padL-padR)/(n-1||1)).toFixed(4)+'" data-base="'+(H-padB)+
     '" data-py="'+((H-padB-padT)/niceMax).toFixed(4)+'" data-n="'+n+'"/>';
  return '<svg viewBox="0 0 '+W+" "+H+'" preserveAspectRatio="none" role="img">'+g+"</svg>";
}
/* Ranked horizontal bars. Each row can declare itself an aggregate of one
   dimension (`it.agg`), in which case it dims when the current selection is
   absent from it and carries a dark marker sized to the selection's share of
   that bar — the "how much of this rule is this one trader?" read. */
function hbars(items,opts){
  opts=opts||{};
  const W=opts.w||520,rowH=opts.rowH||22,labW=opts.labW||150,valW=46;
  const max=Math.max(1,...items.map(i=>i.v));
  const barW=W-labW-valW-8;
  let g="",y=6;
  items.forEach(it=>{
    const w=Math.max(1,it.v/max*barW);
    const tipAttrs=it.tip?' data-tip="'+esc(it.tip)+'" data-tipsub="'+esc(it.tipsub||"")+
      '" data-tiptable="'+esc(it.tiptable||"")+'"':"";
    const open=it.agg?'<g '+it.agg+" "+(it.hl||"")+tipAttrs+' style="cursor:pointer">':"<g"+tipAttrs+">";
    g+=open;
    g+='<text x="0" y="'+(y+10)+'" font-size="'+cf(9.5)+'" fill="var(--ink-2)">'+esc(it.label)+"</text>";
    g+='<rect x="'+labW+'" y="'+(y+1)+'" width="'+w.toFixed(1)+'" height="11" rx="2.5" fill="'+(it.color||"var(--run)")+
      '" style="cursor:pointer" '+(it.click||"")+'><title>'+esc(it.label)+": "+it.v+"</title></rect>";
    if(it.v2!=null){
      const w2=it.v2/max*barW;
      g+='<rect x="'+labW+'" y="'+(y+1)+'" width="'+Math.max(0,w2).toFixed(1)+'" height="11" rx="2.5" fill="var(--fail)" opacity=".92"><title>'+esc(it.label)+": "+it.v2+" suspicious</title></rect>";
    }
    g+='<text x="'+(W-2)+'" y="'+(y+10)+'" text-anchor="end" font-size="'+cf(9.5)+'" font-family="var(--mono)" font-weight="700" fill="var(--ink-2)">'+esc(it.vLabel||String(it.v))+"</text>";
    g+="</g>";
    if(it.aggKey) g+='<rect class="hlmark-svg" data-hl-for="'+esc(it.aggKey)+'" data-hl-total="'+it.v+'" data-hl-len="'+w.toFixed(1)+
      '" x="'+labW+'" y="'+(y+1)+'" width="0" height="11" rx="2.5" fill="var(--ink)" pointer-events="none"/>';
    y+=rowH;
  });
  return '<svg viewBox="0 0 '+W+" "+Math.max(y+2,20)+'" preserveAspectRatio="xMinYMin meet" role="img">'+g+"</svg>";
}
/* Twenty-four columns, one per hour of the desk-local trading day. Shaded bands
   mark the hours outside any desk's window, so "outside hours" is a region of
   the chart rather than a number the reader has to hold in their head. */
function hourChart(counts,opts){
  opts=opts||{};
  const W=opts.w||560,H=opts.h||212,padL=30,padB=28,padT=14,padR=8;
  const max=Math.max(1,...counts), niceMax=Math.ceil(max/4)*4;
  const bw=(W-padL-padR)/24, bar=Math.min(17,bw*0.72);
  const Y=v=>H-padB-(v/niceMax)*(H-padB-padT);
  const px=(H-padB-padT)/niceMax;
  let g="";
  // Nobody's desk is open before 07:00 or after 19:30 local.
  [[0,7],[19.5,24]].forEach(b=>{
    const x=padL+b[0]*bw;
    g+='<rect x="'+x.toFixed(1)+'" y="'+padT+'" width="'+((b[1]-b[0])*bw).toFixed(1)+'" height="'+(H-padB-padT)+
      '" fill="var(--fail)" opacity=".055"/>';
  });
  for(let i=0;i<=4;i++){
    const v=niceMax*i/4,y=Y(v);
    g+='<line x1="'+padL+'" y1="'+y.toFixed(1)+'" x2="'+(W-padR)+'" y2="'+y.toFixed(1)+'" stroke="var(--hair)" stroke-dasharray="'+(i?"2 3":"0")+'"/>'+
       '<text x="'+(padL-5)+'" y="'+(y+3.5).toFixed(1)+'" text-anchor="end" font-size="'+cf(8.5)+'" fill="var(--ink-3)" font-family="var(--mono)">'+Math.round(v)+"</text>";
  }
  /* The columns are aggregates in their own right: pick a trader anywhere on the
     page and this chart redraws as that trader's session, lit where they deal and
     dark where they don't. The cut has to match what the chart counts — deals on
     the activity tab, alerts on the detection one — or the marker is scaled
     against a population sixteen times larger than the bar it sits in. */
  const cut=opts.cut||"", noun=opts.unitLabel||"Alerts";
  const tot=Math.max(1,counts.reduce((a,c)=>a+c,0));
  counts.forEach((v,h)=>{
    const x=padL+h*bw+(bw-bar)/2;
    const outside=h<7||h>=19;
    g+='<rect x="'+x.toFixed(1)+'" y="'+Y(v).toFixed(1)+'" width="'+bar.toFixed(1)+'" height="'+Math.max(0.6,(H-padB)-Y(v)).toFixed(1)+
      '" rx="1.5" fill="'+(outside?"var(--fail)":"var(--agent)")+'" data-hl-hour="'+h+'" data-hlsrc="hour|'+h+'" data-hlpin="1" '+
      hlAgg(cut+"hour",h,v)+
      ' style="cursor:pointer" data-tip="'+pad2(h)+":00 – "+pad2((h+1)%24)+':00" data-tipsub="'+(outside?"Outside every desk's trading window":"Within desk hours")+
      '" data-tiptable="'+esc(noun)+"|"+v+"§Share of the day|"+(v/tot*100).toFixed(1)+'%"/>';
    g+='<rect class="hlshare" data-hl-for="'+cut+'hour|'+h+'" data-hl-px="'+px.toFixed(4)+'" data-hl-base="'+(H-padB)+
      '" x="'+(x+bar*0.26).toFixed(1)+'" y="'+(H-padB)+'" width="'+(bar*0.48).toFixed(1)+'" height="0" rx="1.5" fill="var(--ink)" pointer-events="none"/>';
    if(h%3===0) g+='<text x="'+(x+bar/2).toFixed(1)+'" y="'+(H-padB+12)+'" text-anchor="middle" font-size="'+cf(8.5)+'" fill="var(--ink-3)" font-family="var(--mono)">'+pad2(h)+"</text>";
  });
  g+='<text x="'+(padL+3.5*bw).toFixed(1)+'" y="'+(padT+9)+'" text-anchor="middle" font-size="'+cf(8)+'" fill="var(--fail)" opacity=".75">outside desk hours</text>';
  g+='<text x="'+(padL+21.5*bw).toFixed(1)+'" y="'+(padT+9)+'" text-anchor="middle" font-size="'+cf(8)+'" fill="var(--fail)" opacity=".75">outside</text>';
  return '<svg viewBox="0 0 '+W+" "+H+'" preserveAspectRatio="xMidYMid meet" role="img">'+g+"</svg>";
}
/* ISO 8601 week numbering, so "weeks 1–9" means the weeks a calendar actually
   labels 1 to 9 rather than a count backwards from today. */
function isoWeek(d){
  const t=new Date(Date.UTC(d.getFullYear(),d.getMonth(),d.getDate()));
  t.setUTCDate(t.getUTCDate()-((t.getUTCDay()+6)%7)+3);
  const ft=new Date(Date.UTC(t.getUTCFullYear(),0,4));
  ft.setUTCDate(ft.getUTCDate()-((ft.getUTCDay()+6)%7)+3);
  return 1+Math.round((t-ft)/(7*dayMs));
}
function isoWeekYear(d){
  const t=new Date(Date.UTC(d.getFullYear(),d.getMonth(),d.getDate()));
  t.setUTCDate(t.getUTCDate()-((t.getUTCDay()+6)%7)+3);
  return t.getUTCFullYear();
}
const dayOfYear=d=>Math.round((new Date(d.getFullYear(),d.getMonth(),d.getDate())-new Date(d.getFullYear(),0,0))/dayMs);
/* "1-9", "1 – 9", "5", or blank for the whole year. */
function parseRange(v){
  const m=String(v==null?"":v).replace(/[–—]/g,"-").match(/^\s*(\d+)\s*(?:-\s*(\d+))?\s*$/);
  if(!m) return [null,null];
  const a=+m[1], b=m[2]?+m[2]:+m[1];
  return [Math.min(a,b),Math.max(a,b)];
}

/* A prior year of trading, aggregated only — counts, notional and tenor mix per
   trader per day. The alert book covers one year, so a year-on-year comparison
   has nothing to sit against without it. Built from the same desk weights,
   seasonality and product mix as the live book, a shade quieter, so last year
   looks like the same floor rather than like a different one. */
const PRIOR_ACT={};
(function buildPriorYear(){
  TRADERS.forEach(t=>{ PRIOR_ACT[t.id]={}; });
  for(let d=0;d<DAYS;d++){
    const date=new Date(dateForIdx(d).getTime()-365*dayMs);
    if(!isBiz(date)) continue;
    const iso=isoDate(date);
    const dom=date.getDate(), eom=new Date(date.getFullYear(),date.getMonth()+1,0).getDate();
    const eomBoost=dom>=eom-1?1.35:dom>=eom-3?1.15:1;
    const seasonal=0.86+0.28*Math.sin((d+31)/58);
    DESKS.forEach(desk=>{
      const n=Math.max(1,Math.round(desk.traders.length*desk.dpt*seasonal*eomBoost*rand(0.72,1.28)*0.93));
      for(let i=0;i<n;i++){
        const tr=weightedChoice(desk.traders.map(x=>[x,x.grade==="Associate"?1.35:x.grade==="Senior"?1.15:0.85]));
        const prod=choice(tr.products), meta=PROD_BY_NAME[prod];
        const notional=Math.min(tr.ticketLimit*0.94,Math.max(0.4,lognorm(meta.med,meta.sig)));
        const band=tenorBandOf(choice(meta.tenors));
        const rec=PRIOR_ACT[tr.id][iso]||(PRIOR_ACT[tr.id][iso]={n:0,notional:0,tenor:{}});
        rec.n++; rec.notional+=notional; rec.tenor[band]=(rec.tenor[band]||0)+1;
      }
    });
  }
})();

/* A stacked column chart with no axes and no labels, sized for a grid cell.
   Squeezed on purpose: at this size a book's shape — a steady hum, a burst, a
   gap, a step change in what is being traded — is legible before any number is.
   With year-on-year on, the same period twelve months earlier is drawn over it
   as a line, so this year's shape is read against last year's rather than
   against nothing. */
function sparkStack(cols,segs,opts){
  opts=opts||{};
  const W=opts.w||188, H=opts.h||64, gap=cols.length>40?0.4:cols.length>26?0.7:1;
  const tot=c=>segs.reduce((a,sg)=>a+(c.v[sg.label]||0),0);
  const yoy=!!opts.yoy;
  const max=Math.max(1e-9,...cols.map(tot),yoy?Math.max(...cols.map(c=>c.prior||0)):0,opts.max||0);
  const bw=Math.max(0.8,(W-(cols.length-1)*gap)/cols.length);
  let g='<rect x="0" y="0" width="'+W+'" height="'+H+'" fill="var(--panel-2)" rx="3"/>';
  cols.forEach((c,i)=>{
    const x=i*(bw+gap), t=tot(c);
    let acc=0;
    segs.forEach(sg=>{
      const v=c.v[sg.label]||0; if(v<=0) return;
      const h=(v/max)*(H-2), y=H-1-((acc+v)/max)*(H-2);
      g+='<rect x="'+x.toFixed(2)+'" y="'+y.toFixed(2)+'" width="'+bw.toFixed(2)+'" height="'+Math.max(0.6,h).toFixed(2)+'" fill="'+sg.color+'"/>';
      acc+=v;
    });
    if(t>0||c.prior>0) g+='<rect class="ssHit" x="'+x.toFixed(2)+'" y="0" width="'+bw.toFixed(2)+'" height="'+H+'" fill="transparent"'+
      ' data-tip="'+esc(c.label)+'" data-tipsub="'+esc(opts.unit==="m"?fmtM(t):fmtNum(t)+" deals")+
      '" data-tiptable="'+esc(segs.filter(sg=>(c.v[sg.label]||0)>0).map(sg=>sg.label+"|"+(opts.unit==="m"?fmtM(c.v[sg.label]):fmtNum(c.v[sg.label]))).join("§")+
        (yoy?"§Same period last year|"+(opts.unit==="m"?fmtM(c.prior||0):fmtNum(Math.round(c.prior||0))):""))+'"/>';
  });
  if(yoy){
    const pts=cols.map((c,i)=>((i*(bw+gap))+bw/2).toFixed(2)+","+(H-1-((c.prior||0)/max)*(H-2)).toFixed(2)).join(" ");
    g+='<polyline points="'+pts+'" fill="none" stroke="var(--ink)" stroke-width="1.3" stroke-dasharray="3 2" opacity=".75"/>';
  }
  return '<svg viewBox="0 0 '+W+" "+H+'" preserveAspectRatio="none" class="sstack" role="img">'+g+"</svg>";
}

/* Tenor as a scatter rather than a stack. A stack tells you the mix; it does not
   tell you whether a trader writes one maturity or twenty. Here each dot is a
   bucket of deals at a tenor, sized by how many — so a book concentrated on one
   point of the curve is a single row of large dots, and a book spread across it
   is a column of small ones. The y axis is logarithmic because the book runs
   from overnight to fifty years. */
const TSC_MIN=0.003, TSC_MAX=52;
const tscY=y=>Math.log(Math.max(TSC_MIN,Math.min(TSC_MAX,y))/TSC_MIN)/Math.log(TSC_MAX/TSC_MIN);
function tenorScatter(cols,opts){
  opts=opts||{};
  const W=opts.w||188, H=opts.h||64, BINS=13;
  const yoy=!!opts.yoy;
  let g='<rect x="0" y="0" width="'+W+'" height="'+H+'" fill="var(--panel-2)" rx="3"/>';
  [[1/12,"1M"],[1,"1Y"],[5,"5Y"],[30,"30Y"]].forEach(t=>{
    const y=H-1-tscY(t[0])*(H-2);
    g+='<line x1="0" y1="'+y.toFixed(1)+'" x2="'+W+'" y2="'+y.toFixed(1)+'" stroke="var(--hair)" stroke-dasharray="1 3"/>';
  });
  const bw=W/Math.max(1,cols.length);
  let maxN=1;
  const binned=cols.map(c=>{
    const bins=new Array(BINS).fill(0);
    (c.tenors||[]).forEach(y=>{ const b=Math.min(BINS-1,Math.floor(tscY(y)*BINS)); bins[b]++; if(bins[b]>maxN) maxN=bins[b]; });
    return bins;
  });
  const rMax=Math.max(1.1,Math.min(bw*0.62,(H-2)/BINS*0.72));
  binned.forEach((bins,i)=>{
    const cx=i*bw+bw/2;
    bins.forEach((n,b)=>{
      if(!n) return;
      const yv=TSC_MIN*Math.pow(TSC_MAX/TSC_MIN,(b+0.5)/BINS);
      const cy=H-1-tscY(yv)*(H-2);
      const r=Math.max(0.8,Math.sqrt(n/maxN)*rMax);
      const band=TENOR_BANDS.find(x=>yv<=x.max)||TENOR_BANDS[TENOR_BANDS.length-1];
      g+='<circle cx="'+cx.toFixed(2)+'" cy="'+cy.toFixed(2)+'" r="'+r.toFixed(2)+'" fill="'+band.color+'" fill-opacity=".78"/>';
    });
  });
  // The trader's own median tenor, and last year's for comparison.
  const med=cols.map((c,i)=>{
    const ts=(c.tenors||[]).slice().sort((a,b)=>a-b);
    return ts.length?{x:i*bw+bw/2,y:H-1-tscY(median(ts))*(H-2)}:null;
  }).filter(Boolean);
  if(med.length>1) g+='<polyline points="'+med.map(m=>m.x.toFixed(2)+","+m.y.toFixed(2)).join(" ")+
    '" fill="none" stroke="var(--ink-2)" stroke-width="1.1" opacity=".7"/>';
  if(yoy){
    const p=cols.map((c,i)=>c.priorTenor?{x:i*bw+bw/2,y:H-1-tscY(c.priorTenor)*(H-2)}:null).filter(Boolean);
    if(p.length>1) g+='<polyline points="'+p.map(m=>m.x.toFixed(2)+","+m.y.toFixed(2)).join(" ")+
      '" fill="none" stroke="var(--ink)" stroke-width="1.2" stroke-dasharray="3 2" opacity=".7"/>';
  }
  cols.forEach((c,i)=>{
    const ts=c.tenors||[];
    if(!ts.length&&!c.priorTenor) return;
    const s2=ts.slice().sort((a,b)=>a-b);
    g+='<rect class="ssHit" x="'+(i*bw).toFixed(2)+'" y="0" width="'+bw.toFixed(2)+'" height="'+H+'" fill="transparent"'+
      ' data-tip="'+esc(c.label)+'" data-tipsub="'+fmtNum(ts.length)+' deals"'+
      ' data-tiptable="'+esc(["Shortest|"+fmtYrs(s2[0]),"Median|"+fmtYrs(median(s2)),"Longest|"+fmtYrs(s2[s2.length-1]),
        "Distinct tenors|"+uniq(s2.map(x=>x.toFixed(2))).length].concat(c.priorTenor?["Median last year|"+fmtYrs(c.priorTenor)]:[]).join("§"))+'"/>';
  });
  return '<svg viewBox="0 0 '+W+" "+H+'" preserveAspectRatio="none" class="sstack" role="img">'+g+"</svg>";
}
const fmtYrs=y=>y==null?"—":y<1/24?"O/N":y<1?Math.round(y*12)+"M":y<10?(+y.toFixed(1))+"Y":Math.round(y)+"Y";

/* The columns of every chart: a calendar year, cut into ISO weeks or into days,
   optionally narrowed to a numbered range. */
function actColumns(){
  const A=state.act, wk=A.unit==="week";
  const [lo,hi]=parseRange(A.range);
  const byKey={}, cols=[];
  for(let d=0;d<DAYS;d++){
    const date=dateForIdx(d);
    if((wk?isoWeekYear(date):date.getFullYear())!==A.year) continue;
    const num=wk?isoWeek(date):dayOfYear(date);
    if(lo!=null&&(num<lo||num>hi)) continue;
    if(!byKey[num]){
      byKey[num]={key:num,days:[],dates:[],label:(wk?"Week ":"Day ")+num+" of "+A.year};
      cols.push(byKey[num]);
    }
    byKey[num].days.push(d);
    byKey[num].dates.push(isoDate(new Date(date.getTime()-365*dayMs)));
  }
  cols.sort((a,b)=>a.key-b.key);
  cols.forEach(c=>{ c.label+=" · "+fmtDateShort(dateForIdx(c.days[0]))+
    (c.days.length>1?" – "+fmtDateShort(dateForIdx(c.days[c.days.length-1])):""); });
  return cols;
}
/* Weekly (or daily) activity per trader, bucketed once over the book. */
function traderActivity(cols,metric){
  const tenor=metric==="tenor";
  const segs=tenor?TENOR_BANDS.map(b=>({label:b.label,color:b.color})):ASSET_CLASSES.map(a=>({label:a,color:AC_COLOR[a]}));
  const by={};
  TRADERS.forEach(t=>{
    by[t.id]=cols.map(c=>{
      const cell={v:{},label:c.label,tenors:tenor?[]:null,prior:0,priorTenor:null};
      c.days.forEach(d=>{
        (byTraderDay.get(t.id+"|"+d)||[]).forEach(x=>{
          if(!tradeMatchesRail(x)) return;
          if(tenor) cell.tenors.push(tenorYears(x.tenor));
          const k=tenor?tenorBandOf(x.tenor):x.ac;
          cell.v[k]=(cell.v[k]||0)+(metric==="notional"?x.notional:1);
        });
      });
      let pw=0,pn=0;
      c.dates.forEach(iso=>{
        const r=(PRIOR_ACT[t.id]||{})[iso]; if(!r) return;
        cell.prior+=metric==="notional"?r.notional:r.n;
        Object.keys(r.tenor).forEach(b=>{ pw+=r.tenor[b]*(BAND_MID[b]||1); pn+=r.tenor[b]; });
      });
      if(pn) cell.priorTenor=pw/pn;
      return cell;
    });
  });
  return {segs,by};
}
