/* ============================================================
   Data adapter — the only file that touches the bank's data

   Everything the application needs is declared here and nowhere else. Supply
   a payload and the dashboard runs; supply nothing and it says so rather than
   rendering an empty shell that looks like a quiet day.

   Two ways in, checked in this order:
     1. window.TM_DATA  — set by a <script> the server renders, or by your own
        bootstrap before this file loads.
     2. ./data.json     — fetched at start-up. Needs a web server; opening the
        file straight off disk will be blocked by the browser's file:// rules.

   The payload shape is specified in DATA-CONTRACT.md, and data.json in this
   folder is a working example of it.
============================================================ */
const TM_REQUIRED=["desks","traders","counterparties","instruments","trades","alerts","baselines"];

let DESKS=[], TRADERS=[], COUNTERPARTIES=[], INSTRUMENTS=[], TRADES=[], ALERTS=[], BASE={};
const DESK_BY_ID={}, TRADER_BY_ID={}, INST_BY_KEY={}, TRADES_BY_ID={}, ALERT_BY_ID={};
const byTraderDay=new Map();                       // "traderId|dayIdx" -> [trade]

function tmFail(msg,detail){
  const host=document.getElementById("pane")||document.body;
  host.innerHTML='<div class="empty" style="margin:40px auto;max-width:46em;text-align:left">'+
    '<b>The dashboard has no data to show.</b><br><br>'+msg+
    (detail?'<br><br><code style="font-size:.75rem">'+String(detail).replace(/[<&]/g,"")+'</code>':"")+
    '<br><br>See DATA-CONTRACT.md for the payload this build expects.</div>';
}

/* Rebuilds everything the generators used to leave behind: the lookup indexes,
   the day index, the trade-to-alert back-references and the peer cohorts. A
   payload therefore carries facts only — no cross-references to keep in step,
   because a JSON file cannot hold a cycle and a hand-maintained one goes stale. */
function tmHydrate(d){
  const missing=TM_REQUIRED.filter(k=>!Array.isArray(d[k])&&typeof d[k]!=="object");
  if(missing.length) throw new Error("payload is missing: "+missing.join(", "));

  DESKS=d.desks; TRADERS=d.traders; COUNTERPARTIES=d.counterparties;
  INSTRUMENTS=d.instruments; TRADES=d.trades; ALERTS=d.alerts; BASE=d.baselines;

  DESKS.forEach(x=>DESK_BY_ID[x.id]=x);
  TRADERS.forEach(t=>TRADER_BY_ID[t.id]=t);
  INSTRUMENTS.forEach(i=>INST_BY_KEY[i.key]=i);

  // desk.traders and trader.peers are rebuilt here, never carried in the file
  DESKS.forEach(x=>x.traders=[]);
  TRADERS.forEach(t=>{ const dk=DESK_BY_ID[t.deskId]; if(dk) dk.traders.push(t); });
  const cohorts={};
  TRADERS.forEach(t=>(cohorts[t.cohort]=cohorts[t.cohort]||[]).push(t));
  TRADERS.forEach(t=>{ t.peers=cohorts[t.cohort]||[t]; });

  TRADES.forEach(t=>{
    t.date=new Date(t.iso);
    if(t.valueDate) t.valueDate=new Date(t.valueDate);
    t.alerts=t.alerts||[]; t.flags=t.flags||[];
    TRADES_BY_ID[t.id]=t;
    const k=t.traderId+"|"+t.dayIdx;
    (byTraderDay.get(k)||byTraderDay.set(k,[]).get(k)).push(t);
  });
  ALERTS.forEach(a=>{
    a.date=new Date(a.iso);
    ALERT_BY_ID[a.id]=a;
    (a.tradeIds||[]).forEach(id=>{ const t=TRADES_BY_ID[id]; if(t) t.alerts.push(a); });
  });
  // the flag the blotter reads, derived rather than carried
  TRADES.forEach(t=>{ if(t.alerts.length) t.flags=[...new Set(t.alerts.map(a=>a.ruleId))]; });
}

function tmStart(d){
  try{ tmHydrate(d); }
  catch(e){ tmFail("The payload was found but could not be read.",e.message); return; }
  if(!TRADES.length){ tmFail("The payload loaded but contains no trades."); return; }
  if(typeof applyReviews==="function") applyReviews();
  if(typeof buildDerived==="function") buildDerived();
  render();
}

