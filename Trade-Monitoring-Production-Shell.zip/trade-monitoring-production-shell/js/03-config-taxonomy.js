/* ============================================================
   Product taxonomy and banding
   Lifted out of the demo data: these are configuration, not sample data.
   Tune them to the bank's own product set — every chart axis, filter and
   band boundary is driven from here, and from here only, so the panels
   cannot disagree with one another about where a deal belongs.
============================================================ */
/* Counterparties with a documented connection to a member of staff — the
   related-party register the surveillance system reconciles trades against. */
/* Benchmark and block flow is institutional: a family-office trust printing
   $300m into the 4pm fix reads as a data error rather than as a finding. */
const INST_TYPES=["Bank","Hedge Fund","Asset Manager","Broker","Insurer"];
const RELATED_PARTIES={
  "Verandah Holdings Pte":"Director is the spouse of a member of trading staff",
  "Peregrine Trust (Cayman)":"Beneficial owner matches a staff personal-account declaration",
  "Blue Lantern Ventures":"Registered address shared with a declared staff dependant",
};
/* Jurisdictions the financial-crime policy rates as high risk for payment
   routing, and the names the wall keeps the trading floor out of. Both are
   checked per trader: a wall crossing is granted to a person, not to a desk. */
const HIGH_RISK_JUR=[["Seychelles","High — FATF grey list"],["Panama","High — enhanced due diligence"],
  ["Cyprus","Elevated — shell-company exposure"],["Latvia","Elevated — correspondent banking"],
  ["Cayman","Elevated — beneficial-ownership opacity"],["BVI","High — beneficial-ownership opacity"]];
const RESTRICTED=[["Vantara Property","Advisory mandate live — corporate finance wall"],
  ["Halcyon Airlines","Restructuring committee — bank is a lender"],
  ["Kestrel Mining","Announced acquisition financing in progress"],
  ["Solstice Retail","Covenant negotiation — bank holds material non-public information"]];
const INTERNAL_BOOKS=["TRSY-FUNDING","XVA-DESK","PROP-LEGACY","CVA-HEDGE","STRUCT-WAREHOUSE"];
const CHANNELS=[["Voice",34],["eComm single-dealer",30],["Multi-dealer platform",18],["API / Algo",12],["Internal booking",6]];
const VENUES=["OTC bilateral","SEF / MTF","Exchange (SGX)","Exchange (CME)","Exchange (HKEX)","Interdealer broker","Internal"];

const PRODUCTS=[
  {p:"FX Spot",             ac:"FX Cash",                   fam:"fx",    med:14, sig:1.10, tenors:["T+2"]},
  {p:"FX Forward",          ac:"FX Cash",                   fam:"fx",    med:11, sig:1.05, tenors:["1M","3M","6M","1Y"]},
  {p:"FX Swap",             ac:"FX Cash",                   fam:"fx",    med:22, sig:1.00, tenors:["1W","1M","3M","6M"]},
  {p:"NDF",                 ac:"FX Cash",                   fam:"ndf",   med:8,  sig:1.05, tenors:["1M","3M","6M","1Y"]},
  {p:"FX Vanilla Option",   ac:"FX Options",                fam:"fxopt", med:9,  sig:1.10, tenors:["1M","3M","6M","1Y"]},
  {p:"FX Barrier Option",   ac:"FX Options",                fam:"fxopt", med:7,  sig:1.15, tenors:["3M","6M","1Y"]},
  {p:"FX Digital Option",   ac:"FX Options",                fam:"fxopt", med:5,  sig:1.10, tenors:["1M","3M","6M"]},
  {p:"FX Accumulator",      ac:"FX Derivatives",            fam:"fxopt", med:6,  sig:1.05, tenors:["6M","1Y"]},
  {p:"FX Variance Swap",    ac:"FX Derivatives",            fam:"fxopt", med:4,  sig:1.00, tenors:["3M","6M","1Y"]},
  {p:"FX Futures",          ac:"FX Futures",                fam:"fx",    med:6,  sig:0.95, tenors:["Front month","Back month","Quarterly"]},
  {p:"IRS",                 ac:"Interest Rate Derivatives", fam:"rate",  med:28, sig:1.05, tenors:["2Y","5Y","10Y","30Y"]},
  {p:"OIS",                 ac:"Interest Rate Derivatives", fam:"rate",  med:34, sig:1.00, tenors:["1M","3M","1Y","2Y"]},
  {p:"FRA",                 ac:"Interest Rate Derivatives", fam:"rate",  med:40, sig:0.90, tenors:["3x6","6x9","9x12"]},
  {p:"Swaption",            ac:"Interest Rate Derivatives", fam:"rate",  med:18, sig:1.05, tenors:["1Y into 5Y","2Y into 10Y","5Y into 5Y"]},
  {p:"Cap/Floor",           ac:"Interest Rate Derivatives", fam:"rate",  med:15, sig:1.00, tenors:["2Y","5Y","10Y"]},
  {p:"Inflation Swap",      ac:"Interest Rate Derivatives", fam:"rate",  med:12, sig:1.00, tenors:["5Y","10Y","20Y"]},
  {p:"CCS",                 ac:"Interest Rate Derivatives", fam:"rate",  med:16, sig:1.05, tenors:["3Y","5Y","10Y"]},
  {p:"Cross-Ccy Basis Swap",ac:"Interest Rate Derivatives", fam:"rate",  med:20, sig:1.00, tenors:["1Y","3Y","5Y"]},
  {p:"Govt Bond",           ac:"Bonds",                     fam:"bondg", med:19, sig:1.05, tenors:["2Y","5Y","10Y","30Y"]},
  {p:"Corp Bond",           ac:"Bonds",                     fam:"bondc", med:7,  sig:1.10, tenors:["3Y","5Y","7Y","10Y"]},
  {p:"Bond Forward",        ac:"Bonds",                     fam:"bondg", med:12, sig:1.00, tenors:["1M","3M"]},
  {p:"Repo",                ac:"Repo",                      fam:"repo",  med:75, sig:0.85, tenors:["O/N","1W","1M","3M"]},
  {p:"Reverse Repo",        ac:"Repo",                      fam:"repo",  med:68, sig:0.85, tenors:["O/N","1W","1M","3M"]},
  {p:"Equity Option",       ac:"Equity Derivatives",        fam:"eqopt", med:5,  sig:1.10, tenors:["1M","3M","6M","1Y"]},
  {p:"Equity Swap",         ac:"Equity Derivatives",        fam:"eq",    med:11, sig:1.05, tenors:["3M","6M","1Y"]},
  {p:"Variance Swap",       ac:"Equity Derivatives",        fam:"eqopt", med:4,  sig:1.00, tenors:["3M","6M","1Y"]},
  {p:"Equity Index Future", ac:"Equity Derivatives",        fam:"eq",    med:8,  sig:0.95, tenors:["Front month","Quarterly"]},
  {p:"CDS Single Name",     ac:"Credit Derivatives",        fam:"cds",   med:10, sig:1.00, tenors:["3Y","5Y","10Y"]},
  {p:"CDS Index",           ac:"Credit Derivatives",        fam:"cdsi",  med:25, sig:0.95, tenors:["5Y","10Y"]},
  {p:"Total Return Swap",   ac:"Credit Derivatives",        fam:"trs",   med:14, sig:1.00, tenors:["1Y","3Y","5Y"]},
];
const PROD_BY_NAME={}; PRODUCTS.forEach(p=>PROD_BY_NAME[p.p]=p);
/* The longest maturity each product is actually written to. A 25-year FX
   forward and a 40-year equity swap are not long-dated trades, they are data
   errors — so only the products below can carry a tenor-cap breach. */
const MAX_YEARS={"IRS":50,"CCS":30,"Cross-Ccy Basis Swap":30,"Inflation Swap":50,
  "Cap/Floor":30,"Govt Bond":50,"Corp Bond":30,"CDS Single Name":10,"Total Return Swap":10};
/* Every tenor convention on the book reduced to years, so a swap, a bill, a
   swaption and an FRA can sit in the same bucket. A swaption's risk is its
   underlying, not the option leg, and an FRA's is the far date. */
function tenorYears(t){
  if(!t) return 0.25;
  if(/^O\/N|^T\+/i.test(t)) return 0.004;
  const into=t.match(/into\s+(\d+)\s*Y/i);      if(into) return +into[1];
  const fra=t.match(/^(\d+)x(\d+)$/);            if(fra)  return +fra[2]/12;
  const w=t.match(/^(\d+)\s*W$/i);               if(w)    return +w[1]/52;
  const m=t.match(/^(\d+)\s*M$/);                if(m)    return +m[1]/12;
  const y=t.match(/^(\d+)\s*Y$/i);               if(y)    return +y[1];
  if(/month|quarter/i.test(t)) return 0.25;
  return 0.25;
}
const TENOR_BANDS=[
  {label:"≤ 1 month",   max:1/12,     color:"var(--pass)"},
  {label:"1–12 months", max:1,        color:"var(--agent)"},
  {label:"1–5 years",   max:5,        color:"var(--warn)"},
  {label:"5 years +",   max:Infinity, color:"var(--fail)"},
];
function tenorBandOf(t){
  const y=tenorYears(t);
  for(let i=0;i<TENOR_BANDS.length;i++) if(y<=TENOR_BANDS[i].max) return TENOR_BANDS[i].label;
  return TENOR_BANDS[TENOR_BANDS.length-1].label;
}
const BAND_MID={"≤ 1 month":0.04,"1–12 months":0.5,"1–5 years":3,"5 years +":12};
/* Ticket-size bands. Defined once so the distribution chart and the highlight
   dimension cannot disagree about where a $25m deal belongs. */
const SIZE_BANDS=[[0,1,"< $1m"],[1,5,"$1–5m"],[5,10,"$5–10m"],[10,25,"$10–25m"],[25,50,"$25–50m"],
  [50,100,"$50–100m"],[100,250,"$100–250m"],[250,500,"$250–500m"],[500,Infinity,"$500m +"]];
function sizeBandOf(n){
  for(let i=0;i<SIZE_BANDS.length;i++) if(n>=SIZE_BANDS[i][0]&&n<SIZE_BANDS[i][1]) return SIZE_BANDS[i][2];
  return SIZE_BANDS[SIZE_BANDS.length-1][2];
}

/* Products whose price comes out of a model rather than off a screen. Only
   these can carry a day-one P&L argument; a spot deal is marked within seconds. */
const MODELLED=["FX Barrier Option","FX Digital Option","FX Accumulator","FX Variance Swap",
  "Swaption","Cap/Floor","Inflation Swap","Cross-Ccy Basis Swap","Variance Swap","Equity Swap","Total Return Swap"];
const ASSET_CLASSES=[];
PRODUCTS.forEach(p=>{ if(ASSET_CLASSES.indexOf(p.ac)<0) ASSET_CLASSES.push(p.ac); });
const AC_COLOR={
  "FX Cash":"var(--agent)","FX Options":"var(--run)","FX Derivatives":"var(--cyan)","FX Futures":"var(--violet)",
  "Interest Rate Derivatives":"var(--gold)","Bonds":"var(--pink)","Repo":"var(--ink-3)",
  "Equity Derivatives":"var(--pass)","Credit Derivatives":"var(--fail)"};
const PRODUCTS_BY_AC={}; ASSET_CLASSES.forEach(ac=>PRODUCTS_BY_AC[ac]=PRODUCTS.filter(p=>p.ac===ac).map(p=>p.p));

