/* ============================================================
   Market context
   Powers the market chart in the alert case file: where a deal printed
   against the market it was struck into.

   midAt(instrument, dayIndex, minute) must return the market mid at that
   moment. The demo implementation walked a generated price path; a
   production build should serve it from the tick store (FACT_MARKET_QUOTE
   in the data schema). Until it does, the two market charts in the drawer
   are the only thing affected — everything else runs without it.
============================================================ */
/* The mid at a moment. The session runs from yesterday's close to today's, and
   in between it walks: a Brownian bridge pinned at both ends, so the day has a
   real high and a real low without the close drifting away from the daily path.
   Independent noise per bucket would draw a sawtooth no market ever printed. */
const SESSION_OPEN=420, SESSION_CLOSE=1140, SESSION_BUCKETS=145;
const _bridge=new Map();
function dayBridge(inst,d){
  const k=inst.i+"|"+d;
  let w=_bridge.get(k);
  if(w) return w;
  w=new Array(SESSION_BUCKETS); let acc=0;
  for(let b=0;b<SESSION_BUCKETS;b++){ acc+=hashNoise(inst.i,d,b); w[b]=acc; }
  const end=w[SESSION_BUCKETS-1];
  for(let b=0;b<SESSION_BUCKETS;b++) w[b]=(w[b]-end*b/(SESSION_BUCKETS-1))*inst.dv*0.16;
  _bridge.set(k,w);
  return w;
}
function midAt(inst,day,min){
  const d=Math.max(0,Math.min(DAYS-1,day));
  const m=min==null?SESSION_CLOSE:min;
  const prev=inst.path[Math.max(0,d-1)], close=inst.path[d];
  const f=Math.max(0,Math.min(1,(m-SESSION_OPEN)/(SESSION_CLOSE-SESSION_OPEN)));
  const b=Math.max(0,Math.min(SESSION_BUCKETS-1,Math.round((m-SESSION_OPEN)/5)));
  return prev+(close-prev)*f+dayBridge(inst,d)[b];
}
function volAt(inst,day){
  if(!inst.volPath) return null;
  return inst.volPath[Math.max(0,Math.min(DAYS-1,day))];
}
/* The session's own high and low, sampled at the five-minute grid the intraday
   noise is defined on. */
function dayRange(inst,day){
  let lo=Infinity,hi=-Infinity;
  for(let m=SESSION_OPEN;m<=SESSION_CLOSE;m+=5){ const v=midAt(inst,day,m); if(v<lo)lo=v; if(v>hi)hi=v; }
  return {lo,hi};
}
/* Materiality: eight times the instrument's own dealing spread, never below the
   family floor. A rule that says "25 bps" for every product on the book is a
   rule that cannot fire on a corporate bond and cannot stop firing on a CDS
   index — the threshold has to come from the instrument. */
const omThreshold=inst=>Math.max(inst.omFloor,inst.spreadBps*8);
/* How far the market itself moved between two moments, in bps. Every rule that
   claims a benchmark moved, a close was pushed or a burst walked the level has
   to read that claim off the same path the alert chart draws — otherwise the
   evidence and the picture disagree in front of the officer. */
function mktMove(inst,day,fromMin,toMin){
  const a=midAt(inst,day,fromMin), b=midAt(inst,day,toMin);
  return devBpsOf(inst.unit,b,a);
}
const priceTested=inst=>inst.omFloor>0;
