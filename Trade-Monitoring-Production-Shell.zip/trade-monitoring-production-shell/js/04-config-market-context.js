/* ============================================================
   Market context — served from the tick store

   Powers the market chart in the alert case file: where a deal printed against
   the market it was struck into. The demo walked a generated price path; this
   build reads FACT_MARKET_QUOTE instead, through the index the adapter builds
   from the payload's `quotes` array.

   Every lookup is tolerant of absence. A tick store that does not reach back
   far enough, or does not cover an instrument, is an ordinary condition in a
   first deployment — it must leave the case file open and the rest of the
   evidence readable, not take the drawer down with it. Callers get null and
   the chart says it has no market data for that instrument.
============================================================ */
const SESSION_OPEN=420, SESSION_CLOSE=1140;

/* instrumentKey|dayIdx -> {m:[minutes, ascending], v:[mids], hi, lo}
   Built once by the adapter from the flat quote rows; see DATA-CONTRACT.md. */
const QUOTES=new Map();
const quoteKey=(instKey,day)=>instKey+"|"+day;
function hasMarketData(inst,day){
  if(!inst) return false;
  if(day==null) return QUOTES.size>0&&[...QUOTES.keys()].some(k=>k.indexOf(inst.key+"|")===0);
  return QUOTES.has(quoteKey(inst.key,day));
}

/* The mid at a moment. Quotes are a series of observations, not a continuous
   function, so a request between two of them is interpolated rather than
   snapped to the earlier one: snapping draws a staircase that reads as the
   market standing still, which is exactly the wrong impression on a chart whose
   job is to show how far a print sat from the level. Before the first quote of
   the day and after the last, the series is held flat — extrapolating a trend
   past the data would be inventing it. */
function midAt(inst,day,min){
  if(!inst) return null;
  const d=Math.max(0,Math.min(DAYS-1,day));
  const s=QUOTES.get(quoteKey(inst.key,d));
  if(!s||!s.m.length) return null;
  const m=min==null?SESSION_CLOSE:min;
  if(m<=s.m[0]) return s.v[0];
  if(m>=s.m[s.m.length-1]) return s.v[s.v.length-1];
  let lo=0,hi=s.m.length-1;
  while(hi-lo>1){ const mid=(lo+hi)>>1; if(s.m[mid]<=m) lo=mid; else hi=mid; }
  const span=s.m[hi]-s.m[lo];
  if(!span) return s.v[lo];
  return s.v[lo]+(s.v[hi]-s.v[lo])*((m-s.m[lo])/span);
}

/* The session's own high and low. Taken from the quote rows where the feed
   carries them, because a vendor's stamped high is the one a trader will argue
   from; derived from the observations only as a fallback, where it is bounded
   by the sampling interval and will understate a spike between two quotes. */
function dayRange(inst,day){
  if(!inst) return null;
  const s=QUOTES.get(quoteKey(inst.key,Math.max(0,Math.min(DAYS-1,day))));
  if(!s||!s.v.length) return null;
  if(s.hi!=null&&s.lo!=null) return {lo:s.lo,hi:s.hi};
  let lo=Infinity,hi=-Infinity;
  for(const v of s.v){ if(v<lo)lo=v; if(v>hi)hi=v; }
  return {lo,hi};
}

function volAt(inst,day){
  const s=QUOTES.get(quoteKey(inst.key,Math.max(0,Math.min(DAYS-1,day))));
  return s&&s.vol!=null?s.vol:null;
}

/* Materiality: eight times the instrument's own dealing spread, never below the
   family floor. A rule that says "25 bps" for every product on the book is a
   rule that cannot fire on a corporate bond and cannot stop firing on a CDS
   index — the threshold has to come from the instrument. */
const omThreshold=inst=>Math.max(inst.omFloor||0,(inst.spreadBps||0)*8);

function devBpsOf(unit,px,mid){
  if(unit==="%"||unit==="bps") return (px-mid)*(unit==="%"?100:1);
  return mid?((px-mid)/Math.abs(mid))*10000:0;
}

/* How far the market itself moved between two moments, in bps. Read off the
   same series the chart draws, so the evidence and the picture cannot disagree
   in front of the officer. */
function mktMove(inst,day,fromMin,toMin){
  const a=midAt(inst,day,fromMin), b=midAt(inst,day,toMin);
  return a==null||b==null?null:devBpsOf(inst.unit,b,a);
}
const priceTested=inst=>(inst.omFloor||0)>0;
