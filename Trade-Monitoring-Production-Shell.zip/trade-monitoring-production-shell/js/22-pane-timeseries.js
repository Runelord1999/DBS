/* ============================================================
   Pane — Trade activity time series
   One dot per deal, plotted against the clock. Size is notional, so a block
   stands out from flow without reading a number; colour and shape carry whichever
   dimension the officer is interrogating. The point of the view is not any single
   deal — it is the shape a book makes over months, and the places where that shape
   breaks: a burst of tickets in a quiet week, a name that only trades after the
   close, a size that appears once and never again.
============================================================ */
const TS_SHAPES=["circle","square","triUp","diamond","triDown","hex","plus","star","pent"];
/* A dot's outline, centred on 0,0 at radius r. Shape has to survive at 3px, so
   these are deliberately blunt — a nine-pointed star reads as a smudge. */
function tsMark(shape,cx,cy,r,fill,extra){
  const a=(n,rot)=>{let d="";for(let i=0;i<n;i++){const t=rot+i*2*Math.PI/n;
    d+=(i?" ":"")+(cx+r*Math.cos(t)).toFixed(1)+","+(cy+r*Math.sin(t)).toFixed(1);}return d;};
  const at='fill="'+fill+'" '+(extra||"");
  switch(shape){
    case "square":  return '<rect x="'+(cx-r*.86).toFixed(1)+'" y="'+(cy-r*.86).toFixed(1)+'" width="'+(r*1.72).toFixed(1)+'" height="'+(r*1.72).toFixed(1)+'" '+at+"/>";
    case "triUp":   return '<polygon points="'+a(3,-Math.PI/2)+'" '+at+"/>";
    case "triDown": return '<polygon points="'+a(3,Math.PI/2)+'" '+at+"/>";
    case "diamond": return '<polygon points="'+a(4,-Math.PI/2)+'" '+at+"/>";
    case "pent":    return '<polygon points="'+a(5,-Math.PI/2)+'" '+at+"/>";
    case "hex":     return '<polygon points="'+a(6,0)+'" '+at+"/>";
    case "plus":    { const t=r*.42,o=r*1.05;
      return '<path d="M'+(cx-t)+','+(cy-o)+'h'+(2*t)+'v'+(o-t)+'h'+(o-t)+'v'+(2*t)+'h'+(-(o-t))+'v'+(o-t)+
             'h'+(-2*t)+'v'+(-(o-t))+'h'+(-(o-t))+'v'+(-2*t)+'h'+(o-t)+'z" '+at+"/>"; }
    case "star":    { let d="";for(let i=0;i<10;i++){const t=-Math.PI/2+i*Math.PI/5,rr=i%2?r*.46:r*1.15;
      d+=(i?" ":"")+(cx+rr*Math.cos(t)).toFixed(1)+","+(cy+rr*Math.sin(t)).toFixed(1);}
      return '<polygon points="'+d+'" '+at+"/>"; }
    default:        return '<circle cx="'+cx.toFixed(1)+'" cy="'+cy.toFixed(1)+'" r="'+r.toFixed(1)+'" '+at+"/>";
  }
}
/* Distinct hues by golden angle, with lightness and saturation cycling so that
   neighbouring categories differ on more than hue alone. Sixty-eight traders will
   never be fully separable by colour — the legend and the rail are what make a
   crowded selection readable — but adjacent names stay apart. */
function tsPalette(n){
  const out=[];
  for(let i=0;i<n;i++){
    const h=(i*137.508)%360, s=58+(i%3)*13, l=(i%2?42:56)-(i%4===3?7:0);
    out.push("hsl("+h.toFixed(0)+","+s+"%,"+l+"%)");
  }
  return out;
}
const TS_UNIT_DAYS={day:1,week:7,month:30};
/* The dimensions the dots can be encoded by, and the one rule about combining
   them: a desk is a set of traders, so colouring by both says nothing the desk
   alone did not already say. */
const TS_DIMS=[["ac","Asset class"],["trader","Trader"],["desk","Desk"]];
function tsEncOf(){
  const e=state.ts.enc.filter(d=>TS_DIMS.some(x=>x[0]===d));
  return e.length?e:["ac"];
}
function tsKeyer(dim){
  return dim==="ac"?(t=>t.ac):dim==="trader"?(t=>t.traderId):(t=>t.deskId);
}
function tsLabel(dim,k){
  return dim==="ac"?k
    :dim==="trader"?((TRADER_BY_ID[k]||{}).name||k)
    :((DESK_BY_ID[k]||{}).short||k);
}
/* Zoom runs continuously in pixels per day rather than in steps, because the
   interesting question changes with the scale: at 10px a day you are looking for a
   month that broke pattern, at 40,000 you are looking at the ninety seconds around
   one print. The label tier follows the scale down from months to seconds. */
const TS_PXMIN=4, TS_PXMAX=260000;          // 260,000 px/day ≈ 3px a second
/* Browsers stop honouring a scroll container past about 33.5 million pixels and
   truncate it without saying so, which would quietly make the far end of a long
   window unreachable. Hold the canvas below that and let the horizon set the
   deepest zoom — a year still reaches five-second ticks, which is far enough. */
const TS_MAXCANVAS=30000000;
/* Weekends and holidays are drawn at a fifth of a weekday's width. Almost nothing
   is booked on them, so at full width they spent two sevenths of the axis saying
   nothing while the weekdays either side were squeezed. The axis is therefore
   piecewise rather than linear in time, and every conversion between a minute and
   a pixel has to go through the two functions below — including the zoom anchor
   and the visible-slice search, which is why they are cached prefix sums rather
   than a loop. */
const TS_WEEKEND_W=0.2;
const TS_DAYW=new Array(DAYS), TS_CUM=new Float64Array(DAYS+1);
(function tsAxisScale(){
  for(let d=0;d<DAYS;d++){
    TS_DAYW[d]=isBiz(dateForIdx(d))?1:TS_WEEKEND_W;
    TS_CUM[d+1]=TS_CUM[d]+TS_DAYW[d];
  }
})();
// Day-units spanned between two day indices, and the inverse.
const tsSpanUnits=(a,b)=>TS_CUM[Math.max(0,Math.min(DAYS,b))]-TS_CUM[Math.max(0,Math.min(DAYS,a))];
/* A minute to day-units from day zero. */
function tsUnitsAt(tmin){
  const d=Math.floor(tmin/1440);
  if(d<0) return TS_CUM[0]+(tmin/1440);
  if(d>=DAYS) return TS_CUM[DAYS]+(tmin/1440-DAYS);
  return TS_CUM[d]+((tmin-d*1440)/1440)*TS_DAYW[d];
}
/* And back again, by binary search over the prefix sums. */
function tsMinAt(units){
  if(units<=TS_CUM[0]) return units*1440;
  if(units>=TS_CUM[DAYS]) return (DAYS+(units-TS_CUM[DAYS]))*1440;
  let lo=0,hi=DAYS;
  while(lo<hi-1){ const m=(lo+hi)>>1; if(TS_CUM[m]<=units) lo=m; else hi=m; }
  return (lo+((units-TS_CUM[lo])/TS_DAYW[lo]))*1440;
}
const tsSpanDays=()=>Math.max(1,Math.min(DAYS,Math.round(state.ts.n*TS_UNIT_DAYS[state.ts.unit])));
const tsMaxPx=()=>Math.min(TS_PXMAX,TS_MAXCANVAS/Math.max(1,tsSpanUnits(Math.max(0,DAYS-tsSpanDays()),DAYS)));
const TS_UNIT_MIN={sec:1/60,min:1,hour:60,day:1440};
const TS_TIERS=[
  {unit:"sec",step:1},{unit:"sec",step:5},{unit:"sec",step:15},{unit:"sec",step:30},
  {unit:"min",step:1},{unit:"min",step:5},{unit:"min",step:15},{unit:"min",step:30},
  {unit:"hour",step:1},{unit:"hour",step:3},{unit:"hour",step:6},{unit:"hour",step:12},
  {unit:"day",step:1},{unit:"day",step:2},{unit:"day",step:7},{unit:"day",step:14},{unit:"day",step:30},
];
/* Chosen by the room a label needs rather than by a zoom threshold, so ticks thin
   out smoothly instead of collapsing into a smear at the deep end — the old table
   put a one-second label every three pixels at full zoom. */
const TS_LABEL_PX=64;
function tsTier(px){
  const perMin=px/1440;
  for(const t of TS_TIERS) if(TS_UNIT_MIN[t.unit]*t.step*perMin>=TS_LABEL_PX) return t;
  return TS_TIERS[TS_TIERS.length-1];
}

/* Deals in time order, cached against the rail and the chart's own member picks.
   The window can be any slice of the year, so the draw does a binary search rather
   than a scan — at 59,000 deals and a redraw per wheel notch that difference is
   the difference between usable and not. */
let TS_CACHE={sig:null,rows:null};
function tsRows(){
  const S=state.ts;
  /* The trader picks only bite while trader is an encoded dimension. Enforcing
     that here rather than only where the dimension is switched means no other
     path can leave a filter applied with no control on screen to show it. */
  const pk=tsEncOf().indexOf("trader")>=0?S.pick.trader:[];
  const sig=JSON.stringify([[...state.filters.trader],[...state.filters.desk],
    [...state.filters.assetClass],pk]);
  if(TS_CACHE.sig===sig) return TS_CACHE.rows;
  const rows=TRADES.filter(t=>tradeMatchesRail(t)&&(!pk.length||pk.indexOf(t.traderId)>=0))
    .map(t=>{ t.tmin=t.dayIdx*1440+t.execMin; return t; })
    .sort((a,b)=>a.tmin-b.tmin);
  TS_CACHE={sig,rows};
  return rows;
}
const tsLower=(rows,v)=>{ let lo=0,hi=rows.length;
  while(lo<hi){ const m=(lo+hi)>>1; if(rows[m].tmin<v) lo=m+1; else hi=m; } return lo; };

/* A multi-select bound to the chart rather than to the rail: the rail scopes the
   whole page, this picks what belongs on this one plot. */
/* Desk and asset class are scoped by the rail, which governs every pane, so the
   chart does not offer its own list of them — two controls for one filter is a
   question about which one is winning. Trader keeps a picker because choosing the
   handful of names to plot is this chart's own act, not a page-wide scope. */
const TS_PICK_OPTS={
  trader:()=>TRADERS.slice().sort((a,b)=>a.name.localeCompare(b.name))
    .map(t=>[t.id,t.name+" · "+DESK_BY_ID[t.deskId].short]),
};
const TS_PICK_NOUN={trader:"traders"};
const tsHasPick=dim=>!!TS_PICK_OPTS[dim];
function tsPickBtn(dim){
  const sel=state.ts.pick[dim], opts=TS_PICK_OPTS[dim]();
  const lab=!sel.length?"All "+TS_PICK_NOUN[dim]
    :sel.length===1?((opts.find(o=>o[0]===sel[0])||[])[1]||sel[0])
    :sel.length+" "+TS_PICK_NOUN[dim]+" selected";
  return '<label><span>'+esc((TS_DIMS.find(x=>x[0]===dim)||[])[1]||dim)+
    (sel.length?" ("+sel.length+")":"")+'</span>'+
    '<button type="button" class="msel-btn tspick" data-tspick="'+dim+
    '" aria-expanded="false"><span>'+esc(lab)+"</span></button></label>";
}
let tsPickOpen=null;
function closeTsPick(){
  const p=$("#tspick-panel"); if(p) p.remove();
  $$("[data-tspick]").forEach(b=>b.setAttribute("aria-expanded","false"));
  tsPickOpen=null;
}
function openTsPick(btn){
  closeTsPick();
  const dim=btn.dataset.tspick, sel=state.ts.pick[dim];
  const p=document.createElement("div");
  p.id="tspick-panel"; p.className="msel-panel open tspick-panel";
  p.innerHTML=TS_PICK_OPTS[dim]().map(o=>
      '<label class="msel-item"><input type="checkbox" data-tspickv="'+dim+"|"+esc(o[0])+'" '+
      (sel.indexOf(o[0])>=0?"checked":"")+"> "+esc(o[1])+"</label>").join("")+
    '<div class="msel-actions"><button data-tspickall="'+dim+'">Select all</button>'+
    '<button data-tspickclear="'+dim+'">Clear</button></div>';
  document.body.appendChild(p);
  const r=btn.getBoundingClientRect();
  p.style.left=Math.round(Math.min(r.left,window.innerWidth-p.offsetWidth-10))+"px";
  p.style.top=Math.round(Math.min(r.bottom+4,window.innerHeight-p.offsetHeight-10))+"px";
  btn.setAttribute("aria-expanded","true");
  tsPickOpen=dim;
}

/* Whatever pinned the highlight — a dot, a legend swatch, this menu — the menu
   shows it, so the control and the chart never disagree about what is locked. */
function tsPinnedTrader(){
  return hlPinned&&hlPinned.slice(0,7)==="trader|"?hlPinned.slice(7):"";
}
function paneTimeseries(){
  const S=state.ts;
  const enc=tsEncOf();
  const shapeDim=enc.length===1?enc[0]:"ac";
  const colorDim=enc.length===1?enc[0]:enc.find(d=>d!=="ac")||"ac";
  const spanDays=Math.max(1,Math.min(DAYS,Math.round(S.n*TS_UNIT_DAYS[S.unit])));
  const rows=tsRows().filter(t=>t.dayIdx>=DAYS-spanDays);

  const kpis='<div class="kpis">'+
    kpi("Deals in view",fmtNum(rows.length),spanDays+" days, rail-scoped","var(--agent)")+
    kpi("Notional",fmtM(rows.reduce((a,t)=>a+t.notional,0)),"across the window","var(--run)")+
    kpi("Traders",fmtNum(uniq(rows.map(t=>t.traderId)).length),"active in the window","var(--violet)")+
    kpi("Largest ticket",fmtM(Math.max(0,...rows.map(t=>t.notional))),"single deal","var(--warn)")+
    kpi("Outside desk hours",fmtNum(rows.filter(t=>t.execMin<420||t.execMin>=1170).length),
      "deals booked early or late","var(--fail)")+
    kpi("Weekend or holiday",fmtNum(rows.filter(t=>!isBiz(t.date)).length),"deals on a non-business day","var(--gold)")+
    "</div>";

  const strip='<div class="fstrip actstrip">'+
    '<label><span>Colour &amp; shape by</span><div class="segbtns">'+
      TS_DIMS.map(d=>'<button data-tsenc="'+d[0]+'" aria-pressed="'+(enc.indexOf(d[0])>=0)+
        '" data-tip="'+esc(d[1])+'" data-tipsub="'+
        esc(d[0]==="ac"?"Combines with either trader or desk."
           :"Trader and desk are alternatives — picking one clears the other, because a desk is a set of traders.")+
        '">'+d[1]+"</button>").join("")+
    "</div></label>"+
    // One picker per active dimension: choose the dimension, then choose its members.
    enc.filter(tsHasPick).map(tsPickBtn).join("")+
    /* Highlighting is not filtering. This locks one name's deals into the outline
       and leaves every other deal on the chart, because the question it answers is
       "where does this person sit in the floor's activity" — which a filtered chart
       cannot answer at all. */
    '<label><span>Highlight trader\u2019s trades</span><select id="ts-hltrader" class="tshl">'+
      opt("","\u2014 none \u2014",tsPinnedTrader())+
      TRADERS.slice().sort((a,b)=>a.name.localeCompare(b.name))
        .map(t=>opt(t.id,t.name+" · "+DESK_BY_ID[t.deskId].short,tsPinnedTrader())).join("")+
    "</select></label>"+
    tsCaseSelect(rows)+
    '<label><span>Horizon</span><input type="text" id="ts-n" class="wkin" style="width:44px" value="'+esc(String(S.n))+'"></label>'+
    '<label><span>&nbsp;</span><div class="segbtns">'+
      [["day","Days"],["week","Weeks"],["month","Months"]].map(u=>
        '<button data-tsunit="'+u[0]+'" aria-pressed="'+(S.unit===u[0])+'">'+u[1]+"</button>").join("")+
    "</div></label>"+
    '<label><span>Vertical axis</span><div class="segbtns">'+
      [["notional","Notional"],["dev","Off mid"],["tenor","Tenor"],["hour","Time of day"]].map(y=>
        '<button data-tsy="'+y[0]+'" aria-pressed="'+(S.y===y[0])+'">'+y[1]+"</button>").join("")+
    "</div></label>"+
    '<label><span>Zoom</span><div class="segbtns">'+
      '<button data-tszoomstep="-1" data-tip="Zoom out">&minus;</button>'+
      '<button data-tszoomstep="1" data-tip="Zoom in">+</button>'+
      '<button data-tsfit="1" data-tip="Fit the window to the panel">Fit</button>'+
    "</div></label>"+
    '<div class="fspacer"></div><span class="tiny" id="ts-stat">&nbsp;</span></div>';

  const legend='<div class="tslegs" id="ts-legend"></div>';
  const host='<div class="panel-body tsbody" id="ts-host" style="height:'+S.h+'px">'+
      '<svg class="tsaxis" id="ts-axis" aria-hidden="true"></svg>'+
      '<div class="tswrap" id="ts-wrap" tabindex="0">'+
        '<div class="tscanvas" id="ts-canvas"><svg class="tssvg" id="ts-svg"></svg></div>'+
      "</div></div>"+
    // Drag the grip to give the plot more of a large screen.
    '<div class="tsgrip" id="ts-grip" title="Drag to resize" aria-label="Resize chart"></div>';

  return kpis+panel("Trade activity time series",
    "one dot per deal · size = notional · "+
      (enc.length===1
        ? "colour and shape by "+((TS_DIMS.find(x=>x[0]===enc[0])||[])[1]||"").toLowerCase()
        : "shape by asset class, colour by "+((TS_DIMS.find(x=>x[0]===colorDim)||[])[1]||"").toLowerCase()),
    strip+host+legend,
    "<b>Scroll on the chart to zoom</b> — the point under the cursor stays put — and drag the scrollbar to travel. "+
    "Zooming in far enough takes the axis from months down to days, hours, minutes and finally seconds, which is the scale a burst or a layered order is actually read at. "+
    "<b>Drag the grip</b> under the chart to give it more of the screen. "+
    "Weekends and holidays are the narrow shaded columns, drawn at a fifth of a weekday's width so the days that carry the trading get the room — the axis is continuous in time but not linear in it. "+
    "On the time-of-day axis the shaded bands are the hours outside every desk's window. "+
    "<b>Hover a dot</b> for the ticket and to light that trader across the page, <b>double-click</b> to open the deal. "+
    "<b>Highlight trader\u2019s trades</b> locks one name\u2019s deals into the outline and leaves everyone else on the chart. "+
    "<b>Highlight detection cases</b> rings the deals a detection cites \u2014 all of them, by severity, by review status, by typology, or one named case \u2014 with the ring coloured by the severity of the case citing it. "+
    "Neither control filters: seeing where a person or a case sits inside the floor\u2019s activity needs the rest of the floor still visible. "+
    "Ringed deals get first call on the dots the chart can draw, so a named case always appears in full; only a very broad selection over a very wide window is sampled, and the status line above says so when it is. "+
    "To go the other way, open any alert and use <b>Show these deals on the time series</b> \u2014 it widens the horizon to reach the trade date, clears any scoping that would hide them, and scrolls to the deals.");
}

/* ============================================================
   Detection-case highlighting on the time series

   The trader highlight answers "where does this person sit in the floor's
   activity". This answers the other question a reviewer arrives with: "where do
   the cases sit". A case selection rings the deals a detection actually cites,
   coloured by the severity of the case citing them, and leaves every other deal
   on the chart — the point is to see whether the flagged deals cluster in time,
   in size or in the hours they were booked, which a filtered chart hides.

   Specs: "" none · "any" · "sev|Critical" · "st|Escalated" · "rule|TS-01" ·
   "alert|ALT-00001" (set by the Show-on-time-series button in an alert).
============================================================ */
const TS_CASE_KINDS={
  sev:(a,v)=>a.sev===v, st:(a,v)=>a.status===v,
  rule:(a,v)=>a.ruleId===v, alert:(a,v)=>a.id===v,
};
function tsCaseHits(t,spec){
  const as=t.alerts;
  if(!spec||!as||!as.length) return null;
  if(spec==="any") return as;
  const i=spec.indexOf("|");
  const fn=TS_CASE_KINDS[spec.slice(0,i)];
  if(!fn) return null;
  const v=spec.slice(i+1), hit=as.filter(a=>fn(a,v));
  return hit.length?hit:null;
}
// The ring takes the severity of the most serious case citing the deal: one
// deal can be cited by several, and a Critical must not be drawn as a Low.
function tsCaseSev(hits){
  let worst=null;
  for(const a of hits) if(!worst||SEV_RANK[a.sev]>SEV_RANK[worst]) worst=a.sev;
  return worst;
}
/* The picker. Counts are of DEALS in the current horizon, not of alerts, because
   the number the chart is about to draw is the number the reader should see
   before choosing — an option promising 811 critical alerts and then ringing
   2,300 dots would be its own small lie. */
function tsCaseSelect(rows){
  const cur=state.ts.case||"";
  let anyN=0;
  const bySev={},bySt={},byRule={};
  rows.forEach(t=>{
    const as=t.alerts;
    if(!as||!as.length) return;
    anyN++;
    const sevSeen={},stSeen={},ruleSeen={};
    as.forEach(a=>{
      if(!sevSeen[a.sev]){ sevSeen[a.sev]=1; bySev[a.sev]=(bySev[a.sev]||0)+1; }
      if(!stSeen[a.status]){ stSeen[a.status]=1; bySt[a.status]=(bySt[a.status]||0)+1; }
      if(!ruleSeen[a.ruleId]){ ruleSeen[a.ruleId]=1; byRule[a.ruleId]=(byRule[a.ruleId]||0)+1; }
    });
  });
  const o=(v,lab,n)=>opt(v,lab+(n!=null?"  ("+fmtNum(n)+" deals)":""),cur);
  const grp=(lab,inner)=>inner?'<optgroup label="'+esc(lab)+'">'+inner+"</optgroup>":"";
  // A case pinned from an alert is not in any of the standing lists, so it is
  // added explicitly — otherwise the control would sit on "none" while the
  // chart was plainly showing a selection.
  const pinned=cur.slice(0,6)==="alert|"
    ? opt(cur,"Case "+cur.slice(6)+" — pinned from the alert",cur) : "";
  const statuses=["Escalated","Suspicious","In Review","Open","Passed"].filter(s=>bySt[s]);
  const rules=RULES.filter(r=>byRule[r.id]).sort((a,b)=>byRule[b.id]-byRule[a.id]);
  return '<label><span>Highlight detection cases</span><select id="ts-hlcase" class="tshl">'+
    o("","— none —")+pinned+
    o("any","Any detection",anyN)+
    grp("By severity",SEV_ORDER.filter(s=>bySev[s]).map(s=>o("sev|"+s,s,bySev[s])).join(""))+
    grp("By review status",statuses.map(s=>o("st|"+s,s,bySt[s])).join(""))+
    grp("By typology",rules.map(r=>o("rule|"+r.id,r.id+" "+r.name,byRule[r.id])).join(""))+
    "</select></label>";
}
function tsCaseLabel(spec){
  if(!spec) return "";
  if(spec==="any") return "any detection";
  const i=spec.indexOf("|"), k=spec.slice(0,i), v=spec.slice(i+1);
  if(k==="rule") return v+" "+((RULES.find(r=>r.id===v)||{}).name||"");
  if(k==="alert") return "case "+v;
  if(k==="st") return v.toLowerCase()+" cases";
  return v.toLowerCase()+" severity";
}

/* The dark overlay inside a monthly column is the current selection's own count
   for that month, drawn from the zero line so twelve months can be compared
   against a common baseline instead of at whatever height the stack leaves each
   segment. It had no tooltip of its own and had to be guessed at, which is a
   poor showing for the one mark on the chart that answers "did this start here".
   Generated rather than written in, because what it means changes with the
   selection and the bar is redrawn on every highlight. */
TIPGEN.hlshare=el=>{
  if(!hlCurrent) return null;
  const px=+el.getAttribute("data-hl-px")||0;
  if(px<=0) return null;
  const n=Math.round((+el.getAttribute("height")||0)/px);
  const tot=+el.getAttribute("data-hl-mtot")||0;
  const unit=el.getAttribute("data-hl-unit")||"alerts";
  const month=el.getAttribute("data-hl-mlabel")||"";
  const [k,v]=hlCurrent.split("|");
  const who=k==="trader"?(TRADER_BY_ID[v]||{}).name||v
    :k==="desk"?(DESK_BY_ID[v]||{}).name||v
    :k==="rule"?v+" "+((RULE_BY_ID[v]||{}).name||"")
    :k==="hour"?pad2(v)+":00–"+pad2((+v+1)%24)+":00"
    :k==="month"?(MONTH_KEYS[+v]||{}).full||v:v;
  return {title:who+" · "+month,
    sub:fmtNum(n)+" of "+fmtNum(tot)+" "+unit+" that month",
    rows:["Share of the month|"+(tot?(n/tot*100).toFixed(1):"0.0")+"%",
          (HL_NOUN[k]||k)+"|"+who,
          "Reading|"+"the bar is drawn from zero at the column's own scale, so its height is comparable across months"
         ].join("§")};
};

/* Dot tooltips are generated on hover rather than written into every mark.
   Embedding them cost roughly 250 characters per dot — at the cap that is over
   a megabyte of attribute text rebuilt on every scroll frame — so they used to
   be switched off above 3,000 dots, which is below the count the opening view
   draws. Generating on demand costs one lookup and restores the tooltip at
   every zoom level. */
TIPGEN.trade=el=>{
  const t=TRADES_BY_ID[el.getAttribute("data-trade")];
  if(!t) return null;
  const as=t.alerts||[];
  const rows=["Notional|"+fmtM(t.notional),"Instrument|"+t.instrument,
    "Direction|"+t.dir,"Counterparty|"+t.ctpy+" · "+t.ctpyType,
    "Deviation|"+(t.devBps>0?"+":"")+(t.devBps||0).toFixed(1)+" bps",
    "Tenor|"+(t.tenor||"—"),"Channel|"+t.channel,
    "Booking|"+t.status+(t.amends?" · "+t.amends+" amendment"+(t.amends>1?"s":""):"")];
  // A flagged deal says so here, with the case reference, so the dot does not
  // have to be clicked to find out whether it is one of the ones in question.
  if(as.length){
    const worst=as.slice().sort((x,y)=>SEV_RANK[y.sev]-SEV_RANK[x.sev])[0];
    rows.push("Detections|"+as.length+" · "+as.map(a=>a.ruleId).join(", "));
    rows.push("Highest severity|"+worst.sev+" · "+worst.id+" · "+worst.status);
  }
  return {title:t.trader+" · "+t.product,
          sub:fmtDateShort(t.date)+" "+fmtTime(t.execMin)+" · "+t.deskShort+" · "+t.id,
          rows:rows.join("§")};
};

/* The draw. Only the visible slice is built, with a screen of overscan either
   side, because a ten-day window at second resolution is a canvas 2.6 million
   pixels wide and no browser will render an SVG that size. The canvas div carries
   the full width so the scrollbar is honest about how much there is to travel. */
function tsDraw(){
  const host=$("#ts-host"), wrap=$("#ts-wrap"), canvas=$("#ts-canvas"),
        svg=$("#ts-svg"), axis=$("#ts-axis");
  if(!host||!wrap||!svg) return;
  const S=state.ts;
  /* The scale fields are read by the draw, the zoom, the scroll handler and the
     resize grip, so a missing or corrupted one turns every coordinate into NaN and
     the SVG silently refuses the whole slab. Normalise once, here. */
  if(!(S.px>0)) S.px=16;
  if(!(S.h>0)) S.h=470;
  if(!S.pick||!Array.isArray(S.pick.trader)) S.pick={trader:[]};
  const enc=tsEncOf();
  const shapeDim=enc.length===1?enc[0]:"ac";
  const colorDim=enc.length===1?enc[0]:enc.find(d=>d!=="ac")||"ac";

  const spanDays=tsSpanDays();
  S.px=Math.max(TS_PXMIN,Math.min(tsMaxPx(),S.px));   // the horizon may have shrunk since
  const d0=Math.max(0,DAYS-spanDays);
  const t0=d0*1440, t1=DAYS*1440;
  const all=tsRows();
  const iAll0=tsLower(all,t0);

  const padL=58, padT=16, padB=30;
  const pxPerMin=S.px/1440;                 // weekday minutes; weekends run at a fifth of it
  const u0=tsUnitsAt(t0);
  const tsX=tm=>(tsUnitsAt(tm)-u0)*S.px;    // minute to pixel on the piecewise axis
  const tsT=x=>tsMinAt(u0+x/S.px);          // and back
  const totalW=Math.max(1,tsSpanUnits(d0,DAYS)*S.px);
  canvas.style.width=Math.round(totalW)+"px";
  /* A pending centre is consumed before the visible slab is measured, so the
     jump lands in one draw rather than painting the old position first. It is
     then re-applied once on the next frame: arriving from another tab, the
     scroller has not finished laying out, and a clientWidth read that early put
     the target off-centre by half of whatever the width was wrong by. */
  if(tsPendingCenter!=null&&isFinite(tsPendingCenter)){
    const half=(wrap.clientWidth||600)/2;
    wrap.scrollLeft=Math.max(0,Math.min(Math.max(0,totalW-half*2),tsX(tsPendingCenter)-half));
    const again=tsCenterPass>0?tsPendingCenter:null;
    if(again!=null){ tsCenterPass--; requestAnimationFrame(()=>{ tsPendingCenter=again; tsDraw(); }); }
    tsPendingCenter=null;
  }
  /* The plot is sized from the scroller's own content box rather than the panel's,
     and a gutter is reserved whenever the content overflows. Two different things
     were putting the horizontal scrollbar over the date labels: the SVG was drawn
     to the panel height, which is taller than the area the scroller actually shows;
     and where the platform draws overlay scrollbars — as this one does — the bar
     floats above the content and clientHeight reserves nothing for it. A classic
     scrollbar is already excluded from clientHeight, so the manual gutter is only
     added when the measurement comes back zero. */
  const overflowing=totalW>wrap.clientWidth+1;
  const sbH=Math.max(0,wrap.offsetHeight-wrap.clientHeight);
  const gutter=overflowing&&sbH===0?14:0;
  const H=Math.max(200,(wrap.clientHeight||S.h)-gutter), plotH=H-padT-padB;
  canvas.style.height=H+"px";

  const viewW=wrap.clientWidth||600;
  const over=viewW;                                    // one screen of overscan each way
  const left=Math.max(0,wrap.scrollLeft-over);
  const right=Math.min(totalW,wrap.scrollLeft+viewW+over);
  const mFrom=tsT(left), mTo=tsT(right);

  // Colour and shape registries come from the whole window, so a scroll never
  // repaints a category in a different colour.
  const win=all.slice(iAll0,tsLower(all,t1));
  const shapeKeys=uniq(win.map(tsKeyer(shapeDim))).sort();
  const colorKeys=uniq(win.map(tsKeyer(colorDim))).sort();
  const shapeOf={}; shapeKeys.forEach((k,i)=>shapeOf[k]=TS_SHAPES[i%TS_SHAPES.length]);
  const colorOf={};
  if(colorDim==="ac") colorKeys.forEach(k=>colorOf[k]=AC_COLOR[k]||"var(--run)");
  else { const pal=tsPalette(colorKeys.length); colorKeys.forEach((k,i)=>colorOf[k]=pal[i]); }

  let slice=all.slice(tsLower(all,mFrom),tsLower(all,mTo));
  /* Thinned low enough that every drawn dot can afford to be interactive. A
     denser slab was not worth the trade: past this many dots the chart reads as
     a mass anyway, and the old cap left the default view with 5,877 dots that
     could not be hovered at all. */
  const CAP=4500;
  /* A case selection gets first call on the dot budget, but not all of it. A
     named case is a handful of deals and is always drawn in full; a broad
     selection over a wide window can match thousands, and letting it take the
     whole budget left the chart showing nothing but rings — which is a filtered
     chart, exactly what this control is not meant to be. So the ringed deals are
     capped at CASE_MAX and a floor of context dots is always kept, because a
     case only means something read against the flow it sits in. */
  const CTX_MIN=1200, CASE_MAX=CAP-CTX_MIN;
  const caseSpec=S.case||"", caseSev={};
  let caseHits=[];
  if(caseSpec){
    caseHits=slice.filter(t=>{
      const h=tsCaseHits(t,caseSpec);
      if(!h) return false;
      caseSev[t.id]=tsCaseSev(h);
      return true;
    });
  }
  let thinned=false, caseThinned=false;
  if(caseHits.length>CASE_MAX){
    const st=Math.ceil(caseHits.length/CASE_MAX);
    caseHits.forEach((t,i)=>{ if(i%st!==0) delete caseSev[t.id]; });
    caseHits=caseHits.filter((_,i)=>i%st===0);
    caseThinned=true; thinned=true;
  }
  if(slice.length>CAP){
    if(caseHits.length){
      const rest=slice.filter(t=>!caseSev[t.id]);
      const keep=Math.max(CTX_MIN,CAP-caseHits.length);
      const step=Math.max(1,Math.ceil(rest.length/keep));
      const kept=rest.filter((_,i)=>i%step===0);
      thinned=thinned||kept.length<rest.length;
      // Re-sorted into time order: the draw relies on the slice being ordered.
      slice=caseHits.concat(kept).sort((a,b)=>a.tmin-b.tmin);
    }else{
      thinned=true;
      slice=slice.filter((_,i)=>i%Math.ceil(slice.length/CAP)===0);
    }
  }

  const yDefs={
    notional:{lab:"Notional",fmt:v=>fmtM(Math.pow(10,v)),val:t=>Math.log10(Math.max(0.1,t.notional))},
    dev:{lab:"Deviation from mid (bps)",fmt:v=>(v>0?"+":"")+v.toFixed(0),val:t=>t.devBps||0},
    tenor:{lab:"Tenor (years)",fmt:v=>v<1?Math.round(v*12)+"m":v.toFixed(1)+"y",
      val:t=>{const y=tenorYears(t.tenor); return isFinite(y)?y:0;}},
    hour:{lab:"Execution time",fmt:v=>pad2(Math.round(v))+":00",val:t=>t.execMin/60},
  };
  const Y=yDefs[S.y]||yDefs.notional;
  // Scaled on the whole window, never on the visible slice — an axis that
  // rescaled as you scrolled would make two dots at the same height mean
  // different things at different scroll positions.
  let lo=Infinity,hi=-Infinity;
  win.forEach(t=>{const v=Y.val(t); if(v<lo)lo=v; if(v>hi)hi=v;});
  if(!isFinite(lo)){lo=0;hi=1;}
  if(hi-lo<1e-6) hi=lo+1;
  if(S.y==="hour"){ lo=0; hi=24; } else { const pv=(hi-lo)*0.08; lo-=pv; hi+=pv; }
  const yPx=v=>padT+plotH-((v-lo)/(hi-lo))*plotH;
  const nMax=Math.max(1,...win.map(t=>t.notional));
  const rBase=S.px>=600?9.5:S.px>=120?7.4:5.2;
  const rOf=n=>1.7+Math.sqrt(Math.max(0,n)/nMax)*rBase;
  const X=tm=>tsX(tm)-left;                            // local to the drawn slab
  const slabW=Math.max(1,right-left);

  let g="";
  const dFrom=Math.floor(mFrom/1440), dTo=Math.ceil(mTo/1440);
  for(let d=dFrom;d<=dTo;d++){
    if(d<0||d>=DAYS) continue;
    const dt=dateForIdx(d), x=X(d*1440), w=TS_DAYW[d]*S.px;
    if(!isBiz(dt)) g+='<rect x="'+x.toFixed(1)+'" y="'+padT+'" width="'+w.toFixed(1)+'" height="'+plotH+'" fill="var(--fail)" opacity=".05"/>';
    else if(S.y==="hour")
      g+='<rect x="'+x.toFixed(1)+'" y="'+yPx(24).toFixed(1)+'" width="'+w.toFixed(1)+'" height="'+(yPx(19.5)-yPx(24)).toFixed(1)+'" fill="var(--fail)" opacity=".05"/>'+
         '<rect x="'+x.toFixed(1)+'" y="'+yPx(7).toFixed(1)+'" width="'+w.toFixed(1)+'" height="'+(yPx(0)-yPx(7)).toFixed(1)+'" fill="var(--fail)" opacity=".05"/>';
  }
  const TICKS=6;
  for(let i=0;i<=TICKS;i++){
    const y=yPx(lo+(hi-lo)*i/TICKS);
    g+='<line x1="0" y1="'+y.toFixed(1)+'" x2="'+slabW.toFixed(1)+'" y2="'+y.toFixed(1)+'" stroke="var(--hair)" stroke-dasharray="2 3"/>';
  }
  if(S.y==="dev"&&lo<0&&hi>0)
    g+='<line x1="0" y1="'+yPx(0).toFixed(1)+'" x2="'+slabW.toFixed(1)+'" y2="'+yPx(0).toFixed(1)+'" stroke="var(--ink-3)" opacity=".55"/>';

  /* Time ticks. The tier is chosen from the zoom, so the same code labels months
     at one end of the range and seconds at the other. */
  const tier=tsTier(S.px), stepMin=TS_UNIT_MIN[tier.unit]*tier.step;
  const fmtTick=tm=>{
    const d=Math.floor(tm/1440), mins=tm-d*1440, dt=dateForIdx(Math.max(0,Math.min(DAYS-1,d)));
    if(tier.unit==="day") return fmtDateShort(dt);
    if(tier.unit==="hour") return pad2(Math.floor(mins/60))+":00";
    if(tier.unit==="min") return pad2(Math.floor(mins/60))+":"+pad2(Math.floor(mins%60));
    const s=Math.round((mins-Math.floor(mins))*60);
    return pad2(Math.floor(mins/60))+":"+pad2(Math.floor(mins%60))+":"+pad2(s);
  };
  /* Ticks are generated in time but spaced in pixels: inside a compressed weekend
     the axis advances five times more slowly, so a step that reads well on a
     Wednesday would stack four labels on top of each other on a Saturday. */
  let tk=Math.ceil(mFrom/stepMin)*stepMin, guard=0, lastX=-1e9;
  while(tk<=mTo&&guard++<8000){
    const x=X(tk);
    if(x-lastX<TS_LABEL_PX*0.72){ tk+=stepMin; continue; }
    lastX=x;
    g+='<line x1="'+x.toFixed(1)+'" y1="'+padT+'" x2="'+x.toFixed(1)+'" y2="'+(padT+plotH)+'" stroke="var(--hair)" opacity=".6"/>'+
       '<text x="'+x.toFixed(1)+'" y="'+(padT+plotH+14)+'" text-anchor="middle" font-size="'+cf(8.5)+
       '" fill="var(--ink-3)" font-family="var(--mono)">'+esc(fmtTick(tk))+"</text>";
    // A date under the clock, so a reader zoomed to the minute still knows the day.
    if(tier.unit!=="day"&&Math.abs(tk%1440)<stepMin)
      g+='<text x="'+x.toFixed(1)+'" y="'+(padT+plotH+24)+'" text-anchor="middle" font-size="'+cf(7.5)+
         '" fill="var(--ink-3)" opacity=".85">'+esc(fmtDateShort(dateForIdx(Math.floor(tk/1440))))+"</text>";
    tk+=stepMin;
  }

  /* Every dot carries the same short attribute set: the highlight hooks, the deal
     id, and the name of the tooltip generator. Nothing is rationed by dot count
     any more — the long text is built on hover instead of written here. */
  let rings="";
  slice.slice().sort((a,b)=>b.notional-a.notional).forEach(t=>{
    const r=rOf(t.notional), x=X(t.tmin), y=yPx(Y.val(t));
    const extra='data-trade="'+t.id+'" data-tipgen="trade" data-hlsrc="trader|'+t.traderId+
      '" data-hl-trader="'+t.traderId+'" data-hl-desk="'+t.deskId+'" '+hlDim("ac",t.ac)+
      ' style="cursor:pointer"';
    g+=tsMark(shapeOf[tsKeyer(shapeDim)(t)]||"circle",x,y,r,
      colorOf[tsKeyer(colorDim)(t)]||"var(--run)",
      'fill-opacity="'+(r>7?".62":".78")+'" stroke="var(--panel)" stroke-width=".6" '+extra);
    /* Case rings are collected as they go and emitted after the last dot, so a
       ring is never painted over by a larger deal drawn on top of it. */
    if(caseSev[t.id]) rings+='<circle cx="'+x.toFixed(1)+'" cy="'+y.toFixed(1)+'" r="'+(r+3.4).toFixed(1)+
      '" fill="none" stroke="'+SEV_COLOR[caseSev[t.id]]+'" stroke-width="1.8" opacity=".95" pointer-events="none"/>';
  });
  g+=rings;

  if(!slice.length){
    const span=Math.max(1e-6,tsT(wrap.scrollLeft+viewW)-tsT(wrap.scrollLeft));
    g+='<text x="'+((wrap.scrollLeft-left)+viewW/2).toFixed(1)+'" y="'+(padT+plotH/2).toFixed(1)+
      '" text-anchor="middle" font-size="'+cf(11)+'" fill="var(--ink-3)">'+
      esc("No deals in this "+(span<2?Math.round(span*60)+"-second":span<180?Math.round(span)+"-minute":
        Math.round(span/60)+"-hour")+" view \u2014 zoom out or scroll along")+"</text>";
  }
  svg.setAttribute("width",Math.round(slabW));
  svg.setAttribute("height",H);
  svg.setAttribute("viewBox","0 0 "+Math.round(slabW)+" "+H);
  svg.style.left=Math.round(left)+"px";
  svg.innerHTML=g;

  let ax="";
  for(let i=0;i<=TICKS;i++){
    const v=lo+(hi-lo)*i/TICKS;
    ax+='<text x="'+(padL-8)+'" y="'+(yPx(v)+3.5).toFixed(1)+'" text-anchor="end" font-size="'+cf(8.5)+
      '" fill="var(--ink-3)" font-family="var(--mono)">'+esc(Y.fmt(v))+"</text>";
  }
  ax+='<text x="13" y="'+(padT+plotH/2).toFixed(1)+'" transform="rotate(-90 13 '+(padT+plotH/2).toFixed(1)+
    ')" text-anchor="middle" font-size="'+cf(9)+'" fill="var(--ink-2)" font-weight="700">'+esc(Y.lab)+"</text>";
  axis.setAttribute("width",padL); axis.setAttribute("height",H);
  axis.setAttribute("viewBox","0 0 "+padL+" "+H);
  axis.innerHTML=ax;

  const stat=$("#ts-stat");
  if(stat) stat.textContent=fmtNum(win.length)+" deals in window · "+
    ({sec:"seconds",min:"minutes",hour:"hours",day:"days"}[tier.unit])+" resolution"+
    (caseSpec?" · "+fmtNum(caseHits.length)+" ringed for "+tsCaseLabel(caseSpec)+
      (caseThinned?" (sampled — zoom in or narrow the selection to see them all)":""):"")+
    (thinned?" · thinned to keep the view readable":"");

  const leg=$("#ts-legend");
  if(leg){
    const legRow=(dim,keys,render)=>{
      const cap=22, list=keys.slice(0,cap);
      return '<div class="tsleg"><span class="tslegh">'+
        esc((TS_DIMS.find(x=>x[0]===dim)||[])[1]||dim)+"</span>"+list.map(render).join("")+
        (keys.length>cap?'<span class="tslegmore">+'+(keys.length-cap)+" more — narrow the "+
          (tsHasPick(dim)?"picker":"rail")+" to name them</span>":"")+"</div>";
    };
    const swatch=k=>shapeDim===colorDim
      ? '<svg width="13" height="13" viewBox="0 0 13 13">'+tsMark(shapeOf[k]||"circle",6.5,6.5,5,colorOf[k],'fill-opacity=".85"')+"</svg>"
      : '<i style="background:'+colorOf[k]+'"></i>';
    let html=legRow(colorDim,colorKeys,k=>
      '<span class="tslegi" '+hlDim(colorDim==="ac"?"ac":colorDim,k)+' data-hlsrc="'+
        esc(colorDim+"|"+k)+'">'+swatch(k)+esc(tsLabel(colorDim,k))+"</span>");
    if(shapeDim!==colorDim)
      html+=legRow(shapeDim,shapeKeys,k=>'<span class="tslegi" '+hlDim("ac",k)+' data-hlsrc="ac|'+esc(k)+'">'+
        '<svg width="13" height="13" viewBox="0 0 13 13">'+tsMark(shapeOf[k],6.5,6.5,5,"var(--ink-2)","")+"</svg>"+esc(k)+"</span>");
    /* The ring legend names the severity scale and, where a selection is live,
       says how many of the ringed deals sit at each level — the distribution
       matters more than the total when deciding where to look first. */
    if(caseSpec){
      const n={}; caseHits.forEach(t=>{ const s=caseSev[t.id]; n[s]=(n[s]||0)+1; });
      html+='<div class="tsleg"><span class="tslegh">Detection cases</span>'+
        SEV_ORDER.filter(s=>n[s]).map(s=>'<span class="tslegi" data-hlsrc="sev|'+esc(s)+'" '+
          hlDim("sev",s)+'><svg width="15" height="15" viewBox="0 0 15 15">'+
          '<circle cx="7.5" cy="7.5" r="3.2" fill="var(--ink-3)" fill-opacity=".55"/>'+
          '<circle cx="7.5" cy="7.5" r="6" fill="none" stroke="'+SEV_COLOR[s]+'" stroke-width="1.8"/></svg>'+
          esc(s)+" · "+fmtNum(n[s])+"</span>").join("")+
        (caseHits.length?"":'<span class="tslegmore">no deals from this selection fall in the current view — scroll or widen the horizon</span>')+
        "</div>";
    }
    html+='<div class="tsleg"><span class="tslegh">Notional</span>'+
      [nMax*0.05,nMax*0.3,nMax].map(v=>'<span class="tslegi"><svg width="'+(rOf(v)*2+4).toFixed(0)+
        '" height="20" viewBox="0 0 '+(rOf(v)*2+4).toFixed(0)+' 20">'+
        tsMark("circle",rOf(v)+2,10,rOf(v),"var(--ink-3)",'fill-opacity=".55"')+"</svg>"+fmtM(v)+"</span>").join("")+"</div>";
    leg.innerHTML=html;
  }
  hlRefresh();
}
/* Redraws are coalesced to one per frame: a wheel gesture fires dozens of events
   and each one would otherwise rebuild the slab. */
/* Set by the jump-from-a-case action and consumed by the next draw. Declared
   with the chart rather than with the handler so the draw never outruns it. */
let tsPendingCenter=null, tsCenterPass=0;
let tsRAF=null;
function tsSchedule(){ if(tsRAF) return; tsRAF=requestAnimationFrame(()=>{ tsRAF=null; tsDraw(); }); }
function tsZoom(factor,clientX){
  const wrap=$("#ts-wrap"); if(!wrap) return;
  const S=state.ts;
  const r=wrap.getBoundingClientRect();
  const ax=(clientX==null?r.width/2:clientX-r.left);       // anchor within the viewport
  const spanDays=tsSpanDays();
  const u0=tsUnitsAt(Math.max(0,DAYS-spanDays)*1440);
  const before=u0+(wrap.scrollLeft+ax)/S.px;              // day-units under the cursor
  S.px=Math.max(TS_PXMIN,Math.min(tsMaxPx(),S.px*factor));
  tsDraw();
  wrap.scrollLeft=Math.max(0,(before-u0)*S.px-ax);        // hold that instant still
  tsSchedule();
}
function tsFit(){
  const wrap=$("#ts-wrap"); if(!wrap) return;
  const S=state.ts;
  const spanDays=tsSpanDays();
  S.px=Math.max(TS_PXMIN,Math.min(tsMaxPx(),
    (wrap.clientWidth-4)/Math.max(1,tsSpanUnits(Math.max(0,DAYS-spanDays),DAYS))));
  wrap.scrollLeft=0; tsDraw();
}
/* Bound once, delegated, because the pane's nodes are replaced on every render. */
(function tsBind(){
  document.addEventListener("wheel",e=>{
    const w=e.target.closest&&e.target.closest("#ts-wrap");
    if(!w) return;
    e.preventDefault();
    tsZoom(Math.pow(0.998,e.deltaY),e.clientX);
  },{passive:false,capture:true});
  document.addEventListener("scroll",e=>{
    if(e.target&&e.target.id==="ts-wrap") tsSchedule();
  },true);
  window.addEventListener("resize",()=>{ if(state.tab==="timeseries") tsSchedule(); });
  // The grip resizes the plot live; the height is state, so it survives a render.
  let drag=null;
  document.addEventListener("pointerdown",e=>{
    const g=e.target.closest&&e.target.closest("#ts-grip");
    if(!g) return;
    const host=$("#ts-host");
    drag={y:e.clientY,h:host.clientHeight};
    g.setPointerCapture&&g.setPointerCapture(e.pointerId);
    document.body.style.userSelect="none";
    e.preventDefault();
  });
  document.addEventListener("pointermove",e=>{
    if(!drag) return;
    const host=$("#ts-host"); if(!host) return;
    state.ts.h=Math.max(240,Math.min(1400,Math.round(drag.h+(e.clientY-drag.y))));
    host.style.height=state.ts.h+"px";
    tsSchedule();
  });
  document.addEventListener("pointerup",()=>{ if(drag){ drag=null; document.body.style.userSelect=""; tsDraw(); } });
})();
