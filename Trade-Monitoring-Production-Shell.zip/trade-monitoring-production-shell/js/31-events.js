/* ============================================================
   Events
============================================================ */
$("#f-daterange").addEventListener("change",e=>{state.dateRangeDays=+e.target.value;state.det.page=0;render();});
$("#reset-reviews").addEventListener("click",()=>{
  REVIEWS={}; saveLS(REV_KEY,{});
  ALERTS.forEach(a=>{ if(a.mine){ a.mine=false; a.audit=a.audit.filter(x=>!x.mine); } });
  location.reload();
});

/* ============================================================
   Interaction model
   One rule everywhere: a single click on anything the highlight can key on
   LOCKS that selection; clicking it again, or Esc, releases it. A double click
   drills — opens the alert, the ticket, the trader file, or the queue filtered
   to what was clicked. Chrome (tabs, filters, sorting, paging, the decision
   form) always acts on the first click, because a control is not a data point.
============================================================ */
function handleChrome(t,e){
  /* Guarded on its own attribute: the chart's member pickers borrow this class
     for styling, and an unguarded match here swallowed their clicks. */
  const mbtn=t.closest(".msel-btn[data-msel]");
  if(mbtn){ const k=mbtn.dataset.msel; if(openMsel===k) closeMsel(); else buildMsel(k); return true; }
  const mall=t.closest("[data-mselall]"); if(mall){ const k=mall.dataset.mselall; state.filters[k]=new Set(MSEL_OPTS[k]); buildMsel(k); render(); return true; }
  const mclr=t.closest("[data-mselclear]"); if(mclr){ const k=mclr.dataset.mselclear; state.filters[k]=new Set(); buildMsel(k); render(); return true; }
  const tab=t.closest(".tab"); if(tab){ state.tab=tab.dataset.tab; closeMsel(); render(); return true; }
  const msr=t.closest("button[data-measure]"); if(msr){ setMeasure(msr.dataset.measure); return true; }
  const dop=t.closest("[data-detopen]");
  if(dop){ alertDrawer(ALERT_BY_ID[dop.dataset.detopen]); return true; }
  /* A queue row opens its finding underneath itself. Guarded on click count so a
     double click still falls through to the full alert file. */
  const dex=t.closest("[data-detexpand]");
  if(dex&&(e.detail||1)<2&&!t.closest("a")&&!t.closest("button")){
    const id=dex.dataset.detexpand;
    state.det.open=state.det.open===id?"":id;
    render(); return true;
  }
  const ipb=t.closest("[data-infopop]");
  if(ipb){ const k=ipb.getAttribute("data-infopop"); if(infoOpen===k) closeInfo(); else { closeInfo(); openInfo(ipb); } return true; }
  const chip=t.closest("[data-clearchip]"); if(chip){ state.filters[chip.dataset.clearchip]=new Set(); render(); return true; }
  /* The activity grid is a picker as much as a display. Clicking a trader's name
     scopes the whole page to them, exactly as choosing them in the rail's trader
     list does, and clicking it again clears the scope. A pinned highlight goes
     with it: once the page is one person, highlighting that person lights
     everything and says nothing. */
  const rt=t.closest("[data-railtrader]");
  if(rt){
    const id=rt.dataset.railtrader, set=state.filters.trader;
    state.filters.trader=(set.size===1&&set.has(id))?new Set():new Set([id]);
    hlPinned=null; closeMsel(); render();
    window.scrollTo({top:0,behavior:"smooth"});
    return true;
  }
  if(t.closest("[data-clearrule]")){ state.det.rule=""; render(); return true; }
  const rcat=t.closest("[data-rulecat]"); if(rcat){ state.rules.cat=rcat.dataset.rulecat; render(); return true; }
  const lw=t.closest("[data-logwho]"); if(lw){ state.log.who=lw.dataset.logwho; state.log.page=0; render(); return true; }
  const br=t.closest("[data-brange]"); if(br){ const n=+br.dataset.brange;
    state.blot.from=isoDate(dateAt(n-1)); state.blot.to=isoDate(TODAY); state.blot.page=0; render(); return true; }
  const srt=t.closest("[data-sortt]"); if(srt){ toggleSort(srt.dataset.sortt,srt.dataset.sortk); render(); return true; }
  const lpg=t.closest("[data-lpage]");
  if(lpg){ const p=lpg.dataset.lpage.split("|"); if(LPAGE[p[0]]){ LPAGE[p[0]].page=+p[1]; localPagedRedraw(p[0]); } return true; }
  const lst=t.closest("[data-lazystep]"); if(lst){ lazyShow(lst.dataset.lazystep,false); return true; }
  const lal=t.closest("[data-lazyall]"); if(lal){ lazyShow(lal.dataset.lazyall,true); return true; }
  const pg=t.closest("[data-page]"); if(pg){ const p=pg.dataset.page.split("|"); state[p[0]].page=+p[1]; render();
    window.scrollTo({top:document.body.scrollHeight*0.35,behavior:"instant"}); return true; }
  if(t.closest("#d-clear")){ Object.assign(state.det,{rule:"",cat:"",status:"",trader:"",search:"",openOnly:false,page:0}); render(); return true; }
  if(t.closest("#b-clear")){ Object.assign(state.blot,{ac:"",product:"",desk:"",trader:"",dir:"",ctpy:"",flagged:false,search:"",
    from:isoDate(dateAt(29)),to:isoDate(TODAY),page:0}); render(); return true; }
  /* Trader and desk are alternatives, so selecting one clears the other rather
     than producing a pairing that says nothing the desk did not already say.
     Asset class combines with either, and the last dimension cannot be cleared —
     an unencoded scatter is a grey cloud. */
  const te=t.closest("[data-tsenc]");
  if(te){
    const d=te.dataset.tsenc, cur=state.ts.enc.slice(), i=cur.indexOf(d);
    /* A dimension that leaves the encoding takes its member selection with it.
       Leaving the picks behind hid a live filter: the picker disappeared from the
       strip while the deals it excluded stayed excluded. */
    const drop=k=>{ const j=cur.indexOf(k); if(j>=0){ cur.splice(j,1); if(state.ts.pick[k]) state.ts.pick[k]=[]; } };
    if(i>=0){ if(cur.length>1) drop(d); }
    else { if(d==="trader"||d==="desk") drop(d==="trader"?"desk":"trader");
           cur.push(d); }
    state.ts.enc=cur; render(); return true;
  }
  const tu=t.closest("[data-tsunit]"); if(tu){ state.ts.unit=tu.dataset.tsunit; render(); return true; }
  const ty=t.closest("[data-tsy]");    if(ty){ state.ts.y=ty.dataset.tsy; render(); return true; }
  const tzs=t.closest("[data-tszoomstep]");
  if(tzs){ tsZoom(+tzs.dataset.tszoomstep>0?1.6:1/1.6,null); return true; }
  if(t.closest("[data-tsfit]")){ tsFit(); return true; }
  const tpb=t.closest("[data-tspick]");
  if(tpb){ if(tsPickOpen===tpb.dataset.tspick) closeTsPick(); else openTsPick(tpb); return true; }
  if(t.closest("[data-tspickall]")){ const d=t.closest("[data-tspickall]").dataset.tspickall;
    state.ts.pick[d]=TS_PICK_OPTS[d]().map(o=>o[0]); closeTsPick(); render(); return true; }
  if(t.closest("[data-tspickclear]")){ const d=t.closest("[data-tspickclear]").dataset.tspickclear;
    state.ts.pick[d]=[]; closeTsPick(); render(); return true; }
  const am=t.closest("[data-actmetric]"); if(am){ state.act.metric=am.dataset.actmetric; render(); return true; }
  const asc=t.closest("[data-actscale]"); if(asc){ state.act.scale=asc.dataset.actscale; render(); return true; }
  const aun=t.closest("[data-actunit]"); if(aun){ state.act.unit=aun.dataset.actunit; state.act.range=""; render(); return true; }
  const acl=t.closest("[data-actcols]"); if(acl){ state.act.cols=+acl.dataset.actcols; render(); return true; }
  const hrw=t.closest("[data-heatrows]"); if(hrw){ state.heat.rows=hrw.dataset.heatrows; render(); return true; }
  const hcl=t.closest("[data-heatcols]"); if(hcl){ state.heat.cols=hcl.dataset.heatcols; render(); return true; }
  const htp=t.closest("[data-heattop]"); if(htp){ state.heat.top=+htp.dataset.heattop; render(); return true; }
  const hdn=t.closest("[data-heatden]"); if(hdn){ state.heat.density=hdn.dataset.heatden; render(); return true; }
  const ayy=t.closest("[data-actyoy]"); if(ayy){ state.act.yoy=!state.act.yoy; render(); return true; }
  const acta=t.closest("[data-act]");
  if(acta){
    if(acta.dataset.act==="__reset"){ undoDecision(); return true; }
    drawerDraft.action=drawerDraft.action===acta.dataset.act?"":acta.dataset.act;
    drawerDraft.reason="";
    refreshDecide(); return true;
  }
  if(t.closest("#dec-save")){ recordDecision(); return true; }
  if(t.closest("#d-close")||t.id==="scrim"){ closeDrawer(); return true; }
  return false;
}
/* Drilling through to the underlying data. */
function handleDrill(t,e){
  // Anything drilled out of the heatmap carries the heatmap's own window.
  if(t.closest(".matrix")) setRangeDays(365);
  const alertEl=t.closest("[data-alert]"); if(alertEl){ e.preventDefault(); alertDrawer(ALERT_BY_ID[alertEl.dataset.alert]); return true; }
  const tradeEl=t.closest("[data-trade]"); if(tradeEl){ e.preventDefault(); tradeDrawer(TRADES_BY_ID[tradeEl.dataset.trade]); return true; }
  const trEl=t.closest("[data-trader]"); if(trEl){ e.preventDefault(); traderDrawer(TRADER_BY_ID[trEl.dataset.trader]); return true; }
  const tsc=t.closest("[data-tscase]"); if(tsc){ e.preventDefault(); goTimeSeriesCase(tsc.dataset.tscase); return true; }
  const trr=t.closest("[data-trrule]"); if(trr){ closeDrawer(); const p=trr.dataset.trrule.split("|"); goDetections({rule:p[1],trader:p[0]}); return true; }
  const rc=t.closest("[data-ruleclick]"); if(rc){ closeDrawer(); goDetections({rule:rc.dataset.ruleclick}); return true; }
  const sevc=t.closest("[data-sevclick]"); if(sevc){ state.filters.severity=new Set([sevc.dataset.sevclick]); render(); return true; }
  const stc=t.closest("[data-statusclick]"); if(stc){ goDetections({status:stc.dataset.statusclick}); return true; }
  const mb=t.closest("[data-monthbar]"); if(mb){
    const mk=MONTH_KEYS[+mb.dataset.monthbar];
    const days=Math.max(1,Math.round((TODAY-new Date(mk.y,mk.m,1))/dayMs)+1);
    setRangeDays(Math.min(365,days));
    goDetections({}); return true;
  }
  const hc=t.closest("[data-heatcell]");
  if(hc){
    const p=hc.dataset.heatcell.split("|"), H=state.heat;
    closeDrawer();
    setRangeDays(365);   // the cell counts a full year; the queue must too
    if(H.cols==="desk") state.filters.desk=new Set([p[1]]);
    goDetections(H.rows==="rule"?{rule:p[0],trader:H.cols==="trader"?p[1]:""}
                                :{cat:p[0],trader:H.cols==="trader"?p[1]:""});
    return true;
  }
  const dk=t.closest("[data-deskclick]"); if(dk){ state.filters.desk=new Set([dk.dataset.deskclick]); render(); return true; }
  const hr=t.closest("[data-hlsrc]");
  if(hr){
    // A source with no drill target of its own opens the queue scoped to it.
    const sp=hr.getAttribute("data-hlsrc"), i=sp.indexOf("|"), k=sp.slice(0,i), v=sp.slice(i+1);
    if(k==="trader"){ closeDrawer(); goDetections({trader:v}); return true; }
    if(k==="rule"){ closeDrawer(); goDetections({rule:v}); return true; }
    if(k==="cat"){ closeDrawer(); goDetections({cat:v}); return true; }
    if(k==="sev"){ state.filters.severity=new Set([v]); render(); return true; }
    if(k==="status"){ goDetections({status:v}); return true; }
    if(k==="desk"){ state.filters.desk=new Set([v]); render(); return true; }
  }
  return false;
}
/* A single click on a highlight source is held briefly, so a double click can
   cancel it and drill instead of toggling the lock twice on the way through. */
let _clickTimer=null;
document.addEventListener("click",e=>{
  const t=e.target;
  if(handleChrome(t,e)) return;
  const src=t.closest("[data-hlsrc]");
  if(src&&state.highlight){
    e.preventDefault();
    clearTimeout(_clickTimer);
    const spec=src.getAttribute("data-hlsrc");
    _clickTimer=setTimeout(()=>{ hlPin(spec); },200);
    return;
  }
  if(handleDrill(t,e)) return;
  if(openMsel&&!t.closest(".msel-panel")&&!t.closest(".msel-btn")) closeMsel();
  if(infoOpen&&!t.closest("#infopop")&&!t.closest("[data-infopop]")) closeInfo();
  if(tsPickOpen&&!t.closest("#tspick-panel")&&!t.closest("[data-tspick]")) closeTsPick();
});
document.addEventListener("dblclick",e=>{
  clearTimeout(_clickTimer);
  const t=e.target;
  if(handleChrome(t,e)) return;
  handleDrill(t,e);
});

document.addEventListener("change",e=>{
  const t=e.target;
  if(t.id==="hl-toggle"){ state.highlight=t.checked; hlPinned=null; hlApply(null); return; }
  const tv=t.dataset.tspickv;
  if(tv){ const i=tv.indexOf("|"), d=tv.slice(0,i), v=tv.slice(i+1), a=state.ts.pick[d], j=a.indexOf(v);
    if(t.checked){ if(j<0) a.push(v); } else if(j>=0) a.splice(j,1);
    render(); return; }
  const mv=t.dataset.mselv;
  if(mv){ const p=mv.split("|"); const set=state.filters[p[0]];
    if(t.checked) set.add(p[1]); else set.delete(p[1]);
    refreshMselBtn(p[0]); render(); return; }
  const per=t.dataset.per; if(per){ state[per].per=+t.value; state[per].page=0; render(); return; }
  const lper=t.dataset.lper; if(lper&&LPAGE[lper]){ LPAGE[lper].per=+t.value; LPAGE[lper].page=0; localPagedRedraw(lper); return; }
  const map={"d-rule":["det","rule"],"d-cat":["det","cat"],"d-status":["det","status"],"d-trader":["det","trader"],
    "b-ac":["blot","ac"],"b-product":["blot","product"],"b-desk":["blot","desk"],"b-trader":["blot","trader"],
    "b-dir":["blot","dir"],"b-from":["blot","from"],"b-to":["blot","to"],"l-status":["log","status"]};
  if(map[t.id]){ const m=map[t.id]; state[m[0]][m[1]]=t.value; if(m[1]==="ac") state.blot.product=""; state[m[0]].page=0; render(); return; }
  if(t.id==="ts-hltrader"){
    // A highlight control with the master switch off would simply look broken.
    if(!state.highlight){ state.highlight=true; const c=$("#hl-toggle"); if(c) c.checked=true; }
    hlLock(t.value?"trader|"+t.value:null);
    return;
  }
  // Only the chart changes — the option counts are of the horizon, which has not
  // moved — so this redraws rather than re-rendering the pane.
  if(t.id==="ts-hlcase"){ state.ts.case=t.value; tsDraw(); return; }
  if(t.id==="a-range"){ state.act.range=t.value; render(); return; }
  if(t.id==="ts-n"){ state.ts.n=Math.max(1,Math.min(400,parseInt(t.value,10)||1)); render(); return; }
  if(t.id==="a-year"){ state.act.year=+t.value; render(); return; }
  if(t.id==="d-open"){ state.det.openOnly=t.checked; state.det.page=0; render(); return; }
  if(t.id==="b-flagged"){ state.blot.flagged=t.checked; state.blot.page=0; render(); return; }
  if(t.id==="dec-reason"){ drawerDraft.reason=t.value; refreshDecide(); return; }
});

// Text inputs re-render the pane, so focus and caret are restored afterwards.
let _typing=null;
function liveInput(id,setter){
  const el=$("#"+id); if(!el) return;
  const pos=el.selectionStart;
  setter(el.value);
  render();
  requestAnimationFrame(()=>{ const n=$("#"+id); if(n){ n.focus(); try{n.selectionStart=n.selectionEnd=pos;}catch(err){} } });
}
document.addEventListener("input",e=>{
  const id=e.target.id;
  if(id==="dec-note"){ drawerDraft.note=e.target.value; return; }
  const live={"a-range":v=>{ state.act.range=v; },
              "d-search":v=>{state.det.search=v;state.det.page=0;},
              "b-search":v=>{state.blot.search=v;state.blot.page=0;},
              "b-ctpy":v=>{state.blot.ctpy=v;state.blot.page=0;},
              "l-search":v=>{state.log.search=v;state.log.page=0;}};
  if(live[id]){ clearTimeout(_typing); _typing=setTimeout(()=>liveInput(id,live[id]),160); }
});
document.addEventListener("keydown",e=>{ if(e.key==="Escape"){ if(hlPinned){ hlPinned=null; hlApply(null); } closeDrawer(); closeMsel(); closeInfo(); closeTsPick(); } });
