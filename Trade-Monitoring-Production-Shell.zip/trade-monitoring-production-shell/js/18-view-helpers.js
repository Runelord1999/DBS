/* ============================================================
   Shared view helpers
============================================================ */
function kpi(eyebrow,value,sub,accent){
  return '<div class="kpi" style="--accent:'+(accent||"var(--agent)")+'"><div class="eyebrow">'+esc(eyebrow)+
    '</div><b class="num">'+esc(value)+"</b><small>"+esc(sub)+"</small></div>";
}