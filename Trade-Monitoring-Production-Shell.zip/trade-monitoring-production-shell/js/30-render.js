/* ============================================================
   Render
============================================================ */
const PANES={overview:paneOverview,activity:paneActivity,timeseries:paneTimeseries,detections:paneDetections,rules:paneRules,blotter:paneBlotter,traders:paneTraders,log:paneLog};
function render(){
  // Before anything reads them: the trader scores are cut to the rail, and the
  // rail may have moved since the last render.
  buildTraderStats();
  renderRail(); renderChips();
  $("#pane").innerHTML=PANES[state.tab]();
  $$(".tab").forEach(t=>t.setAttribute("aria-selected",String(t.dataset.tab===state.tab)));
  syncMeasureBtns();
  closeInfo();
  Object.keys(MSEL_OPTS).forEach(refreshMselBtn);
  // The pane is rebuilt from scratch, so a pinned selection has to be
  // re-attached to the new nodes and its aggregate cache re-cut to the rail.
  hlRefresh();
  if(state.tab==="timeseries") tsDraw();
}
/* One place to move the review period. A drill that widens the window and leaves
   the rail's select behind makes the sidebar lie about what the numbers cover, so
   the state snaps to an offered value and the control follows it. */
const RANGE_OPTS=[1,7,30,90,182,365];
function setRangeDays(n){
  state.dateRangeDays=RANGE_OPTS.reduce((p,c)=>Math.abs(c-n)<Math.abs(p-n)?c:p,365);
  const el=$("#f-daterange"); if(el) el.value=state.dateRangeDays;
}
function goDetections(patch){
  Object.assign(state.det,{rule:"",cat:"",status:"",trader:"",search:"",openOnly:false,page:0,open:""},patch||{});
  state.tab="detections";
  render();
  window.scrollTo({top:0,behavior:"smooth"});
}

/* Jump from a case to the deals it cites, on the time series. Three things have
   to be true before the chart can show them, and all three are fixed here rather
   than left for the reader to work out from an empty plot: the horizon has to
   reach back to the trade date, the chart's own trader pick has to be off, and
   the rail must not be scoped somewhere that excludes the deals. */
function goTimeSeriesCase(alertId){
  const a=ALERT_BY_ID[alertId]; if(!a) return;
  const cited=a.tradeIds.map(id=>TRADES_BY_ID[id]).filter(Boolean);
  if(!cited.length) return;
  state.ts.case="alert|"+a.id;
  state.ts.pick={trader:[]};
  if(!cited.some(tradeMatchesRail)){
    state.filters.trader=new Set(); state.filters.desk=new Set(); state.filters.assetClass=new Set();
    TS_CACHE={sig:null,rows:[]};
  }
  // Horizon back far enough to include the oldest cited deal, with a day of slack.
  const oldest=Math.min(...cited.map(t=>t.dayIdx));
  const need=DAYS-oldest+1;
  const per=TS_UNIT_DAYS[state.ts.unit]||1;
  state.ts.n=Math.max(state.ts.n,Math.min(400,Math.ceil(need/per)));
  tsPendingCenter=cited.reduce((m,t)=>Math.min(m,t.dayIdx*1440+t.execMin),Infinity);
  tsCenterPass=1;
  closeDrawer();
  state.tab="timeseries";
  render();
  window.scrollTo({top:0,behavior:"smooth"});
}
