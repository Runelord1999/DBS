/* ============================================================
   Pane — Detections queue
============================================================ */
function detFiltered(){
  const d=state.det;
  const q=d.search.trim().toLowerCase();
  return scopedAlerts().filter(a=>{
    if(d.rule&&a.ruleId!==d.rule) return false;
    if(d.cat&&a.cat!==d.cat) return false;
    if(d.status&&a.status!==d.status) return false;
    if(d.trader&&a.traderId!==d.trader) return false;
    if(d.openOnly&&!isOpen(a)) return false;
    if(q){
      const hay=(a.id+" "+a.rule+" "+a.trader+" "+a.deskName+" "+a.summary+" "+a.products.join(" ")+" "+a.tradeIds.join(" ")).toLowerCase();
      if(hay.indexOf(q)<0) return false;
    }
    return true;
  });
}
function paneDetections(){
  const d=state.det;
  let rows=detFiltered();
  rows=sortRows(rows,"det",{
    day:a=>a.day, sev:a=>SEV_RANK[a.sev], score:a=>a.score, notional:a=>a.notional,
    rule:a=>a.ruleId, trader:a=>a.trader, desk:a=>a.deskShort, status:a=>STATUSES.indexOf(a.status), age:a=>ageOf(a),
  });
  const total=rows.length, pages=Math.max(1,Math.ceil(total/d.per));
  d.page=Math.min(d.page,pages-1);
  const page=rows.slice(d.page*d.per,(d.page+1)*d.per);

  const strip='<div class="fstrip">'+
    '<label><span>Rule</span><select id="d-rule">'+opt("","All rules ("+RULES.length+")",d.rule)+
      RULES.map(r=>opt(r.id,r.id+" · "+r.name,d.rule)).join("")+"</select></label>"+
    '<label><span>Category</span><select id="d-cat">'+opt("","All categories",d.cat)+RULE_CATS.map(c=>opt(c,c,d.cat)).join("")+"</select></label>"+
    '<label><span>Status</span><select id="d-status">'+opt("","All statuses",d.status)+STATUSES.map(s=>opt(s,s,d.status)).join("")+"</select></label>"+
    '<label><span>Trader</span><select id="d-trader">'+opt("","All traders",d.trader)+
      TRADERS.slice().sort((a,b)=>a.name.localeCompare(b.name)).map(t=>opt(t.id,t.name+" · "+DESK_BY_ID[t.deskId].short,d.trader)).join("")+"</select></label>"+
    '<label class="grow"><span>Search</span><input type="text" id="d-search" placeholder="alert id, trade id, trader, summary…" value="'+esc(d.search)+'"></label>'+
    '<label class="chk"><input type="checkbox" id="d-open" '+(d.openOnly?"checked":"")+'> Open items only</label>'+
    (d.rule||d.cat||d.status||d.trader||d.search||d.openOnly?'<button class="btn-ghost" id="d-clear">Clear</button>':"")+
    "</div>";

  const table=total?'<div class="table-wrap"><table><thead><tr>'+
    sortTh("det","day","Alert / raised")+sortTh("det","rule","Rule")+sortTh("det","sev","Severity")+
    sortTh("det","score","Score","r")+sortTh("det","trader","Trader")+sortTh("det","desk","Group")+
    "<th>Pattern observed</th>"+sortTh("det","notional","Notional","r")+sortTh("det","age","Age","r")+sortTh("det","status","Status")+
    "</tr></thead><tbody>"+page.map(a=>{
      const age=ageOf(a), breach=isOpen(a)&&SEV_RANK[a.sev]>=3&&age>3;
      const isOpenRow=state.det.open===a.id;
      /* Deliberately outside the highlight system — no source, no member. This is
         a worklist read top to bottom, and re-scoping the page on every row the
         cursor crosses, dimming the twenty-four rows either side of it, fought
         the one thing the queue is for. The rail already filters it, so the
         dimming was largely redundant on top. */
      return '<tr class="clickable'+(isOpenRow?" rowopen":"")+" "+(a.sev==="Critical"?"sev-crit":a.sev==="High"?"sev-high":"")+'" data-alert="'+a.id+
        '" data-detexpand="'+a.id+'">'+
        '<td class="mono">'+a.id+'<div class="sub2">'+fmtDateShort(a.date)+" "+a.date.getFullYear()+"</div></td>"+
        "<td><b>"+a.ruleId+'</b><div class="sub2">'+esc(a.rule)+"</div></td>"+
        "<td>"+sevTag(a.sev)+"</td>"+
        '<td class="r">'+scoreCell(a.score)+"</td>"+
        "<td>"+esc(a.trader)+'<div class="sub2">'+esc(a.tradeIds.length)+" deal"+(a.tradeIds.length>1?"s":"")+
          " · idx "+TRADER_STATS[a.traderId].idx.toFixed(1)+"</div></td>"+
        "<td>"+esc(a.deskShort)+'<div class="sub2">'+esc(a.region)+"</div></td>"+
        '<td style="white-space:normal;max-width:30em">'+esc(a.summary)+"</td>"+
        '<td class="r mono">'+fmtM(a.notional)+"</td>"+
        '<td class="r mono'+(breach?" failc":"")+'">'+age+"d"+(breach?'<div class="sub2 failc">SLA breach</div>':"")+"</td>"+
        "<td>"+statusTag(a.status)+(a.mine?'<div class="sub2">by you</div>':a.reviewer?'<div class="sub2">'+esc(a.reviewer.split(" (")[0])+"</div>":"")+
        '<div class="sub2 expandhint">'+(isOpenRow?"hide finding":"show finding")+"</div></td></tr>"+
        /* The finding opens underneath the row it belongs to, so the pattern, the
           market it was struck into and the deals behind it are read in the queue
           without losing your place in it. */
        (isOpenRow?'<tr class="detrow"><td colspan="10"><div class="detbody">'+alertFindingHTML(a)+
          '<div class="detfoot"><button class="btn-ghost" data-detopen="'+a.id+'">Open the full alert file</button>'+
          '<span class="tiny">Disposition is recorded in the alert file.</span></div></div></td></tr>':"");
    }).join("")+"</tbody></table></div>"+pager("det",total)
    :'<div class="empty">No alerts match these filters. Widen the review period in the sidebar, or clear the filters above.</div>';

  return panel("Detection queue",
    fmtNum(total)+" alert"+(total===1?"":"s")+" · last "+state.dateRangeDays+" days"+(railActive()?" · rail filters applied":""),
    strip+table,
    "Every row is a rule hit on real bookings in the blotter. <b>Click a row</b> to open the finding underneath it — the pattern, the market it was struck into, and the deals behind it. <b>Double-click</b> for the full alert file, where a disposition is recorded: pass it as explained, tag it suspicious, or escalate it to Investigations.");
}
