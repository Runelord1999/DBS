/* ============================================================
   Formatters + calendar
============================================================ */
const dayMs=86400000;
const TODAY=new Date(2026,7,3);                  // fixed "today" so the book reads consistently
const DAYS=365;                                  // one year of daily trading
const dateAt=off=>new Date(TODAY.getTime()-off*dayMs);            // off: 0 = today
const dateForIdx=i=>new Date(TODAY.getTime()-(DAYS-1-i)*dayMs);   // i: 0 = one year ago
const MONTHS=["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
const pad2=n=>String(n).padStart(2,"0");
const fmtDate=d=>pad2(d.getDate())+" "+MONTHS[d.getMonth()]+" "+d.getFullYear();
const fmtDateShort=d=>pad2(d.getDate())+" "+MONTHS[d.getMonth()];
const isoDate=d=>d.getFullYear()+"-"+pad2(d.getMonth()+1)+"-"+pad2(d.getDate());
const fmtTime=m=>pad2(Math.floor(m/60))+":"+pad2(Math.round(m)%60);
const fmtM=v=>{ // v in $M
  if(Math.abs(v)>=1000) return "$"+(v/1000).toFixed(2)+"bn";
  if(Math.abs(v)>=10) return "$"+Math.round(v).toLocaleString()+"m";
  return "$"+v.toFixed(1)+"m";
};
const fmtK=v=>{ // v in $k
  const a=Math.abs(v);
  if(a>=1000) return (v<0?"-":"")+"$"+(a/1000).toFixed(a>=10000?0:1)+"m";
  return (v<0?"-":"")+"$"+Math.round(a).toLocaleString()+"k";
};
const fmtPct=(v,d=1)=>(v*100).toFixed(d)+"%";
const fmtNum=(v,d=0)=>v.toLocaleString(undefined,{minimumFractionDigits:d,maximumFractionDigits:d});
const isWeekend=d=>d.getDay()===0||d.getDay()===6;
// A handful of regional holidays, so "booked on a non-business day" has real teeth.
const HOLIDAYS=new Set(["2025-08-09","2025-12-25","2025-12-26","2026-01-01","2026-01-02","2026-02-17","2026-04-03","2026-05-01","2026-06-19"]);
const isHoliday=d=>HOLIDAYS.has(isoDate(d));
const isBiz=d=>!isWeekend(d)&&!isHoliday(d);
