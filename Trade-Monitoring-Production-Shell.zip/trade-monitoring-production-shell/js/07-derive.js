/* ============================================================
   Derived indices
   In the demo these were computed as the file loaded, because the data was
   already there. Here the data arrives later, so the same work is wrapped in
   buildDerived() and the adapter calls it once the payload is hydrated.
============================================================ */
const TRADER_STATS={}, RULE_STATS={};

// Twelve rolling months ending today — fixed by the calendar, not by the data.
const MONTH_KEYS=[];
(function(){
  for(let i=11;i>=0;i--){ const d=new Date(TODAY.getFullYear(),TODAY.getMonth()-i,1);
    MONTH_KEYS.push({y:d.getFullYear(),m:d.getMonth(),label:MONTHS[d.getMonth()],
      full:MONTHS[d.getMonth()]+" "+String(d.getFullYear()).slice(2)}); }
})();
const monthIdxOf=d=>{ for(let i=0;i<12;i++) if(MONTH_KEYS[i].y===d.getFullYear()&&MONTH_KEYS[i].m===d.getMonth()) return i; return -1; };

/* Baselines: supplied by the warehouse when the bank has AGG_TRADER_BASELINE,
   computed from the delivered book when it does not. Computing them here is a
   fallback for a pilot, not a substitute — a baseline measured over whatever
   history happens to be loaded is only as good as that history. */
function computeBaselines(){
  TRADERS.forEach(t=>{
    if(BASE[t.id]) return;
    const own=TRADES.filter(x=>x.traderId===t.id);
    const byDay={}; own.forEach(x=>{ (byDay[x.dayIdx]=byDay[x.dayIdx]||[]).push(x); });
    const dk=Object.keys(byDay);
    const tickets=dk.map(k=>byDay[k].length);
    const sizes=own.map(x=>x.notional);
    const ctpy={}; own.forEach(x=>{ ctpy[x.ctpy]=(ctpy[x.ctpy]||0)+1; });
    const names=Object.keys(ctpy).sort((a,b)=>ctpy[b]-ctpy[a]);
    BASE[t.id]={deals:own.length,activeDays:dk.length,
      tickets:tickets.length?mean(tickets):0,
      medSize:sizes.length?median(sizes):0,
      ctpyCount:names.length,topCtpy:names[0]||"",
      topCtpyShare:own.length&&names.length?ctpy[names[0]]/own.length:0,
      products:uniq(own.map(x=>x.product)),
      execMean:own.length?mean(own.map(x=>x.execMin)):0,
      amendRate:own.length?own.filter(x=>x.amends>0).length/own.length:0};
  });
}

function buildDerived(){
  // any cached rail signature predates the data
  TRADER_STATS_SIG=null;
  /* The hour the alerting activity was executed, taken from the earliest deal
     on the alert, plus the dimensions the highlight layer brushes on. */
  ALERTS.forEach(a=>{
    let m=null; const ct=[],ch=[],tb=[],sb=[];
    (a.tradeIds||[]).forEach(id=>{
      const t=TRADES_BY_ID[id]; if(!t) return;
      if(m===null||t.execMin<m) m=t.execMin;
      if(ct.indexOf(t.ctpy)<0) ct.push(t.ctpy);
      if(ch.indexOf(t.channel)<0) ch.push(t.channel);
      const b1=tenorBandOf(t.tenor); if(tb.indexOf(b1)<0) tb.push(b1);
      const b2=sizeBandOf(t.notional); if(sb.indexOf(b2)<0) sb.push(b2);
    });
    a.hour=m===null?null:Math.min(23,Math.floor(m/60));
    a.ctpys=ct; a.channels=ch; a.tenorBands=tb; a.sizeBands=sb;
  });

  TRADERS.forEach(t=>TRADER_STATS[t.id]={id:t.id,name:t.name,deskId:t.deskId,cohort:t.cohort,
    trades:0,notional:0,pnl:0,alerts:0,crit:0,susp:0,score:0,rules:{}});
  RULES.forEach(r=>RULE_STATS[r.id]={id:r.id,hits:0,open:0,passed:0,susp:0,notional:0,
    months:Array(12).fill(0),days:Array(DAYS).fill(0)});
  ALERTS.forEach(a=>{
    const s=RULE_STATS[a.ruleId]; if(!s) return;
    s.hits++; s.notional+=a.notional;
    if(a.status==="Open"||a.status==="In Review") s.open++;
    else if(a.status==="Passed") s.passed++; else s.susp++;
    if(a.day>=0&&a.day<DAYS) s.days[a.day]++;
    const mi=monthIdxOf(a.date); if(mi>=0) s.months[mi]++;
  });
  computeBaselines();
}
