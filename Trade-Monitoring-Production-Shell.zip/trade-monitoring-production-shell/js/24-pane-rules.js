/* ============================================================
   Pane — Rule library
============================================================ */
function paneRules(){
  const cats=["",...RULE_CATS];
  const list=RULES.filter(r=>!state.rules.cat||r.cat===state.rules.cat);
  const scoped=allScopedAlerts();
  const cards=list.map(r=>{
    const hits=scoped.filter(a=>a.ruleId===r.id);
    const open=hits.filter(isOpen).length;
    const dec=hits.filter(a=>!isOpen(a));
    const passed=dec.filter(a=>a.status==="Passed").length;
    const months=MONTH_KEYS.map((mk,i)=>hits.filter(a=>monthIdxOf(a.date)===i).length);
    /* Also outside the highlight system. The library is a reference document —
       fifty-eight cards read for their wording — and having fifty-seven of them fade
       out under the cursor made it unreadable as one. */
    return '<div class="rulecard" style="--sevc:'+SEV_COLOR[r.sev]+'" data-ruleclick="'+r.id+'">'+
      '<div class="rhd"><span class="rid">'+r.id+"</span><h4>"+esc(r.name)+"</h4>"+sevTag(r.sev)+"</div>"+
      "<p>"+esc(r.desc)+"</p>"+
      '<div class="logic"><b>Test:</b> '+esc(r.logic)+"</div>"+
      '<div class="rbase"><span class="scope">Per trader</span>'+esc(r.base)+"</div>"+
      (function(){
        const sc=ruleSchema(r.id);
        const rows=Object.keys(sc.bySrc).map(src=>src+"|"+sc.bySrc[src].join(", ")).join("§");
        return '<div class="reqrow"><span class="reqchip" data-tip="'+esc(r.id+" — data required")+
          '" data-tipsub="'+esc(sc.n+" fields from "+sc.systems+" source systems. The rule cannot run without all of them.")+
          '" data-tiptable="'+esc(rows)+'">'+sc.n+" fields · "+sc.systems+" systems</span>"+
          '<span class="reqsrc">'+esc(Object.keys(sc.bySrc).slice(0,2).join(" · ")+
            (sc.systems>2?" +"+(sc.systems-2):""))+"</span></div>";
      })()+
      '<div class="rstats"><span>Hits <b>'+hits.length+"</b></span><span>Open <b"+(open?' class="warnc"':"")+">"+open+"</b></span>"+
      "<span>Upheld <b"+(dec.length-passed?' class="failc"':"")+">"+(dec.length-passed)+"</b></span>"+
      "<span>Explained <b>"+(dec.length?Math.round(passed/dec.length*100):0)+"%</b></span>"+
      '<span style="margin-left:auto">'+spark(months,74,20,SEV_COLOR[r.sev])+"</span></div></div>";
  });
  const filt='<div class="fstrip"><label><span>Category</span><div class="segbtns">'+
    cats.map(c=>'<button data-rulecat="'+esc(c)+'" aria-pressed="'+(state.rules.cat===c)+'">'+(c||"All")+"</button>").join("")+
    "</div></label><div class=\"fspacer\"></div><span class=\"tiny\">"+RULES.length+" rules active · every one evaluated per trader · thresholds shown are the production settings</span></div>";
  return panel("Rule library",RULES.length+" typologies across pricing, conduct, valuation, controls, settlement, financing and information misuse",
    filt+lazyGrid("rules",cards,{cls:"rulegrid",batch:24,noun:"rules",sig:state.rules.cat}),
    "Each card states the exact test the engine applies, <b>what that test is measured against</b>, the historic outcome, and — on the "+
    "<b>fields chip</b> — every data element the rule reads and the system it has to come from. A typology is only as good as its feed: "+
    "half of these are impossible without an execution timestamp to the second, and a third without reference data nobody currently owns. "+
    "Every rule resolves at trader level — against the individual's own authorisation, their own baseline, or their peer cohort — so a small position never disappears into a desk's pooled turnover. "+
    "<b>Click a rule</b> to open its detections. <b>Explained</b> is the share of dispositioned alerts an officer passed — a rule sitting above 70% is a candidate for re-tuning, not a rule that is working.");
}
