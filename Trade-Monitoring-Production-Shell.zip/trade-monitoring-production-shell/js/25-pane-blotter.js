/* ============================================================
   Pane — Trade blotter
   Every deal in the book, filterable the way an officer actually asks the
   question: this product, this desk, this window, show me only what alerted.
============================================================ */
function blotFiltered(){
  const b=state.blot;
  const q=b.search.trim().toLowerCase(), qc=b.ctpy.trim().toLowerCase();
  const from=b.from?new Date(b.from+"T00:00:00").getTime():-Infinity;
  const to=b.to?new Date(b.to+"T23:59:59").getTime():Infinity;
  return TRADES.filter(t=>{
    if(!tradeMatchesRail(t)) return false;
    const ts=t.date.getTime();
    if(ts<from||ts>to) return false;
    if(b.ac&&t.ac!==b.ac) return false;
    if(b.product&&t.product!==b.product) return false;
    if(b.desk&&t.deskId!==b.desk) return false;
    if(b.trader&&t.traderId!==b.trader) return false;
    if(b.dir&&t.dir!==b.dir) return false;
    if(b.flagged&&!t.flags.length) return false;
    if(qc&&t.ctpy.toLowerCase().indexOf(qc)<0) return false;
    if(q){
      const hay=(t.id+" "+t.instrument+" "+t.product+" "+t.trader+" "+t.ctpy+" "+t.book+" "+t.flags.join(" ")).toLowerCase();
      if(hay.indexOf(q)<0) return false;
    }
    return true;
  });
}
const DIRECTIONS=["Buy","Sell","Pay","Receive","Borrow","Lend"];
function paneBlotter(){
  const b=state.blot;
  let rows=blotFiltered();
  const notional=rows.reduce((a,t)=>a+t.notional,0);
  const flagged=rows.filter(t=>t.flags.length).length;
  const traders=new Set(rows.map(t=>t.traderId)).size;
  rows=sortRows(rows,"blot",{
    seq:t=>t.dayIdx*1440+t.execMin, notional:t=>t.notional, px:t=>t.px, dev:t=>Math.abs(t.devBps),
    product:t=>t.product, instrument:t=>t.instrument, trader:t=>t.trader, desk:t=>t.deskShort,
    ctpy:t=>t.ctpy, pnl:t=>t.pnl, flags:t=>t.flags.length, status:t=>t.status, tenor:t=>t.tenor,
  });
  const total=rows.length, pages=Math.max(1,Math.ceil(total/b.per));
  b.page=Math.min(b.page,pages-1);
  const page=rows.slice(b.page*b.per,(b.page+1)*b.per);

  const kpis='<div class="kpis kpis-4">'+
    kpi("Deals in view",fmtNum(total),"of "+fmtNum(TRADES.length)+" booked in 12 months","var(--run)")+
    kpi("Notional in view",fmtM(notional),"aggregate across products","var(--agent)")+
    kpi("Alerted deals",fmtNum(flagged),total?fmtPct(flagged/total,2)+" of the deals in view":"—","var(--fail)")+
    kpi("Traders / groups",traders+" / "+new Set(rows.map(t=>t.deskId)).size,"active in this selection","var(--violet)")+
    "</div>";

  const prodOpts=b.ac?PRODUCTS_BY_AC[b.ac]:PRODUCTS.map(p=>p.p);
  const strip='<div class="fstrip">'+
    '<label><span>From</span><input type="date" id="b-from" value="'+esc(b.from)+'"></label>'+
    '<label><span>To</span><input type="date" id="b-to" value="'+esc(b.to)+'"></label>'+
    '<label><span>Quick range</span><div class="segbtns">'+
      [["7","7d"],["30","30d"],["90","90d"],["365","12m"]].map(r=>'<button data-brange="'+r[0]+'">'+r[1]+"</button>").join("")+"</div></label>"+
    '<label><span>Asset class</span><select id="b-ac">'+opt("","All asset classes",b.ac)+ASSET_CLASSES.map(a=>opt(a,a,b.ac)).join("")+"</select></label>"+
    '<label><span>Product</span><select id="b-product">'+opt("","All products",b.product)+prodOpts.map(p=>opt(p,p,b.product)).join("")+"</select></label>"+
    '<label><span>Desk</span><select id="b-desk">'+opt("","All desks",b.desk)+DESKS.map(d=>opt(d.id,d.name,b.desk)).join("")+"</select></label>"+
    '<label><span>Trader</span><select id="b-trader">'+opt("","All traders",b.trader)+
      TRADERS.slice().sort((x,y)=>x.name.localeCompare(y.name)).map(t=>opt(t.id,t.name,b.trader)).join("")+"</select></label>"+
    '<label><span>Direction</span><select id="b-dir">'+opt("","Any",b.dir)+DIRECTIONS.map(x=>opt(x,x,b.dir)).join("")+"</select></label>"+
    '<label><span>Counterparty</span><input type="text" id="b-ctpy" placeholder="name contains…" value="'+esc(b.ctpy)+'"></label>'+
    '<label class="grow"><span>Search</span><input type="text" id="b-search" placeholder="trade id, instrument, book, rule…" value="'+esc(b.search)+'"></label>'+
    '<label class="chk"><input type="checkbox" id="b-flagged" '+(b.flagged?"checked":"")+"> Alerted deals only</label>"+
    '<button class="btn-ghost" id="b-clear">Reset</button>'+
    "</div>";

  const table=total?'<div class="table-wrap"><table><thead><tr>'+
    sortTh("blot","seq","Trade / date")+sortTh("blot","trader","Trader / group")+sortTh("blot","product","Product")+
    sortTh("blot","instrument","Instrument")+sortTh("blot","tenor","Tenor")+"<th>Dir</th>"+
    sortTh("blot","notional","Notional","r")+sortTh("blot","px","Price","r")+"<th class=\"r\">Market mid</th>"+
    sortTh("blot","dev","Dev","r")+sortTh("blot","ctpy","Counterparty")+"<th>Channel</th>"+
    sortTh("blot","pnl","P&amp;L","r")+sortTh("blot","status","Status")+sortTh("blot","flags","Alerts")+
    "</tr></thead><tbody>"+page.map(t=>{
      const dev=Math.abs(t.devBps);
      const devC=dev>25?"failc":dev>12?"warnc":"muted";
      return '<tr class="clickable" data-trade="'+t.id+'">'+
        '<td class="mono">'+(t.flags.length?'<span class="flagdot"></span>':"")+t.id+'<div class="sub2">'+fmtDateShort(t.date)+" "+fmtTime(t.execMin)+"</div></td>"+
        "<td>"+esc(t.trader)+'<div class="sub2">'+esc(t.deskShort)+"</div></td>"+
        "<td>"+esc(t.product)+'<div class="sub2">'+esc(t.ac)+"</div></td>"+
        "<td>"+esc(t.instrument)+"</td>"+
        '<td class="mono">'+esc(t.tenor)+"</td>"+
        "<td>"+esc(t.dir)+"</td>"+
        '<td class="r mono">'+fmtM(t.notional)+"</td>"+
        '<td class="r mono">'+t.px.toFixed(t.dp)+"</td>"+
        '<td class="r mono muted">'+t.mktPx.toFixed(t.dp)+"</td>"+
        '<td class="r mono '+devC+'">'+(t.devBps>0?"+":"")+t.devBps.toFixed(1)+"</td>"+
        "<td>"+esc(t.ctpy)+'<div class="sub2">'+esc(t.ctpyType)+"</div></td>"+
        '<td class="tiny">'+esc(t.channel)+"</td>"+
        '<td class="r mono '+(t.pnl>=0?"passc":"failc")+'">'+fmtK(t.pnl)+"</td>"+
        "<td>"+'<span class="tag '+(t.status==="Cancelled"?"t-muted":t.status==="Amended"?"t-warn":t.status==="Live"?"t-run":"t-pass")+'">'+t.status+"</span>"+
          (t.amends?'<div class="sub2">'+t.amends+" amend"+(t.amends>1?"s":"")+"</div>":"")+"</td>"+
        "<td>"+(t.flags.length?t.flags.map(f=>'<span class="tag t-fail" style="margin-right:3px">'+f+"</span>").join(""):'<span class="muted">—</span>')+"</td></tr>";
    }).join("")+"</tbody></table></div>"+pager("blot",total)
    :'<div class="empty">No deals match these filters.</div>';

  return kpis+panel("Trade blotter",
    "all products · FX cash, options and derivatives, rates, credit, bonds, repo, futures and equity derivatives",
    strip+table,
    "Prices are shown against the market mid at the moment of execution; <b>Dev</b> is the distance from it in basis points, and is what the "+
    "off-market rules test. A red dot marks a deal that appears in at least one alert — <b>click any row</b> for the full ticket and its linked alerts.");
}
