/* ============================================================
   Pane — Review log
============================================================ */
function logFiltered(){
  const l=state.log, q=l.search.trim().toLowerCase();
  return ALERTS.filter(a=>{
    if(isOpen(a)) return false;
    if(!matchRail(a)) return false;
    if(l.who==="me"&&!(a.mine||a.reviewer===OFFICER)) return false;
    if(l.status&&a.status!==l.status) return false;
    if(q){
      const hay=(a.id+" "+a.rule+" "+a.trader+" "+a.reason+" "+a.note+" "+a.summary).toLowerCase();
      if(hay.indexOf(q)<0) return false;
    }
    return true;
  });
}
function paneLog(){
  const l=state.log;
  let rows=logFiltered();
  const passed=rows.filter(a=>a.status==="Passed").length;
  const susp=rows.filter(a=>a.status==="Suspicious").length;
  const escal=rows.filter(a=>a.status==="Escalated").length;
  const lag=rows.filter(a=>a.reviewDay!=null).map(a=>a.reviewDay-a.day);
  const avgLag=lag.length?lag.reduce((a,b)=>a+b,0)/lag.length:0;

  rows=sortRows(rows,"log",{
    reviewDay:a=>a.reviewDay||a.day, day:a=>a.day, sev:a=>SEV_RANK[a.sev], rule:a=>a.ruleId,
    trader:a=>a.trader, status:a=>STATUSES.indexOf(a.status), notional:a=>a.notional,
  });
  const total=rows.length, pages=Math.max(1,Math.ceil(total/l.per));
  l.page=Math.min(l.page,pages-1);
  const page=rows.slice(l.page*l.per,(l.page+1)*l.per);

  const kpis='<div class="kpis kpis-4">'+
    kpi("Dispositions recorded",fmtNum(total),l.who==="me"?"by you":"whole surveillance team","var(--run)")+
    kpi("Passed as explained",fmtNum(passed),total?fmtPct(passed/total,0)+" of decisions":"—","var(--pass)")+
    kpi("Tagged suspicious",fmtNum(susp),fmtNum(escal)+" further escalated","var(--fail)")+
    kpi("Average time to decide",avgLag.toFixed(1)+" days","target: 3 days for Critical / High","var(--gold)")+
    "</div>";

  // Decisions by month, so the officer can see their own throughput.
  const months=MONTH_KEYS.map((mk,i)=>{
    const inM=rows.filter(a=>a.reviewDay!=null&&monthIdxOf(dateForIdx(a.reviewDay))===i);
    return {label:mk.label,parts:[
      {label:"Passed",v:inM.filter(a=>a.status==="Passed").length,color:"var(--pass)"},
      {label:"Suspicious",v:inM.filter(a=>a.status==="Suspicious").length,color:"var(--fail)"},
      {label:"Escalated",v:inM.filter(a=>a.status==="Escalated").length,color:"var(--violet)"}]};
  });
  // Which reasons the officer leans on — a reason code used everywhere is usually
  // a rule that needs re-tuning rather than a book that needs watching.
  const reasons={};
  rows.forEach(a=>{ if(a.reason) reasons[a.reason]=(reasons[a.reason]||0)+1; });
  const reasonItems=Object.keys(reasons).map(k=>({label:k.length>38?k.slice(0,37)+"…":k,v:reasons[k],
    color:PASS_REASONS.indexOf(k)>=0?"var(--pass)":"var(--fail)"})).sort((a,b)=>b.v-a.v).slice(0,10);

  const charts='<div class="grid2b">'+
    panel("Decisions by month",(l.who==="me"?"your":"team")+" throughput · rolling 12 months",
      '<div class="panel-body"><div class="chart-well">'+stackedBars(months,null,{w:620,h:236})+"</div></div>",
      "Throughput matters as much as outcome: a month where the queue was not worked shows up here first.")+
    panel("Reason codes used","top 10",
      '<div class="panel-body"><div class="chart-well">'+
      (reasonItems.length?hbars(reasonItems,{w:480,rowH:22,labW:230}):'<div class="empty">No decisions recorded yet.</div>')+"</div></div>",
      "Green = passed as explained, red = upheld.")+
    "</div>";

  const strip='<div class="fstrip">'+
    '<label><span>Reviewer</span><div class="segbtns">'+
      [["me","My decisions"],["all","Whole team"]].map(w=>'<button data-logwho="'+w[0]+'" aria-pressed="'+(l.who===w[0])+'">'+w[1]+"</button>").join("")+
      "</div></label>"+
    '<label><span>Outcome</span><select id="l-status">'+opt("","All outcomes",l.status)+
      ["Passed","Suspicious","Escalated"].map(s=>opt(s,s,l.status)).join("")+"</select></label>"+
    '<label class="grow"><span>Search</span><input type="text" id="l-search" placeholder="alert, trader, reason, note…" value="'+esc(l.search)+'"></label>'+
    "</div>";

  const table=total?'<div class="table-wrap"><table><thead><tr>'+
    sortTh("log","reviewDay","Decided")+sortTh("log","day","Alert")+sortTh("log","rule","Rule")+sortTh("log","sev","Sev")+
    sortTh("log","trader","Trader")+"<th>Outcome</th><th>Reason recorded</th><th>Reviewer</th>"+sortTh("log","notional","Notional","r")+
    "</tr></thead><tbody>"+page.map(a=>
      // Same reasoning as the detection queue: a decision log is read as a list.
      '<tr class="clickable" data-alert="'+a.id+'">'+
      '<td class="mono">'+(a.reviewDay!=null?fmtDateShort(dateForIdx(a.reviewDay)):"—")+
        '<div class="sub2">'+(a.reviewDay!=null?(a.reviewDay-a.day)+"d after alert":"")+"</div></td>"+
      '<td class="mono">'+a.id+'<div class="sub2">'+fmtDateShort(a.date)+"</div></td>"+
      "<td><b>"+a.ruleId+'</b><div class="sub2">'+esc(a.rule)+"</div></td>"+
      "<td>"+sevTag(a.sev)+"</td>"+
      "<td>"+esc(a.trader)+'<div class="sub2">'+esc(a.deskShort)+"</div></td>"+
      "<td>"+statusTag(a.status)+"</td>"+
      '<td style="white-space:normal;max-width:26em">'+esc(a.reason||"—")+
        (a.note?'<div class="sub2" style="white-space:normal;color:var(--ink-3)">'+esc(a.note.slice(0,90))+(a.note.length>90?"…":"")+"</div>":"")+"</td>"+
      "<td>"+esc(a.mine?OFFICER:a.reviewer||"—")+"</td>"+
      '<td class="r mono">'+fmtM(a.notional)+"</td></tr>").join("")+"</tbody></table></div>"+pager("log",total)
    :'<div class="empty">No decisions recorded for this selection yet. Work an alert from the Detections queue and it will appear here.</div>';

  return kpis+charts+'<div class="mt14">'+panel("Disposition log",
    fmtNum(total)+" decision"+(total===1?"":"s")+" · "+(l.who==="me"?"recorded by you":"recorded across the team"),
    strip+table,
    "This is the audit record. Every disposition carries the officer, the timestamp, the reason code and the free-text rationale, and stays "+
    "attached to the alert and its underlying deals. <b>Click a row</b> to reopen the alert.")+"</div>";
}
