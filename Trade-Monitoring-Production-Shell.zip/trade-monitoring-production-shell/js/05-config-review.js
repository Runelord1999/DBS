/* ============================================================
   Review workflow — reason codes and decision persistence
   Not demo data: this is the disposition path an officer actually uses.
   Decisions are held in localStorage so the queue survives a reload. Point
   loadLS/saveLS at the case-management service to persist them for real.
============================================================ */
const PASS_REASONS=[
  "Client-authorised order — instruction on file",
  "Documented hedge for an existing position",
  "Market dislocation corroborated by TCA",
  "System or feed latency — data quality issue",
  "Personal mandate exception approved for this trader",
  "Trader explanation verified with the desk head",
  "Duplicate of an existing case",
  "Benign — thin liquidity at the time of execution",
  "Baseline distorted — trader covering a colleague on block leave",
  "Trader's baseline reset after a book transfer this quarter",
];
const SUSP_REASONS=[
  "Unexplained off-market pricing",
  "Pattern consistent with mark manipulation",
  "Concealment of a loss position",
  "Potential personal benefit or undisclosed conflict",
  "Indicators of information misuse",
  "Control circumvention — authorisation defeated",
  "Repeat pattern by the same trader",
  "Sustained departure from the trader's own baseline",
];

/* Officer decisions persist locally and are re-applied over the seed, so the
   queue an officer worked yesterday stays worked after a reload. */
const REV_KEY="ts-dash-reviews-v1";
function loadLS(k,d){ try{const v=localStorage.getItem(k); return v?JSON.parse(v):d;}catch(e){return d;} }
function saveLS(k,v){ try{localStorage.setItem(k,JSON.stringify(v));}catch(e){} }
let REVIEWS=loadLS(REV_KEY,{});
function applyReviews(){
  Object.keys(REVIEWS).forEach(id=>{
    const a=ALERT_BY_ID[id]; if(!a) return;
    const r=REVIEWS[id];
    a.status=r.status; a.reason=r.reason||""; a.note=r.note||"";
    a.reviewer=OFFICER; a.reviewedStr=r.ts; a.reviewDay=DAYS-1; a.mine=true;
    if(!a.audit.some(x=>x.mine)) a.audit.push({ts:r.ts,actor:OFFICER,action:r.action,detail:r.reason||"—",mine:true});
    else a.audit=a.audit.filter(x=>!x.mine).concat([{ts:r.ts,actor:OFFICER,action:r.action,detail:r.reason||"—",mine:true}]);
  });
}
applyReviews();

