/* ============================================================
   Drawer — alert case file and disposition
============================================================ */
let drawerAlert=null, drawerDraft={action:"",reason:"",note:""};
function openDrawer(eyebrow,title,html){
  $("#d-eye").textContent=eyebrow; $("#d-title").textContent=title;
  $("#d-body").innerHTML=html; $("#d-body").scrollTop=0;
  $("#drawer").classList.add("open"); $("#scrim").classList.add("open");
}
function closeDrawer(){ $("#drawer").classList.remove("open"); $("#scrim").classList.remove("open"); drawerAlert=null; }
function toast(msg){
  const el=$("#toast"); el.innerHTML=msg; el.classList.add("on");
  clearTimeout(toast._t); toast._t=setTimeout(()=>el.classList.remove("on"),2600);
}
const ACTIONS=[
  {k:"Passed",   label:"Pass — not suspicious", cls:"pass", reasons:PASS_REASONS,
   hint:"The activity is explained. The alert closes with the rationale attached to the trader's record."},
  {k:"Suspicious",label:"Tag suspicious",        cls:"susp", reasons:SUSP_REASONS,
   hint:"The pattern is upheld. A suspicious transaction report is drafted for Regulatory Reporting."},
  {k:"Escalated", label:"Escalate to Investigations", cls:"esc", reasons:SUSP_REASONS,
   hint:"Beyond surveillance. A case is opened with Financial Crime Investigations and the desk is notified."},
  {k:"In Review", label:"Keep in review",        cls:"rev", reasons:[],
   hint:"Evidence requested from the desk. The alert stays in your queue and keeps ageing."},
];
function decideBlock(a){
  const cur=drawerDraft.action;
  const act=ACTIONS.filter(x=>x.k===cur)[0];
  const decided=!isOpen(a);
  return '<div class="block decide" id="decide-block">'+
    '<div class="lbl">Officer disposition</div>'+
    (decided?'<p class="narr" style="margin-bottom:10px">Currently <b>'+a.status+"</b>"+(a.reason?" — "+esc(a.reason):"")+
      ", recorded by <b>"+esc(a.mine?OFFICER:a.reviewer)+"</b> on "+esc(a.reviewedStr||"—")+
      ". Recording a new decision replaces it and is added to the audit trail.</p>":"")+
    '<div class="decide-row">'+ACTIONS.map(x=>'<button class="dbtn '+x.cls+'" data-act="'+x.k+'" aria-pressed="'+(cur===x.k)+'">'+esc(x.label)+"</button>").join("")+
      (a.mine?'<button class="dbtn" data-act="__reset">Undo my decision</button>':"")+"</div>"+
    (act?'<p class="narr" style="margin:-2px 0 10px;color:var(--ink-3)">'+esc(act.hint)+"</p>":"")+
    '<div class="decide-form">'+
      (act&&act.reasons.length?'<label><span>Reason code</span><select id="dec-reason">'+
        '<option value="">Select a reason…</option>'+act.reasons.map(r=>'<option value="'+esc(r)+'"'+(drawerDraft.reason===r?" selected":"")+">"+esc(r)+"</option>").join("")+
        "</select></label>":"")+
      (act?'<label><span>Reviewer note</span><textarea id="dec-note" placeholder="What did you check, who did you speak to, and what did they say?">'+esc(drawerDraft.note)+"</textarea></label>":"")+
      (act?'<div><button class="btn" id="dec-save" '+(act.reasons.length&&!drawerDraft.reason?"disabled":"")+">Record decision</button>"+
        (act.reasons.length&&!drawerDraft.reason?'<span class="tiny" style="margin-left:10px">Select a reason code to record</span>':"")+"</div>":"")+
    "</div></div>";
}
/* The finding itself — what the engine saw, the market it saw it in, the evidence
   grid and the deals behind it. The queue shows this inline under the row and the
   drawer shows it above the disposition form; there is one copy so the two can
   never drift into telling different stories about the same alert. */
function alertFindingHTML(a){
  const rule=RULE_BY_ID[a.ruleId];
  const tr=TRADER_BY_ID[a.traderId];
  const trades=a.tradeIds.map(id=>TRADES_BY_ID[id]).filter(Boolean);
  /* A revenue rule is argued in revenue, so its deals are listed in it: the
     deal-level P&L column measures a price's deviation from mid, which is the
     wrong quantity for a mark-up the price never shows. Revenue is signed, so
     the loss in a recovery case and the break in a reconciliation case are
     visible on the deal that carries them. */
  const REVR=rule.stream==="revenue";
  const revHead=REVR
    ?'<th class="r" data-tip="Revenue" data-tipsub="Client revenue plus the risk result on the deal">Revenue</th>'+
     '<th class="r" data-tip="Client margin" data-tipsub="Client revenue per million notional — the figure these rules measure">$ per $1m</th>'
    :'<th class="r">P&amp;L</th>';
  const revCell=t=>REVR
    ?'<td class="r mono '+(t.revenue>=0?"passc":"failc")+'">'+fmtK(t.revenue)+'</td>'+
     '<td class="r mono">'+fmtNum(Math.round(t.notional>0?t.clientRevenue*1000/t.notional:0))+"</td>"
    :'<td class="r mono '+(t.pnl>=0?"passc":"failc")+'">'+fmtK(t.pnl)+"</td>";
  return   '<div class="block"><div class="lbl">What the engine observed</div>'+
      '<p class="narr"><b>'+esc(a.summary)+".</b></p>"+
      '<p class="narr" style="margin-top:8px">Test applied: <span class="mono" style="font-size:0.9em">'+esc(rule.logic)+"</span></p>"+
      '<p class="narr" style="margin-top:8px">Measured against: <b>'+esc(rule.base)+"</b> — this rule is evaluated for "+
        esc(tr.name)+" individually, not for "+esc(DESK_BY_ID[tr.deskId].name)+" as a whole.</p>"+
      '<p class="narr" style="margin-top:8px;color:var(--ink-3)">'+esc(rule.why)+"</p>"+
      (function(){
        const sc=ruleSchema(rule.id);
        return '<p class="narr" style="margin-top:8px;font-size:0.6875rem"><span class="reqchip" data-tip="'+
          esc(rule.id+" — data required")+'" data-tipsub="'+esc(sc.n+" fields from "+sc.systems+" source systems")+
          '" data-tiptable="'+esc(Object.keys(sc.bySrc).map(src=>src+"|"+sc.bySrc[src].join(", ")).join("§"))+
          '">Data this test reads · '+sc.n+" fields</span></p>";
      })()+"</div>"+

    marketBlock(trades)+

    '<div class="block"><div class="lbl">Evidence</div><div class="evgrid">'+
      a.evidence.map(e=>'<div class="ek">'+esc(e.k)+'</div><div class="ev'+(e.bad?" bad":"")+'">'+esc(e.v)+"</div>").join("")+
      "</div></div>"+

    '<div class="block"><div class="lbl">Deals in this alert</div><div class="dwrap"><table class="dtable"><thead><tr>'+
      "<th>Trade</th><th>Date / time</th><th>Product</th><th>Instrument</th><th>Dir</th><th class=\"r\">Notional</th>"+
      "<th class=\"r\">Price</th><th class=\"r\">Mid</th><th class=\"r\">Dev bps</th><th>Counterparty</th>"+revHead+"<th>Status</th></tr></thead><tbody>"+
      trades.map(t=>'<tr class="flag"><td class="mono"><a href="#" data-trade="'+t.id+'">'+t.id+"</a></td>"+
        '<td class="mono">'+fmtDateShort(t.date)+" "+fmtTime(t.execMin)+"</td><td>"+esc(t.product)+"</td><td>"+esc(t.instrument)+"</td>"+
        "<td>"+esc(t.dir)+'</td><td class="r mono">'+fmtM(t.notional)+'</td><td class="r mono">'+t.px.toFixed(t.dp)+"</td>"+
        '<td class="r mono muted">'+t.mktPx.toFixed(t.dp)+'</td><td class="r mono '+(Math.abs(t.devBps)>25?"failc":"")+'">'+
        (t.devBps>0?"+":"")+t.devBps.toFixed(1)+"</td><td>"+esc(t.ctpy)+"</td>"+revCell(t)+
        '<td><span class="tag '+(t.status==="Cancelled"?"t-muted":t.status==="Amended"?"t-warn":t.status==="Live"?"t-run":"t-pass")+'">'+t.status+"</span></td></tr>").join("")+
      "</tbody></table></div></div>";
}
function alertDrawer(a){
  drawerAlert=a;
  drawerDraft={action:"",reason:"",note:""};
  const rule=RULE_BY_ID[a.ruleId];
  const tr=TRADER_BY_ID[a.traderId];
  const trades=a.tradeIds.map(id=>TRADES_BY_ID[id]).filter(Boolean);
  const other=ALERTS.filter(x=>x.traderId===a.traderId&&x.id!==a.id);
  const otherByRule={};
  other.forEach(x=>otherByRule[x.ruleId]=(otherByRule[x.ruleId]||0)+1);
  const trMonths=MONTH_KEYS.map((mk,i)=>ALERTS.filter(x=>x.traderId===a.traderId&&monthIdxOf(x.date)===i).length);
  const age=ageOf(a), breach=isOpen(a)&&SEV_RANK[a.sev]>=3&&age>3;

  openDrawer("Alert "+a.id+" · "+rule.cat,rule.id+" — "+rule.name,
    '<div class="dmeta">'+sevTag(a.sev)+statusTag(a.status)+
      '<span class="kv">Score <b>'+a.score+"</b></span>"+
      '<span class="kv">Raised <b>'+esc(a.raisedStr)+"</b></span>"+
      '<span class="kv">Age <b class="'+(breach?"failc":"")+'">'+age+" days"+(breach?" · SLA breach":"")+"</b></span>"+
      '<span class="kv">Notional <b>'+fmtM(a.notional)+"</b></span>"+
      '<span class="kv">Deals <b>'+trades.length+"</b></span></div>"+

    alertFindingHTML(a)+



    '<div class="block"><div class="lbl">Trader context</div>'+
      '<p class="narr"><b>'+esc(tr.name)+"</b> · "+esc(tr.grade)+" · "+esc(DESK_BY_ID[tr.deskId].name)+" · book <span class=\"mono\">"+esc(tr.book)+"</span>"+
      (tr.arc?' · flagged pattern: <b class="failc">'+esc(tr.arc)+"</b>":"")+"</p>"+
      '<div style="display:flex;gap:8px;flex-wrap:wrap;margin:10px 0">'+
        '<span class="kv">Alerts (12m) <b>'+(other.length+1)+"</b></span>"+
        '<span class="kv">Rules triggered <b>'+Object.keys(otherByRule).length+"</b></span>"+
        '<span class="kv">Upheld <b class="failc">'+other.filter(x=>x.status==="Suspicious"||x.status==="Escalated").length+"</b></span>"+
        '<span class="kv">Deals booked <b>'+fmtNum(TRADER_STATS[tr.id].trades)+"</b></span>"+
        '<span class="kv">Risk index <b>'+TRADER_STATS[tr.id].idx.toFixed(1)+"</b></span>"+
        '<span class="kv">Versus cohort <b class="'+(TRADER_STATS[tr.id].cohortN>=PEER_MIN_COHORT&&TRADER_STATS[tr.id].peer>=2?"failc":"")+'">'+peerText(TRADER_STATS[tr.id])+"</b></span>"+
        '<span class="kv">Block leave <b>'+fmtDateShort(dateForIdx(tr.leave[0]))+"–"+fmtDateShort(dateForIdx(tr.leave[1]))+"</b></span></div>"+
      '<div class="lbl" style="margin-top:12px">This trader\'s control profile</div><div class="evgrid">'+
        [["Ticket authorisation",fmtM(tr.ticketLimit)],
         ["Position limit",fmtM(tr.posLimit)],
         ["Maximum tenor",tr.tenorYrs+" years"],
         ["Counterparty concentration cap",fmtPct(tr.ctpyCap,0)],
         ["Approved products",tr.products.join(", ")],
         ["Peer cohort",tr.cohort+" · "+TRADER_STATS[tr.id].cohortN+" traders, median index "+TRADER_STATS[tr.id].cohortMedian.toFixed(1)],
         ["Own median ticket",fmtM(BASE[tr.id].medSize)+" · "+BASE[tr.id].tickets.toFixed(1)+" tickets a day"],
         ["Own counterparty mix",BASE[tr.id].ctpyCount+" names · largest "+BASE[tr.id].topCtpy+" at "+fmtPct(BASE[tr.id].topCtpyShare,0)],
         ["Supervisor",tr.supervisor],
        ].map(r=>'<div class="ek">'+esc(r[0])+'</div><div class="ev">'+esc(r[1])+"</div>").join("")+"</div>"+
      '<div style="display:flex;align-items:center;gap:10px"><span class="tiny">Alerts per month</span>'+spark(trMonths,220,26,"var(--fail)")+"</div>"+
      (Object.keys(otherByRule).length?'<div style="margin-top:10px">'+Object.keys(otherByRule).sort((x,y)=>otherByRule[y]-otherByRule[x]).slice(0,8)
        .map(rid=>'<span class="tag t-muted" style="margin:0 4px 4px 0">'+rid+" ×"+otherByRule[rid]+"</span>").join("")+"</div>":"")+
      '<div style="margin-top:10px;display:flex;gap:8px;flex-wrap:wrap">'+
        '<button class="btn-ghost" data-trader="'+tr.id+'">Open the trader file →</button>'+
        '<button class="btn-ghost" data-tscase="'+a.id+'" data-tip="Rings this case’s deals on the time series and scrolls to them, leaving the rest of the floor’s activity in place for comparison">Show these deals on the time series →</button>'+
      "</div></div>"+

    decideBlock(a)+

    '<div class="block"><div class="lbl">Audit trail</div><ul class="audit">'+
      a.audit.map(x=>'<li><span class="at">'+esc(x.ts)+'</span><span class="aa">'+esc(x.actor)+"</span><span>"+esc(x.action)+
        (x.detail?" — "+esc(x.detail):"")+"</span></li>").join("")+"</ul></div>");
}
function refreshDecide(){
  const el=$("#decide-block");
  if(el&&drawerAlert) el.outerHTML=decideBlock(drawerAlert);
}
function recordDecision(){
  const a=drawerAlert; if(!a||!drawerDraft.action) return;
  const act=ACTIONS.filter(x=>x.k===drawerDraft.action)[0];
  if(act.reasons.length&&!drawerDraft.reason) return;
  const ts=fmtDate(TODAY)+" "+fmtTime(new Date().getHours()*60+new Date().getMinutes());
  REVIEWS[a.id]={status:act.k,reason:drawerDraft.reason,note:drawerDraft.note,ts,
    action:act.k==="Passed"?"Passed — not suspicious":act.k==="Suspicious"?"Tagged suspicious":act.k==="Escalated"?"Escalated to Investigations":"Kept in review"};
  saveLS(REV_KEY,REVIEWS);
  a.status=act.k; a.reason=drawerDraft.reason; a.note=drawerDraft.note; a.reviewer=OFFICER;
  a.reviewedStr=ts; a.reviewDay=DAYS-1; a.mine=true;
  a.audit=a.audit.filter(x=>!x.mine).concat([{ts,actor:OFFICER,action:REVIEWS[a.id].action,detail:drawerDraft.reason||"—",mine:true}]);
  toast("<b>"+a.id+"</b> recorded as "+act.k);
  render(); alertDrawer(a);
}
function undoDecision(){
  const a=drawerAlert; if(!a) return;
  delete REVIEWS[a.id]; saveLS(REV_KEY,REVIEWS);
  a.status="Open"; a.reason=""; a.note=""; a.reviewer=""; a.reviewedStr=""; a.reviewDay=null; a.mine=false;
  a.audit=a.audit.filter(x=>!x.mine);
  toast("<b>"+a.id+"</b> returned to the open queue");
  render(); alertDrawer(a);
}

/* ---- Trade ticket ---- */
function tradeDrawer(t){
  const linked=t.alerts;
  const related=RELATED_PARTIES[t.ctpy];
  const rows=[
    ["Trade id",t.id],["Trade date",t.dateStr],["Execution time",fmtTime(t.execMin)+" "+t.region],
    ["Captured in risk",t.captureLag+" min after execution"],["Value date",fmtDate(t.valueDate)],
    ["Desk",t.deskName],["Trader",t.trader],["Book",t.book],
    ["Product",t.product],["Asset class",t.ac],["Instrument",t.instrument+(t.rating?" · "+t.rating:"")],["Tenor",t.tenor],
    ["Direction",t.dir],["Notional",fmtM(t.notional)],
    ["Traded price",t.px.toFixed(t.dp)],["Market mid at execution",t.mktPx.toFixed(t.dp)],
    ["Deviation from mid",(t.devBps>0?"+":"")+t.devBps.toFixed(1)+" bps"],
    t.vol!=null?["Implied volatility",t.vol.toFixed(2)+" vols (surface "+t.mktVol.toFixed(2)+")"]:null,
    ["Counterparty",t.ctpy+" · "+t.ctpyType+" · "+t.ctpyCountry],
    ["Channel",t.channel],["Venue",t.venue],["Booking status",t.status],["Amendments",String(t.amends)],
    ["SSI amended after execution",t.ssiChanged?"Yes":"No"],
    ["P&L",fmtK(t.pnl)],
  ].filter(Boolean);
  openDrawer("Trade ticket · "+t.product,t.id+" — "+t.instrument,
    '<div class="dmeta"><span class="kv">'+esc(t.deskShort)+"</span><span class=\"kv\">"+esc(t.trader)+"</span>"+
      '<span class="kv">'+fmtM(t.notional)+"</span>"+
      (t.flags.length?'<span class="tag t-fail">'+t.flags.length+" alert"+(t.flags.length>1?"s":"")+"</span>":'<span class="tag t-pass">No alerts</span>')+
      (related?'<span class="tag t-fail">Related party</span>':"")+"</div>"+
    (related?'<div class="block"><div class="lbl">Related-party register</div><p class="narr">'+esc(t.ctpy)+" — "+esc(related)+"</p></div>":"")+
    '<div class="block"><div class="lbl">Ticket</div><div class="evgrid">'+
      rows.map(r=>'<div class="ek">'+esc(r[0])+'</div><div class="ev">'+esc(r[1])+"</div>").join("")+"</div></div>"+
    marketBlock([t],"This deal against the market")+
    (linked.length?'<div class="block"><div class="lbl">Alerts referencing this deal</div><div class="dwrap"><table class="dtable"><thead><tr>'+
      "<th>Alert</th><th>Rule</th><th>Severity</th><th>Raised</th><th>Status</th><th>Pattern</th></tr></thead><tbody>"+
      linked.map(a=>'<tr><td class="mono"><a href="#" data-alert="'+a.id+'">'+a.id+"</a></td><td>"+a.ruleId+" "+esc(a.rule)+"</td>"+
        "<td>"+sevTag(a.sev)+'</td><td class="mono">'+esc(a.dateStr)+"</td><td>"+statusTag(a.status)+"</td>"+
        '<td style="white-space:normal">'+esc(a.summary)+"</td></tr>").join("")+"</tbody></table></div></div>"
      :'<div class="block"><div class="lbl">Alerts referencing this deal</div><p class="narr">None. This deal passed all '+RULES.length+' detection rules.</p></div>')+
    '<div class="block"><div class="lbl">Same trader, same day</div><div class="dwrap"><table class="dtable"><thead><tr>'+
      "<th>Trade</th><th>Time</th><th>Product</th><th>Dir</th><th class=\"r\">Notional</th><th class=\"r\">Dev bps</th><th>Counterparty</th></tr></thead><tbody>"+
      (byTraderDay.get(t.traderId+"|"+t.dayIdx)||[]).slice(0,25).sort((a,b)=>a.execMin-b.execMin)
        .map(x=>'<tr'+(x.id===t.id?' class="flag"':"")+'><td class="mono"><a href="#" data-trade="'+x.id+'">'+x.id+'</a></td><td class="mono">'+fmtTime(x.execMin)+"</td>"+
          "<td>"+esc(x.product)+"</td><td>"+esc(x.dir)+'</td><td class="r mono">'+fmtM(x.notional)+
          '</td><td class="r mono '+(Math.abs(x.devBps)>25?"failc":"")+'">'+(x.devBps>0?"+":"")+x.devBps.toFixed(1)+"</td><td>"+esc(x.ctpy)+"</td></tr>").join("")+
      "</tbody></table></div></div>");
}

/* ---- Trader file ---- */
function traderDrawer(tr){
  const s=TRADER_STATS[tr.id];
  const mine=ALERTS.filter(a=>a.traderId===tr.id).sort((a,b)=>b.day-a.day);
  const months=MONTH_KEYS.map((mk,i)=>mine.filter(a=>monthIdxOf(a.date)===i).length);
  const byRule=RULES.map(r=>({r,n:mine.filter(a=>a.ruleId===r.id).length})).filter(x=>x.n>0).sort((a,b)=>b.n-a.n);
  const upheld=mine.filter(a=>a.status==="Suspicious"||a.status==="Escalated");
  openDrawer("Trader file · "+DESK_BY_ID[tr.deskId].name,tr.name,
    '<div class="dmeta"><span class="kv">Grade <b>'+esc(tr.grade)+"</b></span>"+
      '<span class="kv">Book <b>'+esc(tr.book)+"</b></span>"+
      '<span class="kv">Deals <b>'+fmtNum(s.trades)+"</b></span>"+
      '<span class="kv">Notional <b>'+fmtM(s.notional)+"</b></span>"+
      '<span class="kv">P&L <b class="'+(s.pnl>=0?"passc":"failc")+'">'+fmtK(s.pnl)+"</b></span>"+
      '<span class="kv">Risk index <b>'+s.idx.toFixed(1)+"</b></span>"+
      (tr.arc?'<span class="tag t-fail">'+esc(tr.arc)+"</span>":'<span class="tag t-pass">No recurring pattern</span>')+"</div>"+
    '<div class="block"><div class="lbl">Alert history — 12 months</div>'+
      '<div class="chart-well" style="height:150px">'+stackedBars(MONTH_KEYS.map((mk,i)=>({label:mk.label,
        parts:SEV_ORDER.map(sv=>({label:sv,v:mine.filter(a=>a.sev===sv&&monthIdxOf(a.date)===i).length,color:SEV_COLOR[sv]}))})),null,{w:620,h:170})+"</div>"+
      '<div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:6px">'+
        '<span class="kv">Alerts <b>'+mine.length+"</b></span><span class=\"kv\">Critical <b class=\"failc\">"+mine.filter(a=>a.sev==="Critical").length+"</b></span>"+
        '<span class="kv">Open <b class="warnc">'+mine.filter(isOpen).length+"</b></span>"+
        '<span class="kv">Upheld <b class="failc">'+upheld.length+"</b></span>"+
        '<span class="kv">Rules triggered <b>'+byRule.length+" of "+RULES.length+"</b></span>"+
        '<span class="kv">Block leave <b>'+fmtDateShort(dateForIdx(tr.leave[0]))+"–"+fmtDateShort(dateForIdx(tr.leave[1]))+"</b></span></div></div>"+
    (byRule.length?'<div class="block"><div class="lbl">Typologies triggered</div><div class="chart-well" style="height:'+Math.min(240,byRule.length*24+14)+'px">'+
      hbars(byRule.map(x=>({label:x.r.id+" "+x.r.name.slice(0,30),v:x.n,color:SEV_COLOR[x.r.sev],click:'data-ruleclick="'+x.r.id+'"'})),{w:520,rowH:22,labW:220})+
      "</div></div>":"")+
    '<div class="block"><div class="lbl">Alerts</div><div class="dwrap"><table class="dtable"><thead><tr>'+
      "<th>Alert</th><th>Date</th><th>Rule</th><th>Sev</th><th class=\"r\">Notional</th><th>Status</th><th>Pattern</th></tr></thead><tbody>"+
      mine.slice(0,40).map(a=>'<tr><td class="mono"><a href="#" data-alert="'+a.id+'">'+a.id+'</a></td><td class="mono">'+fmtDateShort(a.date)+"</td>"+
        "<td>"+a.ruleId+"</td><td>"+sevTag(a.sev)+'</td><td class="r mono">'+fmtM(a.notional)+"</td><td>"+statusTag(a.status)+"</td>"+
        '<td style="white-space:normal">'+esc(a.summary)+"</td></tr>").join("")+"</tbody></table></div>"+
      (mine.length>40?'<div class="tiny" style="margin-top:8px">Showing the 40 most recent of '+mine.length+" alerts.</div>":"")+"</div>");
}
