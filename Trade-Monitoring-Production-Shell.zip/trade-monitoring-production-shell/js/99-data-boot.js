/* Start-up — loaded last, once render() and every pane exist */
state.blot.from=isoDate(dateAt(29));
state.blot.to=isoDate(TODAY);

(function(){
  if(window.TM_DATA){ tmStart(window.TM_DATA); return; }
  fetch("./data.json")
    .then(r=>{ if(!r.ok) throw new Error("HTTP "+r.status); return r.json(); })
    .then(tmStart)
    .catch(e=>tmFail(
      "No data source was found. Set window.TM_DATA before this script, or serve "+
      "data.json alongside this page from a web server.", e.message));
})();
