/* ============================================================
   Rail, chips and multi-selects
============================================================ */
function renderRail(){
  const open=openAlerts();
  const crit=open.filter(a=>a.sev==="Critical").length;
  const high=open.filter(a=>a.sev==="High").length;
  const med=open.length-crit-high;
  const newToday=ALERTS.filter(a=>a.day>=DAYS-2&&matchRail(a)).length;
  const ages=open.map(ageOf);
  const all=allScopedAlerts().filter(a=>!isOpen(a));
  const passed=all.filter(a=>a.status==="Passed").length;
  const susp=all.filter(a=>a.status==="Suspicious").length;
  const esc2=all.filter(a=>a.status==="Escalated").length;
  $("#rc-crit").textContent=fmtNum(crit);
  $("#rc-high").textContent=fmtNum(high);
  $("#rc-med").textContent=fmtNum(med);
  $("#rc-new").textContent=fmtNum(newToday);
  $("#rc-oldest").textContent=(ages.length?Math.max.apply(null,ages):0)+" days";
  $("#rc-passed").textContent=fmtNum(passed);
  $("#rc-susp").textContent=fmtNum(susp);
  $("#rc-esc").textContent=fmtNum(esc2);
  $("#rc-conv").textContent=all.length?fmtPct((susp+esc2)/all.length,0):"—";
  $("#tabcnt").textContent=fmtNum(open.length);
}
function renderChips(){
  const f=state.filters, out=[];
  Object.keys(f).forEach(k=>{
    if(!f[k].size) return;
    const names=[...f[k]].map(MSEL_LABEL[k]);
    out.push('<span class="filterchip">'+esc(names.length>2?names.length+" "+MSEL_TITLE[k]:names.join(", "))+
      '<button data-clearchip="'+k+'" aria-label="Clear">×</button></span>');
  });
  if(state.det.rule&&state.tab==="detections") out.push('<span class="filterchip">Rule '+state.det.rule+
    '<button data-clearrule="1" aria-label="Clear">×</button></span>');
  $("#chiprow").innerHTML=out.join("");
}
let openMsel=null;
const MSEL_EYEBROW={trader:"Trader",desk:"Desk",assetClass:"Asset class",severity:"Severity"};
function refreshMselBtn(key){
  const btn=$('.msel-btn[data-msel="'+key+'"]'); if(!btn) return;
  const set=state.filters[key];
  // The count sits on the label, so how much of the floor is in view is legible
  // without opening the picker.
  const eb=$('[data-eyebrow="'+key+'"]');
  if(eb) eb.textContent=MSEL_EYEBROW[key]+(set.size?" ("+set.size+")":"");
  btn.querySelector("span").textContent=!set.size?("All "+MSEL_TITLE[key]):
    set.size===1?MSEL_LABEL[key]([...set][0]):set.size+" "+MSEL_TITLE[key]+" selected";
}
function buildMsel(key){
  const panel=$("#msel-panel-shared");
  const set=state.filters[key];
  panel.innerHTML=MSEL_OPTS[key].map(v=>'<label class="msel-item"><input type="checkbox" data-mselv="'+key+"|"+esc(v)+'" '+
    (set.has(v)?"checked":"")+"> "+esc(MSEL_LABEL[key](v))+"</label>").join("")+
    '<div class="msel-actions"><button data-mselall="'+key+'">Select all</button><button data-mselclear="'+key+'">Clear</button></div>';
  panel.classList.add("open");
  const btn=$('.msel-btn[data-msel="'+key+'"]');
  panel.style.top=(btn.getBoundingClientRect().bottom-$(".msel-shared-wrap").getBoundingClientRect().top+4)+"px";
  $$(".msel-btn").forEach(b=>b.setAttribute("aria-expanded",String(b.dataset.msel===key)));
  openMsel=key;
}
function closeMsel(){
  const panel=$("#msel-panel-shared"); if(panel) panel.classList.remove("open");
  $$(".msel-btn").forEach(b=>b.setAttribute("aria-expanded","false"));
  openMsel=null;
}
