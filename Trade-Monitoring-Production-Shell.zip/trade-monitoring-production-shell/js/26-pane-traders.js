/* ============================================================
   Pane — Traders & groups
============================================================ */
function paneTraders(){
  const scoped=allScopedAlerts();
  const rows=TRADERS.filter(traderInRail).filter(t=>rankable(TRADER_STATS[t.id])).map(t=>{
    const s=TRADER_STATS[t.id];
    const mine=scoped.filter(a=>a.traderId===t.id);
    return {t,s,alerts:mine.length,crit:mine.filter(a=>a.sev==="Critical").length,
      susp:mine.filter(a=>a.status==="Suspicious"||a.status==="Escalated").length,
      open:mine.filter(isOpen).length};
  });
  const maxIdx=Math.max(1,...rows.map(r=>r.s.idx));
  const cards=rows.slice().sort((a,b)=>b.s.idx-a.s.idx).map(r=>{
    const c=r.s.idx>maxIdx*0.6?"var(--fail)":r.s.idx>maxIdx*0.3?"var(--warn)":r.s.idx>maxIdx*0.12?"var(--run)":"var(--pass)";
    return '<div class="tcard" style="--accent:'+c+'" data-trader="'+r.t.id+'" data-hlsrc="trader|'+r.t.id+
      '" data-hl-trader="'+r.t.id+'" data-hl-desk="'+r.t.deskId+'" '+hlAgg("trader",r.t.id,r.s.alerts)+">"+
      '<div><div class="tn">'+esc(r.t.name)+'</div><div class="td">'+esc(DESK_BY_ID[r.t.deskId].name)+" · "+esc(r.t.grade)+"</div></div>"+
      '<div class="trow"><span>Risk index</span><b style="color:'+c+'">'+r.s.idx.toFixed(1)+"</b></div>"+
      '<div class="trow"><span>Versus cohort</span><b style="color:'+(r.s.cohortN>=PEER_MIN_COHORT&&r.s.peer>=2?c:"inherit")+'" data-tip="'+esc(peerTip(r.s))+'">'+peerText(r.s)+"</b></div>"+
      '<div class="trow"><span>Alerts / critical</span><b>'+r.alerts+" / "+r.crit+"</b></div>"+
      '<div class="trow"><span>Upheld</span><b class="'+(r.susp?"failc":"")+'">'+r.susp+"</b></div>"+
      '<div class="trow"><span>Ticket limit</span><b>'+fmtM(r.t.ticketLimit)+"</b></div>"+
      '<div class="trow"><span>Deals booked</span><b>'+fmtNum(r.s.trades)+"</b></div>"+
      '<span class="bar-mini" style="width:100%"><i style="width:'+(r.s.idx/maxIdx*100).toFixed(0)+"%;background:"+c+'"></i></span>'+
      (r.t.arc?'<div class="tiny" style="color:'+c+'">Pattern: '+esc(r.t.arc)+"</div>":'<div class="tiny">No recurring pattern</div>')+
      "</div>";
  }).join("");

  const pts=rows.map(r=>({
    id:r.t.id, deskId:r.t.deskId, x:r.s.trades, y:r.alerts, r:Math.max(1,r.susp+1), big:r.s.idx>maxIdx*0.5,
    color:r.s.idx>maxIdx*0.6?"var(--fail)":r.s.idx>maxIdx*0.3?"var(--warn)":"var(--run)",
    label:r.t.name, sub:DESK_BY_ID[r.t.deskId].name,
    tip:["Deals booked|"+fmtNum(r.s.trades),"Alerts|"+r.alerts,"Critical|"+r.crit,"Upheld|"+r.susp,
         "Risk index|"+r.s.idx.toFixed(1),"Versus cohort|"+peerText(r.s),"Cohort|"+r.t.cohort,
         "Rules triggered|"+r.s.ruleCount+" of "+RULES.length].join("§"),
  }));

  // Trader × rule matrix for the names carrying the most alerts.
  const top=rows.slice().sort((a,b)=>b.alerts-a.alerts).slice(0,14);
  let tmMax=0;
  const tmat=top.map(r=>({r,cells:RULES.map(rule=>{
    const n=scoped.filter(a=>a.traderId===r.t.id&&a.ruleId===rule.id).length;
    if(n>tmMax) tmMax=n; return {rule,n};
  })}));

  const rowA='<div class="grid2">'+
    panel("Alerts against volume","bubble size = alerts upheld as suspicious",
      '<div class="panel-body"><div class="chart-well tall">'+bubbleChart(pts,{w:600,h:300})+"</div></div>",
      "A name sitting high and to the left alerts more than its trading volume explains. <b>Hover a bubble</b> to light that trader everywhere, <b>click</b> for the trader file.")+
    panel("Detection heatmap","trader × rule · the Overview matrix transposed · full 12 months",
      '<div class="matwrap tallmat" style="padding-top:2px"><table class="matrix"><thead><tr><th class="rowhd"></th>'+
      RULES.map(r=>'<th class="colhd" data-hlsrc="rule|'+r.id+'" data-hlpin="1" data-tip="'+esc(r.name)+'" data-tipsub="'+esc(r.cat)+
        '"><div>'+r.id+" "+esc(r.name.slice(0,20))+"</div></th>").join("")+"</tr></thead><tbody>"+
      tmat.map(row=>'<tr><th class="rowhd" data-hlsrc="trader|'+row.r.t.id+'" data-hlpin="1">'+esc(row.r.t.name)+"</th>"+
        row.cells.map(c=>'<td><button class="mcell'+(c.n?"":" zero")+'" style="background:'+heatColor(c.n,tmMax)+
          '" '+hlAgg("cell",c.rule.id+"\u0001"+row.r.t.id,c.n)+
          ' data-hl-trader="'+row.r.t.id+'" data-hl-desk="'+row.r.t.deskId+'" data-hl-rule="'+c.rule.id+'" data-hl-cat="'+esc(c.rule.cat)+
          '" data-hl-sev="'+c.rule.sev+'" data-trrule="'+row.r.t.id+"|"+c.rule.id+'" data-tip="'+esc(row.r.t.name)+'" data-tipsub="'+esc(c.rule.id+" · "+c.rule.name)+
          '" data-tiptable="Alerts|'+c.n+'">'+(c.n||"·")+"</button></td>").join("")+"</tr>").join("")+
      "</tbody></table></div>",
      "The same counts as the Detection heatmap on the Overview, read down the other axis: there a rule is a row, here a trader is. "+
      "A row lit across several unrelated rules is the signature worth pulling — one typology can be an accident, four is a method. "+
      "<b>Hover a name or a rule label</b> to carry that selection across the page; <b>click it</b> to pin.")+
    "</div>";

  /* Trader groups. A desk is a reporting line, so the row is a roll-up of the
     people in it — how many of them are running hot, and how the worst one
     looks — never a pooled ratio, which is precisely the number that lets a
     small book hide inside a large one. */
  const HOT=18;   // risk index at which a name is worth a conversation
  const groups=DESKS.filter(d=>!state.filters.desk.size||state.filters.desk.has(d.id)).map(d=>{
    const members=d.traders.filter(traderInRail).map(t=>({t,s:TRADER_STATS[t.id],a:scoped.filter(x=>x.traderId===t.id)}))
      .sort((a,b)=>b.s.idx-a.s.idx);
    const idxs=members.map(m=>m.s.idx);
    return {d,members,hot:members.filter(m=>m.s.idx>=HOT),
      worst:members[0], med:median(idxs),
      alerts:members.reduce((a,m)=>a+m.a.length,0),
      crit:members.reduce((a,m)=>a+m.a.filter(x=>x.sev==="Critical").length,0),
      open:members.reduce((a,m)=>a+m.a.filter(isOpen).length,0),
      susp:members.reduce((a,m)=>a+m.a.filter(x=>x.status==="Suspicious"||x.status==="Escalated").length,0)};
  }).filter(g=>g.members.length).sort((a,b)=>b.worst.s.idx-a.worst.s.idx);
  const gMax=Math.max(1,...groups.map(g=>g.worst.s.idx));

  const tbl=panel("Desks","a desk is a set of people — these are their individual indices rolled up, not a pooled desk figure",
    '<div class="table-wrap"><table><thead><tr><th>Desk</th><th>Region</th><th class="r">Traders</th>'+
    '<th class="r">Above index '+HOT+'</th><th>Highest-index trader</th><th class="r">Group median</th>'+
    '<th class="r">Alerts</th><th class="r">Critical</th><th class="r">Open</th><th class="r">Upheld</th></tr></thead><tbody>'+
    groups.map(g=>{
      const w=g.worst, c=w.s.idx>gMax*0.6?"var(--fail)":w.s.idx>gMax*0.3?"var(--warn)":"var(--run)";
      return '<tr '+hlAgg("desk",g.d.id,g.alerts)+' data-hlsrc="desk|'+g.d.id+'"><td><b class="clickable" data-deskclick="'+g.d.id+'">'+esc(g.d.name)+"</b></td><td>"+esc(g.d.region)+"</td>"+
        '<td class="r mono">'+g.members.length+'</td>'+
        '<td class="r mono'+(g.hot.length?" failc":"")+'">'+g.hot.length+"</td>"+
        '<td><span class="clickable" data-trader="'+w.t.id+'" data-hlsrc="trader|'+w.t.id+'"><b>'+esc(w.t.name)+"</b> "+
          '<span class="mono" style="color:'+c+'">'+w.s.idx.toFixed(1)+"</span> "+
          '<span class="sub2">'+peerText(w.s)+" vs cohort</span></span></td>"+
        '<td class="r mono">'+g.med.toFixed(1)+"</td>"+
        '<td class="r mono">'+g.alerts+'</td><td class="r mono failc">'+g.crit+"</td>"+
        '<td class="r mono warnc">'+g.open+'</td><td class="r mono">'+g.susp+"</td></tr>";
    }).join("")+"</tbody></table></div>",
    "Groups are ordered by their <b>worst individual</b>, not by their total. Two groups with the same alert count are not the same problem: "+
    "one may be twelve people slightly over threshold, the other a single name at eight times their cohort. "+
    "<b>Click a group</b> to scope the dashboard to it, or a name to open the trader file.");

  return rowA+'<div class="mt14">'+panel("Trader risk index",
    "12 months · severity-weighted alerts per 100 of the trader's own deals · "+rows.length+" traders",
    '<div class="tgrid">'+cards+"</div>",
    "The index weights each alert by severity and divides by the trader's own deal count, so it ranks behaviour rather than busyness. "+
    "<b>Versus cohort</b> restates it against the median of the same grade doing the same kind of work — the comparison a desk head asks for first.")+"</div>"+
    '<div class="mt14">'+tbl+"</div>";
}
