/* ============================================================
   Pane — Surveillance overview
============================================================ */
function paneOverview(){
  const scoped=scopedAlerts(), open=openAlerts(), scopedAll=allScopedAlerts();
  const today=ALERTS.filter(a=>a.day===DAYS-1&&matchRail(a));
  const crit=open.filter(a=>a.sev==="Critical");
  const decided=scoped.filter(a=>!isOpen(a));
  const passed=decided.filter(a=>a.status==="Passed");
  const mine=ALERTS.filter(a=>a.mine||a.reviewer===OFFICER);
  const ages=open.map(ageOf).sort((a,b)=>a-b);
  const medAge=ages.length?ages[Math.floor(ages.length/2)]:0;
  const trades12=TRADES.filter(tradeMatchesRail).length;

  const kpis='<div class="kpis">'+
    kpi("Open alerts",fmtNum(open.length),"awaiting disposition","var(--warn)")+
    kpi("Raised today",fmtNum(today.length),fmtDate(TODAY),"var(--run)")+
    kpi("Critical open",fmtNum(crit.length),"target: cleared in 3 days","var(--fail)")+
    kpi("Median age (open)",medAge+"d","oldest "+(ages.length?ages[ages.length-1]:0)+"d","var(--gold)")+
    kpi("Alerts in period",fmtNum(scoped.length),"last "+state.dateRangeDays+" days","var(--agent)")+
    kpi("Pass rate in period",decided.length?fmtPct(passed.length/decided.length,0):"—",fmtNum(passed.length)+" of "+fmtNum(decided.length)+" explained","var(--pass)")+
    kpi("Suspicious / escalated",fmtNum(decided.length-passed.length),"in the last "+state.dateRangeDays+" days","var(--fail)")+
    kpi("Trades screened",fmtNum(trades12),"12 months, all products","var(--violet)")+
    "</div>";

  // Monthly volume, stacked by severity.
  const months=MONTH_KEYS.map((mk,i)=>{
    const inM=scopedAll.filter(a=>monthIdxOf(a.date)===i);
    return {label:mk.label,sub:i===0||mk.m===0?String(mk.y).slice(2):"",
      parts:SEV_ORDER.map(s=>({label:s,v:inM.filter(a=>a.sev===s).length,color:SEV_COLOR[s]}))};
  });
  const sevSegs=SEV_ORDER.map(s=>({label:s,v:scoped.filter(a=>a.sev===s).length,color:SEV_COLOR[s]}));
  const stSegs=STATUSES.map(s=>({label:s,v:scoped.filter(a=>a.status===s).length,color:STATUS_COLOR[s]}));

  // Daily trend across the full year, irrespective of the period selector — a
  // step change three months ago still matters when today's queue looks calm.
  const daily=Array(DAYS).fill(0);
  scopedAll.forEach(a=>daily[a.day]++);

  const sevTot=scoped.length||1, stTot=scoped.length||1;
  sevSegs.forEach(sg=>{ sg.hl='data-hlsrc="sev|'+esc(sg.label)+'" '+hlDim("sev",sg.label); sg.agg=hlAggP("sev",sg.label,sg.v); });
  stSegs.forEach(sg=>{ sg.hl='data-hlsrc="status|'+esc(sg.label)+'" '+hlDim("status",sg.label); sg.agg=hlAggP("status",sg.label,sg.v); });

  const ageItems=AGE_BUCKETS.map(b=>{
    const n=open.filter(a=>ageOf(a)>=b[1]&&ageOf(a)<=b[2]).length;
    return {label:b[0],v:n,color:b[3],agg:hlAgg("age",b[0],n),aggKey:"age|"+b[0]};
  });
  const rowA='<div class="gridw2 tight">'+
    panel("Alert volume by month","by severity · 12 months",
      '<div class="panel-body"><div class="chart-well tall">'+stackedBars(months,null,{w:660,h:266,hlMonth:true})+"</div></div>",
      "One column per calendar month. Hovering a trader or rule anywhere on the page draws their own count inside each column — the month a pattern started shows as a step.")+
    panel("Severity mix","last "+state.dateRangeDays+" days",
      '<div class="panel-body"><div class="chart-well donut-well">'+
      donut(sevSegs,String(scoped.length),"alerts",112,19)+
      donutLegend(sevSegs,scoped.length,s=>'data-sevclick="'+esc(s.label)+'"')+"</div></div>",
      "Critical and High carry a 3-day disposition target.")+
    panel("Disposition","last "+state.dateRangeDays+" days",
      '<div class="panel-body"><div class="chart-well donut-well">'+
      donut(stSegs,decided.length?fmtPct(passed.length/decided.length,0):"—","passed",112,19)+
      donutLegend(stSegs,scoped.length,s=>'data-statusclick="'+esc(s.label)+'"')+"</div></div>",
      "A high pass rate on one rule is a tuning problem; a low one on a trader is not.")+
    "</div>";



  /* Two charts that exist for the linking: a category fingerprint and a
     booking-hour profile. Neither says much on its own — the floor's mix and
     the floor's working day are unremarkable — but under a selection they are
     the two fastest reads in surveillance. Is this name's activity spread
     across unrelated typologies, or concentrated in one? And is it happening
     when anybody is watching? */
  const catRows=RULE_CATS.map(c=>{
    const hits=scopedAll.filter(a=>a.cat===c);
    const n=hits.length, up=hits.filter(a=>a.status==="Suspicious"||a.status==="Escalated").length;
    const dec=hits.filter(a=>!isOpen(a)).length;
    return {label:c,v:n,v2:up,color:"var(--agent)",agg:hlAgg("cat",c,n),aggKey:"cat|"+c,
      tip:c,tipsub:"Rule category",
      tiptable:["Alerts raised|"+fmtNum(n),"Upheld — suspicious or escalated|"+fmtNum(up),
        "Passed as explained|"+fmtNum(dec-up),"Still open|"+fmtNum(n-dec),
        "Upheld rate|"+(dec?Math.round(up/dec*100):0)+"%"].join("§"),
      hl:'data-hlsrc="cat|'+esc(c)+'" data-hl-cat="'+esc(c)+'" data-hlpin="1"'};
  }).sort((a,b)=>b.v-a.v);
  const upheldKey='<div class="trendkey"><span><i class="lk" style="background:var(--agent)"></i>Alerts raised</span>'+
    '<span><i class="lk" style="background:var(--fail)"></i>Upheld — tagged suspicious or escalated</span>'+
    '<span><i class="lk" style="background:var(--ink)"></i>Current highlight selection</span></div>';

  const hourCounts=Array(24).fill(0);
  scopedAll.forEach(a=>{ if(a.hour!=null) hourCounts[a.hour]++; });
  const hourMax=Math.max(1,...hourCounts);

  /* The daily trend is 365 points; at a quarter of the width its axis stops
     being readable, so it takes double. Density is the point, but a chart
     nobody can read is not density. */
  const rowB='<div class="gridw2 tight">'+
    panel("Detection volume — daily","12 months · daily · dark fill = selection",
      '<div class="panel-body" style="padding-bottom:2px"><div class="chart-well">'+dailyTrend(daily,{w:900,h:236})+"</div></div>"+
      '<div class="trendkey"><span><i class="lk" style="background:var(--run)"></i>Per day</span>'+
      '<span><i class="lk" style="background:var(--violet)"></i>7-day mean</span>'+
      '<span><i class="lk" style="background:var(--ink)"></i>Selection</span></div>',
      "Hovering a name elsewhere fills in that trader's own daily series against the floor's — which is where a pattern that starts on a date separates from one that was always there.")+
    panel("Typology fingerprint","12 months · by rule category · red = upheld",
      '<div class="panel-body"><div class="chart-well">'+hbars(catRows,{w:520,rowH:23,labW:150})+"</div></div>"+upheldKey,
      "The floor's mix is unremarkable; one person's is not. Hover a trader and the dark markers show how much of each category is theirs.")+
    panel("Booking-hour profile","12 months · by execution hour · desk-local",
      '<div class="panel-body"><div class="chart-well">'+hourChart(hourCounts,{w:560,h:212})+"</div></div>",
      "A selection sitting outside the trading day — before the open, after the close, through the night — is the shape concealment makes.")+
    "</div>";

  /* The detection heatmap has to survive production: two hundred traders and a
     rule set that keeps growing. It does that by zooming rather than by
     truncating — rows collapse from fifty rules to nine categories, columns
     from every trader to twelve desks, and in trader mode you choose how many
     of the busiest names to bring on screen. Category × desk fits any monitor;
     rule × trader is the same picture at full resolution. */
  const H=state.heat;
  const byRule=H.rows==="rule";
  const byTrader=H.cols==="trader";
  const heatRows=byRule?RULES.map(r=>({key:r.id,label:r.id+" "+r.name,short:r.id,tip:r.name,sub:r.desc,hl:"rule|"+r.id}))
    :RULE_CATS.map(c=>({key:c,label:c,short:c,tip:c,
                        sub:RULES.filter(r=>r.cat===c).length+" rules in this category",hl:"cat|"+c}));
  let heatCols;
  if(byTrader){
    const ranked=Object.values(TRADER_STATS).filter(traderInRail)
      .map(st=>({st,n:scopedAll.filter(a=>a.traderId===st.id).length}))
      .sort((a,b)=>b.n-a.n||b.st.idx-a.st.idx);
    heatCols=(H.top?ranked.slice(0,H.top):ranked).map(x=>({key:x.st.id,label:x.st.name,
      tip:x.st.name,sub:DESK_BY_ID[x.st.deskId].name,
      extra:"Risk index|"+x.st.idx.toFixed(1)+"§Versus cohort|"+peerText(x.st)+"§Alerts|"+x.n,
      hl:"trader|"+x.st.id}));
  }else{
    heatCols=DESKS.filter(d=>!state.filters.desk.size||state.filters.desk.has(d.id))
      .map(d=>({key:d.id,label:d.short,tip:d.name,sub:d.region+" · "+d.traders.length+" traders",
        extra:"Traders|"+d.traders.length,hl:"desk|"+d.id}));
  }
  /* One pass over the scoped book, keyed straight off each alert. Walking the
     grid per alert would be rows × columns × alerts — fine at fifty by thirty,
     seventeen million comparisons at fifty by two hundred. This is O(alerts)
     however far the floor and the rule set grow. */
  const rowKeys={}, colKeys={};
  heatRows.forEach(r=>{ rowKeys[r.key]=1; });
  heatCols.forEach(c=>{ colKeys[c.key]=1; });
  const cellIdx={}, rowTotal={}, colTotal={};
  let matMax=0;
  scopedAll.forEach(a=>{
    const rk=byRule?a.ruleId:a.cat, ck=byTrader?a.traderId:a.deskId;
    if(!rowKeys[rk]) return;
    rowTotal[rk]=(rowTotal[rk]||0)+1;
    if(!colKeys[ck]) return;
    colTotal[ck]=(colTotal[ck]||0)+1;
    const k=rk+"\u0001"+ck;
    const v=(cellIdx[k]=(cellIdx[k]||0)+1);
    if(v>matMax) matMax=v;
  });
  matMax=Math.max(1,matMax);
  const dense=H.density==="compact";
  const heatCtl='<div class="fstrip actstrip">'+
    '<label><span>Rows</span><div class="segbtns">'+
      [["rule","Rule ("+RULES.length+")"],["cat","Category ("+RULE_CATS.length+")"]].map(x=>
        '<button data-heatrows="'+x[0]+'" aria-pressed="'+(H.rows===x[0])+'">'+x[1]+"</button>").join("")+"</div></label>"+
    '<label><span>Columns</span><div class="segbtns">'+
      [["trader","Trader ("+TRADERS.filter(traderInRail).length+")"],["desk","Desk ("+DESKS.length+")"]].map(x=>
        '<button data-heatcols="'+x[0]+'" aria-pressed="'+(H.cols===x[0])+'">'+x[1]+"</button>").join("")+"</div></label>"+
    (byTrader?'<label><span>Show</span><div class="segbtns">'+
      [[12,"Top 12"],[18,"Top 18"],[30,"Top 30"],[60,"Top 60"],[0,"All"]].map(x=>
        '<button data-heattop="'+x[0]+'" aria-pressed="'+(H.top===x[0])+'">'+x[1]+"</button>").join("")+"</div></label>":"")+
    '<label><span>Density</span><div class="segbtns">'+
      [["comfortable","Comfortable"],["compact","Compact"]].map(x=>
        '<button data-heatden="'+x[0]+'" aria-pressed="'+(H.density===x[0])+'">'+x[1]+"</button>").join("")+"</div></label>"+
    '<div class="fspacer"></div><span class="tiny">'+heatRows.length+" × "+heatCols.length+" = "+
      fmtNum(heatRows.length*heatCols.length)+" cells</span></div>";

  const matrix=panel("Detection heatmap",
    (byRule?"rule":"category")+" × "+(byTrader?"trader":"desk")+" · full 12 months · darker = more alerts",
    heatCtl+
    '<div class="matwrap tallmat'+(dense?" dense":"")+'"><table class="matrix"><thead><tr><th class="rowhd"></th>'+
    heatCols.map(c=>'<th class="colhd" data-hlsrc="'+esc(c.hl)+'" data-tip="'+esc(c.tip)+'" data-tipsub="'+esc(c.sub)+
      '" data-tiptable="'+esc((c.extra?c.extra+"§":"")+"Alerts in view|"+(colTotal[c.key]||0))+'"><div>'+esc(c.label)+"</div></th>").join("")+
    '<th class="colhd"><div>Total</div></th></tr></thead><tbody>'+
    heatRows.map(r=>'<tr><th class="rowhd" data-hlsrc="'+esc(r.hl)+'" data-tip="'+esc(r.tip)+'" data-tipsub="'+esc(r.sub)+'">'+
      (byRule?"<b>"+r.short+"</b>"+esc(r.label.slice(r.short.length+1)):"<b></b>"+esc(r.label))+"</th>"+
      heatCols.map(c=>{
        const n=cellIdx[r.key+"\u0001"+c.key]||0;
        return '<td><button class="mcell'+(n?"":" zero")+'" style="background:'+heatColor(n,matMax)+
          '" '+hlAgg("cell",r.key+"\u0001"+c.key,n)+
          ' data-hl-'+(byTrader?"trader":"desk")+'="'+c.key+'" data-hl-'+(byRule?"rule":"cat")+'="'+esc(r.key)+
          '" data-heatcell="'+esc(r.key+"|"+c.key)+'" data-tip="'+esc(c.tip)+'" data-tipsub="'+esc(r.tip)+
          '" data-tiptable="Alerts|'+n+"§Share of this "+(byRule?"rule":"category")+"|"+
            (rowTotal[r.key]?Math.round(n/rowTotal[r.key]*100):0)+"%§Share of this "+(byTrader?"trader":"desk")+"|"+
            (colTotal[c.key]?Math.round(n/colTotal[c.key]*100):0)+'%">'+(n||"·")+"</button></td>";
      }).join("")+
      '<td><button class="mcell" '+hlAgg(byRule?"rule":"cat",r.key,rowTotal[r.key]||0)+
        ' style="background:color-mix(in srgb,var(--ink-3) 14%,var(--panel));font-weight:800" data-hlsrc="'+esc(r.hl)+
        '" data-tip="'+esc(r.tip)+'" data-tipsub="Every column">'+(rowTotal[r.key]||0)+"</button></td></tr>").join("")+
    '<tr class="mtot"><th class="rowhd"><b></b>Total</th>'+
      heatCols.map(c=>'<td><button class="mcell" '+hlAgg(byTrader?"trader":"desk",c.key,colTotal[c.key]||0)+
        ' style="background:color-mix(in srgb,var(--ink-3) 14%,var(--panel));font-weight:800" data-hlsrc="'+esc(c.hl)+
        '" data-tip="'+esc(c.tip)+'" data-tipsub="Every row">'+(colTotal[c.key]||0)+"</button></td>").join("")+
      '<td><button class="mcell" style="background:var(--panel-2);font-weight:800">'+fmtNum(scopedAll.length)+"</button></td></tr>"+
    "</tbody></table></div>"+
    '<div class="mkey"><span class="kl">Alerts per cell</span><i style="background:var(--heat-0)"></i><span>None</span>'+
    '<i style="background:'+heatColor(matMax*0.2,matMax)+'"></i><span>Low</span>'+
    '<i style="background:'+heatColor(matMax*0.55,matMax)+'"></i><span>Medium</span>'+
    '<i style="background:'+heatColor(matMax*0.85,matMax)+'"></i><span>High</span>'+
    '<i style="background:'+heatColor(matMax,matMax)+'"></i><span>Highest ('+matMax+')</span></div>',
    "Start wide and zoom in: <b>category × desk</b> is nine rows by twelve columns and fits any screen; <b>rule × trader</b> is the same picture at full resolution. "+
    "A lit column is one person, not a department — read down it for how many different typologies that name triggers, and across a row for a rule that needs re-tuning. "+
    "<b>Click any cell or label</b> to lock that selection across the page; <b>double-click</b> to open it in the Detections queue.");

  // Bottom row: rules, traders, ageing.
  const ruleItems=RULES.map(r=>{
    const hits=scopedAll.filter(a=>a.ruleId===r.id);
    return {label:r.id+" "+r.name.slice(0,26),v:hits.length,
      v2:hits.filter(a=>a.status==="Suspicious"||a.status==="Escalated").length,
      color:SEV_COLOR[r.sev],click:'data-ruleclick="'+r.id+'"',
      agg:hlAgg("rule",r.id,hits.length),aggKey:"rule|"+r.id,
      tip:r.id+" "+r.name,tipsub:r.cat+" · "+r.sev,
      tiptable:["Alerts raised|"+fmtNum(hits.length),
        "Upheld — suspicious or escalated|"+fmtNum(hits.filter(a=>a.status==="Suspicious"||a.status==="Escalated").length),
        "Passed as explained|"+fmtNum(hits.filter(a=>a.status==="Passed").length),
        "Still open|"+fmtNum(hits.filter(isOpen).length)].join("§"),
      hl:'data-hlsrc="rule|'+r.id+'" data-hl-rule="'+r.id+'"'};
  }).sort((a,b)=>b.v-a.v).slice(0,10);

  const inRail=Object.values(TRADER_STATS).filter(traderInRail);
  const thin=inRail.filter(s=>s.trades>0&&!rankable(s)).length;
  const tstats=inRail.filter(rankable).sort((a,b)=>b.idx-a.idx).slice(0,10);
  const maxIdx=Math.max(1,...tstats.map(s=>s.idx));

  const rowC='<div class="grid3 tight">'+
    panel("Top rules by hits","12 months · red = upheld",
      '<div class="panel-body"><div class="chart-well">'+hbars(ruleItems,{w:520,rowH:20,labW:186})+"</div></div>"+upheldKey,
      "The full bar is every alert the rule raised; the red length inside it is how many an officer upheld as suspicious or escalated. "+
      "A long bar with almost no red is a rule generating work rather than findings. <b>Double-click a bar</b> to open that rule.")+
    panel("Open queue by age","against the disposition target",
      '<div class="panel-body"><div class="chart-well">'+hbars(ageItems,{w:420,rowH:26,labW:110})+"</div></div>",
      "Critical and High alerts older than <b>3 business days</b> breach the surveillance SLA.")+
    panel("Highest-risk traders","12 months · severity-weighted alerts per 100 of the trader's own deals"+
      (thin?" · "+thin+" name"+(thin===1?"":"s")+" below "+RANK_MIN_DEALS+" deals not ranked":""),
      '<div class="panel-body"><div class="rank-list">'+tstats.map(s=>{
        const t=TRADER_BY_ID[s.id];
        return '<div class="rrow2" data-trader="'+s.id+'" data-hlsrc="trader|'+s.id+'" data-hl-trader="'+s.id+
          '" data-hl-desk="'+s.deskId+'" '+hlAgg("trader",s.id,s.alerts)+
          '><div class="rl"><b>'+esc(s.name)+"</b>"+
          '<div class="sub2">'+esc(DESK_BY_ID[s.deskId].short)+(t.arc?" · "+esc(t.arc):"")+"</div></div>"+
          '<div class="rv">'+s.idx.toFixed(1)+'<span class="sub2" style="margin-left:5px" data-tip="'+esc(peerTip(s))+'">'+peerText(s)+"</span></div>"+
          '<div class="rfull"><span class="bar-mini"><i style="width:'+(s.idx/maxIdx*100).toFixed(0)+"%;background:"+
          (s.idx>maxIdx*0.6?"var(--fail)":s.idx>maxIdx*0.3?"var(--warn)":"var(--run)")+'"></i></span>'+
          '<span class="sub2">'+s.alerts+" alerts · "+s.susp+" upheld · "+s.ruleCount+" of "+RULES.length+" rules</span></div></div>";
      }).join("")+"</div></div>",
      "Divided by each trader's own deal count, so a busy name is not flagged for being busy — and a quiet one cannot hide inside a group's turnover. <b>Click a name</b> for the trader file.")+
    "</div>";

  return kpis+rowA+'<div class="mt10">'+rowB+"</div>"+'<div class="mt10">'+matrix+"</div>"+'<div class="mt10">'+rowC+"</div>";
}
