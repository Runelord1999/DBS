/* ============================================================
   Market context — the deals plotted against the market they were struck into
   Every off-market, fixing-window, session-extreme and momentum typology is an
   argument about where a print sat relative to the market at that moment. Said
   in basis points it is a number the officer has to take on trust; drawn against
   the instrument's own path it is a picture they can check.

   One session's trades render on a minute axis, so a cluster into the 16:00 fix
   or against the close is visible as a cluster. Trades spread over days render
   on a daily axis, so a build-and-reverse or a mark-and-unwind reads as a shape.
============================================================ */
function marketChart(inst,trades,opts){
  opts=opts||{};
  const W=opts.w||620,H=opts.h||210,padL=52,padR=12,padT=16,padB=26;
  const days=uniq(trades.map(t=>t.dayIdx)).sort((a,b)=>a-b);
  /* No tick data for this instrument over these dates is an ordinary condition
     in a first deployment, not an error. Say so where the chart would have been
     and leave the rest of the case file readable. */
  if(!days.some(d=>hasMarketData(inst,d)))
    return '<div class="empty" style="padding:18px;text-align:left">No market data held for <b>'+
      esc(inst.name)+'</b> on '+(days.length===1?"this date":"these dates")+
      '. The deal prices and the booked deviation are shown above; the market line needs a quote series for this instrument.</div>';
  const intraday=days.length===1;
  const fmt=v=>v.toFixed(inst.dp);
  const pts=[], marks=[];
  if(intraday){
    const d=days[0];
    for(let m=SESSION_OPEN;m<=SESSION_CLOSE;m+=5) pts.push({x:m,v:midAt(inst,d,m)});
    trades.forEach(t=>marks.push({x:Math.max(SESSION_OPEN,Math.min(SESSION_CLOSE,t.execMin)),t}));
  }else{
    const lo=Math.max(0,days[0]-6), hi=Math.min(DAYS-1,days[days.length-1]+6);
    for(let d=lo;d<=hi;d++) pts.push({x:d,v:midAt(inst,d,SESSION_CLOSE)});
    trades.forEach(t=>marks.push({x:t.dayIdx,t}));
  }
  // a gap in the series is a missing observation, not a zero
  const drawn=pts.filter(p=>p.v!=null&&isFinite(p.v));
  if(!drawn.length)
    return '<div class="empty" style="padding:18px;text-align:left">No market data held for <b>'+
      esc(inst.name)+'</b> over this window.</div>';
  pts.length=0; drawn.forEach(p=>pts.push(p));
  const xs=pts.map(p=>p.x), x0=Math.min(...xs), x1=Math.max(...xs);
  const all=pts.map(p=>p.v).concat(trades.map(t=>t.px));
  let lo=Math.min(...all), hi=Math.max(...all);
  const pad=Math.max((hi-lo)*0.18,Math.abs(lo)*0.0004);
  lo-=pad; hi+=pad;
  const X=v=>padL+(x1===x0?0.5:(v-x0)/(x1-x0))*(W-padL-padR);
  const Y=v=>H-padB-((v-lo)/((hi-lo)||1))*(H-padB-padT);
  let g="";
  // The instrument's own dealing spread, drawn as a band. A print inside it is
  // ordinary execution; the rules only have something to say outside it.
  const bandTop=pts.map(p=>X(p.x).toFixed(1)+","+Y(p.v*(1+inst.spreadBps/10000)).toFixed(1)).join(" ");
  const bandBot=pts.slice().reverse().map(p=>X(p.x).toFixed(1)+","+Y(p.v*(1-inst.spreadBps/10000)).toFixed(1)).join(" ");
  g+='<polygon points="'+bandTop+" "+bandBot+'" fill="var(--ink-3)" opacity=".14"/>';
  for(let i=0;i<=3;i++){
    const v=lo+(hi-lo)*i/3, y=Y(v);
    g+='<line x1="'+padL+'" y1="'+y.toFixed(1)+'" x2="'+(W-padR)+'" y2="'+y.toFixed(1)+'" stroke="var(--hair)" stroke-dasharray="'+(i?"2 3":"0")+'"/>'+
       '<text x="'+(padL-6)+'" y="'+(y+3.5).toFixed(1)+'" text-anchor="end" font-size="'+cf(8.5)+'" fill="var(--ink-3)" font-family="var(--mono)">'+fmt(v)+"</text>";
  }
  if(intraday){
    // The published benchmark window, so a fixing typology has its window drawn.
    if(inst.fam==="fx"||inst.fam==="ndf"){
      g+='<rect x="'+X(960).toFixed(1)+'" y="'+padT+'" width="'+Math.max(2,(X(966)-X(960))).toFixed(1)+'" height="'+(H-padB-padT)+
         '" fill="var(--violet)" opacity=".16"/>'+
         '<text x="'+X(963).toFixed(1)+'" y="'+(padT-4)+'" text-anchor="middle" font-size="'+cf(7.5)+'" fill="var(--violet)">16:00 fix</text>';
    }
    for(let m=SESSION_OPEN;m<=SESSION_CLOSE;m+=120)
      g+='<text x="'+X(m).toFixed(1)+'" y="'+(H-padB+13)+'" text-anchor="middle" font-size="'+cf(8.5)+'" fill="var(--ink-3)" font-family="var(--mono)">'+fmtTime(m)+"</text>";
  }else{
    const step=Math.max(1,Math.round(pts.length/6));
    pts.forEach((p,i)=>{ if(i%step) return;
      g+='<text x="'+X(p.x).toFixed(1)+'" y="'+(H-padB+13)+'" text-anchor="middle" font-size="'+cf(8.5)+'" fill="var(--ink-3)">'+fmtDateShort(dateForIdx(p.x))+"</text>"; });
  }
  g+='<polyline points="'+pts.map(p=>X(p.x).toFixed(1)+","+Y(p.v).toFixed(1)).join(" ")+'" fill="none" stroke="var(--ink-3)" stroke-width="1.4"/>';
  const thr=omThreshold(inst);
  marks.forEach(mk=>{
    const t=mk.t, x=X(mk.x), y=Y(t.px), ym=Y(t.mktPx);
    const off=Math.abs(t.devBps)>thr;
    const c=off?"var(--fail)":Math.abs(t.devBps)>inst.spreadBps*2?"var(--warn)":"var(--pass)";
    g+='<line x1="'+x.toFixed(1)+'" y1="'+ym.toFixed(1)+'" x2="'+x.toFixed(1)+'" y2="'+y.toFixed(1)+
       '" stroke="'+c+'" stroke-width="1" stroke-dasharray="2 2" opacity=".8"/>';
    g+='<circle cx="'+x.toFixed(1)+'" cy="'+y.toFixed(1)+'" r="4.6" fill="'+c+'" fill-opacity=".85" stroke="var(--panel)" stroke-width="1.2"'+
       ' data-tip="'+esc(t.dir+" "+fmtM(t.notional)+" @ "+fmt(t.px))+'" data-tipsub="'+esc(fmtDateShort(t.date)+" "+fmtTime(t.execMin))+
       '" data-tiptable="Market mid|'+fmt(t.mktPx)+"§Deviation|"+(t.devBps>0?"+":"")+t.devBps.toFixed(1)+" bps§Dealing spread|"+
       inst.spreadBps.toFixed(2)+" bps§Materiality|"+thr.toFixed(1)+' bps"/>';
    g+='<text x="'+x.toFixed(1)+'" y="'+(y<ym?y-8:y+13).toFixed(1)+'" text-anchor="middle" font-size="'+cf(7.5)+'" font-weight="700" fill="'+c+'">'+
       (t.dir==="Buy"||t.dir==="Pay"||t.dir==="Borrow"?"B":"S")+"</text>";
  });
  return '<svg viewBox="0 0 '+W+" "+H+'" preserveAspectRatio="xMidYMid meet" role="img">'+g+"</svg>";
}
/* The instrument an alert is really about: the one carrying most of its deals. */
function alertInstrument(trades){
  const c={};
  trades.forEach(t=>{ if(t.instKey) c[t.instKey]=(c[t.instKey]||0)+1; });
  const k=Object.keys(c).sort((a,b)=>c[b]-c[a])[0];
  return k?INST_BY_KEY[k]:null;
}
function marketBlock(trades,label){
  const inst=alertInstrument(trades);
  if(!inst) return "";
  const own=trades.filter(t=>t.instKey===inst.key);
  const days=uniq(own.map(t=>t.dayIdx));
  const intraday=days.length===1;
  const thr=omThreshold(inst);
  const worst=own.reduce((a,t)=>Math.abs(t.devBps)>Math.abs(a.devBps)?t:a,own[0]);
  /* What the picture is actually showing. Not every typology is a pricing
     argument: a fixing or a burst is about where the deals sit in time, and
     saying "inside the ordinary range" under that chart reads as a retraction. */
  let read;
  if(Math.abs(worst.devBps)>thr){
    read="The furthest print sits <b>"+Math.abs(worst.devBps).toFixed(1)+" bps</b> from the mid — "+
      (Math.abs(worst.devBps)/inst.spreadBps).toFixed(0)+"× the spread anyone else was dealing at, and past the point where the difference stops being execution.";
  } else if(intraday&&own.length>1){
    const span=Math.max.apply(null,own.map(t=>t.execMin))-Math.min.apply(null,own.map(t=>t.execMin));
    const dirs=uniq(own.map(t=>t.dir));
    const dr=dayRange(inst,days[0])||{lo:0,hi:0};
    const width=dr.hi-dr.lo;
    // Where in the session's range the prints landed. Buying at the low all day
    // is a shape even when every individual fill is inside the spread.
    const posn=width>0?mean(own.map(t=>(t.mktPx-dr.lo)/width)):0.5;
    const buySide=["Buy","Pay","Borrow"].indexOf(own[0].dir)>=0;
    if(dirs.length===1&&(buySide?posn<0.28:posn>0.72)){
      read="Every fill is inside the spread, so no single print is off market. The shape is where they sit in the day: <b>"+
        plural(own.length,"deal")+" all "+own[0].dir.toLowerCase()+"ing in the "+
        (buySide?"bottom":"top")+" "+Math.round((buySide?posn:1-posn)*100)+"% of the session's range</b>, across "+
        (span<=1?"one minute":plural(span,"minute"))+".";
    } else {
      read="Pricing is unremarkable — the furthest print is "+Math.abs(worst.devBps).toFixed(1)+
        " bps from mid, inside ordinary execution. The shape is in the timing: <b>"+plural(own.length,"deal")+
        (dirs.length===1?" all "+own[0].dir.toLowerCase()+"ing":"")+" inside "+(span<=1?"the same minute":plural(span,"minute"))+"</b>.";
    }
  } else if(own.length>1){
    const dirs=uniq(own.map(t=>t.dir));
    read="Pricing is unremarkable. What the chart carries is the sequence: <b>"+own.length+" deals across "+
      days.length+" session"+(days.length>1?"s":"")+"</b>"+(dirs.length>1?", turning direction inside the window":", all one way")+".";
  } else {
    read="The print sits <b>"+Math.abs(worst.devBps).toFixed(1)+" bps</b> from the mid, inside the range ordinary execution covers — on this rule the finding is not the price.";
  }
  return '<div class="block"><div class="lbl">'+esc(label||"The market these deals were struck into")+"</div>"+
    '<p class="narr" style="margin-bottom:8px"><b>'+esc(inst.name)+"</b> · "+
      (intraday?"the session of "+esc(fmtDate(dateForIdx(days[0]))):"daily mid, "+esc(fmtDateShort(dateForIdx(Math.min.apply(null,days))))+" – "+esc(fmtDateShort(dateForIdx(Math.max.apply(null,days)))))+
      " · dealing spread <b>"+inst.spreadBps.toFixed(2)+" bps</b>, material beyond <b>"+thr.toFixed(1)+" bps</b></p>"+
    '<div class="chart-well" style="height:214px">'+marketChart(inst,own,{w:620,h:210})+"</div>"+
    '<div class="trendkey"><span><i class="lk" style="background:var(--ink-3)"></i>Market mid</span>'+
    '<span><i class="lk" style="background:color-mix(in srgb,var(--ink-3) 40%,transparent)"></i>Dealing spread</span>'+
    '<span><i class="lk" style="background:var(--pass)"></i>Inside the spread</span>'+
    '<span><i class="lk" style="background:var(--warn)"></i>Outside it</span>'+
    '<span><i class="lk" style="background:var(--fail)"></i>Past materiality</span></div>'+
    '<p class="narr" style="margin-top:8px;color:var(--ink-3)">'+read+"</p></div>";
}
function spark(vals,w,h,color){
  w=w||84;h=h||22;
  const max=Math.max(1,...vals);
  const X=i=>i/(vals.length-1||1)*w, Y=v=>h-2-(v/max)*(h-4);
  return '<svg class="spark" width="'+w+'" height="'+h+'"><polyline points="'+
    vals.map((v,i)=>X(i).toFixed(1)+","+Y(v).toFixed(1)).join(" ")+'" fill="none" stroke="'+(color||"var(--run)")+'" stroke-width="1.4"/></svg>';
}
/* Traders plotted by how much they trade against how much of it alerts. The
   diagonal is the floor average; names above it alert more than their volume
   explains, which is the whole point of looking at it this way. */
function bubbleChart(pts,opts){
  opts=opts||{};
  const W=opts.w||560,H=opts.h||300,padL=44,padB=34,padT=14,padR=14;
  const maxX=Math.max(1,...pts.map(p=>p.x)), maxY=Math.max(1,...pts.map(p=>p.y));
  const nx=Math.ceil(maxX/50)*50, ny=Math.ceil(maxY/5)*5;
  const X=v=>padL+(v/nx)*(W-padL-padR), Y=v=>H-padB-(v/ny)*(H-padB-padT);
  const maxR=Math.max(1,...pts.map(p=>p.r));
  let g="";
  for(let i=0;i<=4;i++){
    const v=ny*i/4,y=Y(v);
    g+='<line x1="'+padL+'" y1="'+y.toFixed(1)+'" x2="'+(W-padR)+'" y2="'+y.toFixed(1)+'" stroke="var(--hair)" stroke-dasharray="'+(i?"2 3":"0")+'"/>'+
       '<text x="'+(padL-6)+'" y="'+(y+3.5).toFixed(1)+'" text-anchor="end" font-size="'+cf(8.5)+'" fill="var(--ink-3)" font-family="var(--mono)">'+v.toFixed(0)+"</text>";
  }
  for(let i=1;i<=4;i++){
    const v=nx*i/4,x=X(v);
    g+='<text x="'+x.toFixed(1)+'" y="'+(H-padB+13)+'" text-anchor="middle" font-size="'+cf(8.5)+'" fill="var(--ink-3)" font-family="var(--mono)">'+fmtNum(v)+"</text>";
  }
  g+='<text x="'+(W/2)+'" y="'+(H-4)+'" text-anchor="middle" font-size="'+cf(8.5)+'" fill="var(--ink-3)">Trades booked (12 months)</text>';
  // Rotated up the left edge: a horizontal title here collides with the top
  // gridline value as soon as the alert count reaches three digits.
  const midY=(padT+(H-padB))/2;
  g+='<text x="11" y="'+midY.toFixed(1)+'" transform="rotate(-90 11 '+midY.toFixed(1)+')" text-anchor="middle" font-size="'+cf(8.5)+'" fill="var(--ink-3)">Alerts</text>';
  pts.forEach(p=>{
    const r=4+ (p.r/maxR)*13;
    const ag=hlAgg("trader",p.id,(TRADER_STATS[p.id]||{}).alerts||0);
    g+='<circle cx="'+X(p.x).toFixed(1)+'" cy="'+Y(p.y).toFixed(1)+'" r="'+r.toFixed(1)+'" fill="'+p.color+
      '" fill-opacity=".55" stroke="'+p.color+'" stroke-width="1.2" style="cursor:pointer" data-trader="'+p.id+
      '" data-hl-trader="'+p.id+'" data-hl-desk="'+esc(p.deskId||"")+'" data-hlsrc="trader|'+p.id+'" '+ag+
      ' data-tip="'+esc(p.label)+'" data-tipsub="'+esc(p.sub)+'" data-tiptable="'+esc(p.tip)+'"/>';
    if(p.big) g+='<text data-hl-trader="'+p.id+'" '+ag+' x="'+X(p.x).toFixed(1)+'" y="'+(Y(p.y)-r-4).toFixed(1)+'" text-anchor="middle" font-size="'+cf(8.5)+'" font-weight="700" fill="var(--ink-2)">'+esc(p.label)+"</text>";
  });
  return '<svg viewBox="0 0 '+W+" "+H+'" preserveAspectRatio="xMidYMid meet" role="img">'+g+"</svg>";
}
/* Heat ramp shared by the matrix and the trader grid. */
function heatColor(v,max){
  if(!v) return "var(--heat-0)";
  const t=Math.min(1,v/(max||1));
  const stops=["var(--heat-1)","var(--heat-2)","var(--heat-3)","var(--heat-4)"];
  const c=stops[Math.min(3,Math.floor(t*4-1e-9))];
  const mix=Math.round(28+t*62);
  return "color-mix(in srgb,"+c+" "+mix+"%,var(--panel))";
}
