/* ============================================================
   Pane — Trade Activity
   The overview answers "what fired". This answers "what is the floor actually
   doing" — the trading data on its own terms, before any rule touches it.
   Everything here is scoped by the rail, so it answers the same question for a
   desk, a trader or an asset class as it does for the whole book.
============================================================ */
function paneActivity(){
  const rows=TRADES.filter(tradeMatchesRail);
  const notl=rows.reduce((a,t)=>a+t.notional,0);
  // Sorted once: median and the 95th percentile are two reads of one ordering,
  // and at 59,000 tickets sorting twice is the most expensive line on the tab.
  const sizes=rows.map(t=>t.notional).sort((a,b)=>a-b);
  const activeTraders=uniq(rows.map(t=>t.traderId)).length;
  const bizDays=uniq(rows.map(t=>t.dayIdx)).length||1;

  const kpis='<div class="kpis">'+
    kpi("Deals booked",fmtNum(rows.length),"12 months, rail-scoped","var(--agent)")+
    kpi("Notional",fmtM(notl),"aggregate across products","var(--run)")+
    kpi("Median ticket",fmtM(median(sizes)),"p95 "+fmtM(pctile(sizes,0.95)),"var(--violet)")+
    kpi("Largest ticket",fmtM(Math.max(0,...sizes)),"single deal","var(--warn)")+
    kpi("Deals per day",fmtNum(Math.round(rows.length/bizDays)),"across "+fmtNum(bizDays)+" sessions","var(--cyan)")+
    kpi("Traders active",fmtNum(activeTraders),"of "+TRADERS.length+" on the floor","var(--gold)")+
    kpi("Products",fmtNum(uniq(rows.map(t=>t.product)).length),"of "+PRODUCTS.length+" approved","var(--pink)")+
    kpi("Counterparties",fmtNum(uniq(rows.map(t=>t.ctpy)).length),"names faced","var(--pass)")+
    "</div>";

  /* One pass over the book, not one per series. Every panel below is a different
     cut of the same 12 months, and the readable shape — a filter per product, per
     counterparty, per band — walks the blotter a hundred times over. At the size a
     real floor books, that turned every toggle on this tab into a two-second wait.
     Collect once into buckets, read the buckets afterwards. */
  const SEP="\u0001";   // key delimiter, so 1+"FX Cash" cannot collide with 11+"FX Cash"
  const bucket=()=>({n:0,nl:0,sizes:[],traders:Object.create(null),tn:0});
  const grab=(m,k)=>m[k]||(m[k]=bucket());
  const put=(b,t)=>{
    b.n++; b.nl+=t.notional; b.sizes.push(t.notional);
    if(!b.traders[t.traderId]){ b.traders[t.traderId]=1; b.tn++; }
  };
  const byProd=Object.create(null), byCtpy=Object.create(null), byAc=Object.create(null),
        byCh=Object.create(null), byTenor=Object.create(null), bySize=Object.create(null),
        byMonthAc=Object.create(null), ctpyType=Object.create(null);
  const hrs=Array(24).fill(0);
  rows.forEach(t=>{
    put(grab(byProd,t.product),t);
    put(grab(byCtpy,t.ctpy),t);
    put(grab(byAc,t.ac),t);
    put(grab(byCh,t.channel),t);
    put(grab(byTenor,tenorBandOf(t.tenor)),t);
    put(grab(bySize,sizeBandOf(t.notional)),t);
    const mi=monthIdxOf(t.date);
    if(mi>=0) grab(byMonthAc,mi+SEP+t.ac).n++;
    hrs[Math.min(23,Math.floor(t.execMin/60))]++;
    if(ctpyType[t.ctpy]===undefined) ctpyType[t.ctpy]=t.ctpyType||"";
  });
  // Alerts the same way: one pass keyed by dimension rather than a scan per series.
  const alBy={product:Object.create(null),ctpy:Object.create(null),
              tenorb:Object.create(null),sizeb:Object.create(null)};
  ALERTS.forEach(a=>{
    if(!matchRail(a)) return;
    a.products.forEach(x=>alBy.product[x]=(alBy.product[x]||0)+1);
    (a.ctpys||[]).forEach(x=>alBy.ctpy[x]=(alBy.ctpy[x]||0)+1);
    (a.tenorBands||[]).forEach(x=>alBy.tenorb[x]=(alBy.tenorb[x]||0)+1);
    (a.sizeBands||[]).forEach(x=>alBy.sizeb[x]=(alBy.sizeb[x]||0)+1);
  });
  const B=(m,k)=>m[k]||{n:0,nl:0,sizes:[],tn:0};

  // Monthly volume, stacked by asset class — the book's own shape over the year.
  const months=MONTH_KEYS.map((mk,i)=>({label:mk.label,sub:i===0||mk.m===0?String(mk.y).slice(2):"",
    parts:ASSET_CLASSES.map(ac=>({label:ac,v:(byMonthAc[i+SEP+ac]||{n:0}).n,color:AC_COLOR[ac]}))}));

  /* Every panel here is drawn from deals, so every marker is measured in deals
     too — "T:" for the count charts, "V:" for the notional ones. */
  const acSegs=ASSET_CLASSES.map(ac=>{
    const n=B(byAc,ac).n;
    return {label:ac,v:n,color:AC_COLOR[ac],hl:'data-hlsrc="ac|'+esc(ac)+'" '+hlDim("ac",ac),agg:hlAggT("ac",ac,n)};
  }).filter(x=>x.v>0);
  const chSegs=CHANNELS.map(c=>{
    const n=B(byCh,c[0]).n;
    return {label:c[0],v:n,
      color:{"Voice":"var(--run)","eComm single-dealer":"var(--agent)","Multi-dealer platform":"var(--cyan)",
             "API / Algo":"var(--violet)","Internal booking":"var(--ink-3)"}[c[0]]||"var(--ink-3)",
      hl:'data-hlsrc="channel|'+esc(c[0])+'" '+hlDim("channel",c[0]),
      agg:hlAggT("channel",c[0],n)};
  }).filter(x=>x.v>0);

  /* Product and counterparty, each measured twice — once by how often the desk
     deals and once by how much it moves. The two rankings disagree constantly,
     and the disagreement is the point: a name that is large by notional and
     small by count is a block relationship, and the reverse is a flow one. */
  const prodStats=PRODUCTS.map(pr=>{
    const b=byProd[pr.p]; if(!b) return null;
    const al=alBy.product[pr.p]||0;
    return {p:pr.p,ac:pr.ac,n:b.n,nl:b.nl,al,
      tiptable:["Deals|"+fmtNum(b.n),"Notional|"+fmtM(b.nl),
        "Median ticket|"+fmtM(median(b.sizes)||0),
        "Traders|"+b.tn,"Alerts|"+fmtNum(al)].join("§"),
      hl:'data-hlsrc="product|'+esc(pr.p)+'" '+hlDim("product",pr.p)};
  }).filter(Boolean);
  const prodCount=prodStats.slice().sort((a,b)=>b.n-a.n).slice(0,12).map(x=>({
    label:x.p,v:x.n,vLabel:fmtNum(x.n),color:AC_COLOR[x.ac],
    tip:x.p,tipsub:x.ac+" · by transaction count",tiptable:x.tiptable,hl:x.hl,
    agg:hlAggT("product",x.p,x.n),aggKey:"T:product|"+x.p}));
  const prodVol=prodStats.slice().sort((a,b)=>b.nl-a.nl).slice(0,12).map(x=>({
    label:x.p,v:x.nl,vLabel:fmtM(x.nl),color:AC_COLOR[x.ac],
    tip:x.p,tipsub:x.ac+" · by notional",tiptable:x.tiptable,hl:x.hl,
    agg:hlAggV("product",x.p,x.nl),aggKey:"V:product|"+x.p}));

  const ctpyStats=Object.keys(byCtpy).map(c=>{
    const b=byCtpy[c], al=alBy.ctpy[c]||0, rel=!!RELATED_PARTIES[c];
    return {c,n:b.n,nl:b.nl,al,rel,type:ctpyType[c]||"",
      short:c.length>24?c.slice(0,23)+"…":c,
      tiptable:["Deals|"+fmtNum(b.n),"Notional|"+fmtM(b.nl),
        "Median ticket|"+fmtM(median(b.sizes)||0),
        "Traders facing this name|"+b.tn,
        "Alerts|"+fmtNum(al)].join("§"),
      hl:'data-hlsrc="ctpy|'+esc(c)+'" '+hlDim("ctpy",c)};
  });
  const ctpyRow=x=>({label:x.short,color:x.rel?"var(--fail)":"var(--agent)",
    tip:x.c,tipsub:x.type+(x.rel?" · related-party register":""),tiptable:x.tiptable,hl:x.hl});
  const ctpyCount=ctpyStats.slice().sort((a,b)=>b.n-a.n).slice(0,12)
    .map(x=>Object.assign(ctpyRow(x),{v:x.n,vLabel:fmtNum(x.n),
      agg:hlAggT("ctpy",x.c,x.n),aggKey:"T:ctpy|"+x.c}));
  const ctpyVol=ctpyStats.slice().sort((a,b)=>b.nl-a.nl).slice(0,12)
    .map(x=>Object.assign(ctpyRow(x),{v:x.nl,vLabel:fmtM(x.nl),
      agg:hlAggV("ctpy",x.c,x.nl),aggKey:"V:ctpy|"+x.c}));

  const tenorItems=TENOR_BANDS.map(bd=>{
    const b=B(byTenor,bd.label), al=alBy.tenorb[bd.label]||0;
    return {label:bd.label,v:b.n,color:bd.color,vLabel:fmtNum(b.n),
      tip:bd.label,tipsub:"Tenor band",
      tiptable:["Deals|"+fmtNum(b.n),"Notional|"+fmtM(b.nl),
        "Share of the book|"+(rows.length?Math.round(b.n/rows.length*100):0)+"%","Alerts|"+fmtNum(al)].join("§"),
      hl:'data-hlsrc="tenorb|'+esc(bd.label)+'" '+hlDim("tenorb",bd.label),
      agg:hlAggT("tenorb",bd.label,b.n),aggKey:"T:tenorb|"+bd.label};
  });

  const sizeItems=SIZE_BANDS.map(bd=>{
    const b=B(bySize,bd[2]), al=alBy.sizeb[bd[2]]||0;
    return {label:bd[2],v:b.n,color:"var(--run)",vLabel:fmtNum(b.n),
      tip:bd[2],tipsub:"Ticket size band",
      tiptable:["Deals|"+fmtNum(b.n),"Notional|"+fmtM(b.nl),
        "Alerts|"+fmtNum(al)].join("§"),
      hl:'data-hlsrc="sizeb|'+esc(bd[2])+'" '+hlDim("sizeb",bd[2]),
      agg:hlAggT("sizeb",bd[2],b.n),aggKey:"T:sizeb|"+bd[2]};
  }).filter(x=>x.v>0);

  const rowA='<div class="gridw2 tight">'+
    panel("Deal volume by month","stacked by asset class · 12 months",
      '<div class="panel-body"><div class="chart-well tall">'+
        stackedBars(months,null,{w:660,h:266,dim:"ac",hlMonth:true,cut:"T:",unitLabel:"deals"})+"</div></div>",
      "The book's own shape across the year. Quarter ends and roll dates are visible without anyone marking them.")+
    panel("Asset class mix","share of deals",
      '<div class="panel-body"><div class="chart-well donut-well">'+
      donut(acSegs,fmtNum(rows.length),"deals",112,19)+donutLegend(acSegs,rows.length)+"</div></div>",
      "Hovering a class lights it across every panel on the page.")+
    panel("Booking channel","how the deals reached the system",
      '<div class="panel-body"><div class="chart-well donut-well">'+
      donut(chSegs,fmtNum(rows.length),"deals",112,19)+donutLegend(chSegs,rows.length)+"</div></div>",
      "Voice and internal bookings are the two channels with the least automated evidence behind them.")+
    "</div>";

  const rowB='<div class="grid4t tight">'+
    panel("Transaction count by product","top 12 by deals",
      '<div class="panel-body"><div class="chart-well">'+hbars(prodCount,{w:520,rowH:19,labW:148})+"</div></div>",
      "How often the floor deals in each product.")+
    panel("Volume by product","top 12 by notional",
      '<div class="panel-body"><div class="chart-well">'+hbars(prodVol,{w:520,rowH:19,labW:148})+"</div></div>",
      "The same products by size. Where this order differs from the count beside it, the product trades in blocks rather than in flow.")+
    panel("Transaction count by counterparty","top 12 by deals · red = related party",
      '<div class="panel-body"><div class="chart-well">'+hbars(ctpyCount,{w:540,rowH:19,labW:168})+"</div></div>",
      "Who the floor deals with most often.")+
    panel("Volume by counterparties","top 12 by notional · red = related party",
      '<div class="panel-body"><div class="chart-well">'+hbars(ctpyVol,{w:540,rowH:19,labW:168})+"</div></div>",
      "A name large by notional and small by count is a block relationship; the reverse is a flow one. Concentration is not itself a finding, but every off-market pattern eventually points at one of these names.")+
    "</div>";

  const rowC='<div class="grid3 tight">'+
    panel("Execution hours","the trading day · desk-local time",
      '<div class="panel-body"><div class="chart-well">'+
        hourChart(hrs,{w:560,h:212,cut:"T:",unitLabel:"Deals"})+"</div></div>",
      "Every deal, not just the alerting ones — the shape a normal session makes, and the baseline the after-hours rule measures against. Select a trader anywhere on the page and this redraws as their session.")+
    panel("Ticket size distribution","deals per size band",
      '<div class="panel-body"><div class="chart-well">'+hbars(sizeItems,{w:460,rowH:19,labW:110})+"</div></div>",
      "A book's size profile is never linear. The tail on the right is where the authorisation rules live.")+
    panel("Tenor profile","how long the risk runs",
      '<div class="panel-body"><div class="chart-well">'+hbars(tenorItems,{w:460,rowH:26,labW:120})+"</div></div>",
      "The whole book by maturity band, against which any one trader's mix can be read.")+
    "</div>";

  /* Trading activity, one small chart per trader. Alert panels answer "who is
     firing"; this answers the question underneath it — what does this person's
     book actually look like, period by period, and does it look like their
     neighbours'. Squeezed on purpose: a burst, a gap, or a drift into longer
     tenors is a shape you see before you read a number. */
  const A=state.act;
  const actCols=actColumns();
  const act=traderActivity(actCols,A.metric);
  const unit=A.metric==="notional"?"m":"n";
  const isTenor=A.metric==="tenor";
  const actRows=TRADERS.filter(traderInRail).slice().sort((a,b)=>
    a.deskId.localeCompare(b.deskId,undefined,{numeric:true})||TRADER_STATS[b.id].idx-TRADER_STATS[a.id].idx);
  const cellTot=c=>act.segs.reduce((x,sg)=>x+(c.v[sg.label]||0),0);
  const sharedMax=Math.max(1e-9,...actRows.map(t=>Math.max(0,...act.by[t.id].map(cellTot))));
  const METRICS=[["count","Deal count"],["notional","Notional volume"],["tenor","Tenor spread"]];
  const YEARS=uniq(Array.from({length:DAYS},(_,d)=>dateForIdx(d).getFullYear())).sort();

  const railTrader=state.filters.trader;
  const actCards=actCols.length?actRows.map(t=>{
    const cells=act.by[t.id];
    const tot=cells.reduce((a,c)=>a+cellTot(c),0);
    const peak=Math.max(0,...cells.map(cellTot));
    const allT=isTenor?cells.reduce((a,c)=>a.concat(c.tenors||[]),[]):null;
    const scoped=railTrader.size===1&&railTrader.has(t.id);
    return '<div class="acard" data-trader="'+t.id+'" data-hlsrc="trader|'+t.id+
      '" data-hl-trader="'+t.id+'" data-hl-desk="'+t.deskId+'" '+
      hlAggT("trader",t.id,TRADER_STATS[t.id].trades)+">"+
      '<div class="an"><button type="button" class="anlink'+(scoped?" on":"")+'" data-railtrader="'+t.id+
        '" data-tip="'+esc(t.name)+'" data-tipsub="'+
        (scoped?"Scoping the whole page · click to clear":"Click to scope every chart on the page to this trader")+
        '">'+esc(t.name)+"</button></div>"+
      '<div class="ad">'+esc(DESK_BY_ID[t.deskId].short)+" · "+esc(t.grade.replace("Executive Director","ED"))+"</div>"+
      (isTenor?tenorScatter(cells,{w:188,h:62,yoy:A.yoy})
              :sparkStack(cells,act.segs,{w:188,h:62,unit:unit,yoy:A.yoy,max:A.scale==="shared"?sharedMax:0}))+
      '<div class="af"><span>'+(isTenor?fmtNum(allT.length)+" deals"
          :A.metric==="notional"?fmtM(tot):fmtNum(tot)+" deals")+"</span>"+
      "<b>"+(isTenor?(allT.length?fmtYrs(median(allT))+" med · "+uniq(allT.map(x=>x.toFixed(2))).length+" tenors":"—")
          :"peak "+(A.metric==="notional"?fmtM(peak):fmtNum(peak)))+"</b></div>"+
      "</div>";
  }).join(""):'<div class="anodata">No weeks or days match that range. Try clearing it, or widen the numbers.</div>';

  const actLegend=(isTenor?TENOR_BANDS.map(b=>({label:b.label,color:b.color})):act.segs)
    .map(sg=>'<span class="alg"><i style="background:'+sg.color+'"></i>'+esc(sg.label)+"</span>").join("")+
    (A.yoy?'<span class="alg"><i class="dash"></i>Same period last year</span>':"");

  const actStrip='<div class="fstrip actstrip">'+
    '<label><span>Year</span><select id="a-year">'+YEARS.map(y=>opt(String(y),String(y),String(A.year))).join("")+"</select></label>"+
    '<label><span>Cut by</span><div class="segbtns">'+
      [["week","Week"],["day","Day"]].map(u=>'<button data-actunit="'+u[0]+'" aria-pressed="'+(A.unit===u[0])+'">'+u[1]+"</button>").join("")+
    "</div></label>"+
    '<label><span>'+(A.unit==="week"?"Weeks of the year":"Days of the year")+'</span>'+
      '<input type="text" id="a-range" class="wkin" placeholder="'+(A.unit==="week"?"1-9":"1-60")+'" value="'+esc(A.range)+'"></label>'+
    '<label><span>Measure</span><div class="segbtns">'+
      METRICS.map(m=>'<button data-actmetric="'+m[0]+'" aria-pressed="'+(A.metric===m[0])+'">'+m[1]+"</button>").join("")+
    "</div></label>"+
    '<label><span>Columns</span><div class="segbtns">'+
      [[0,"Auto"],[3,"3"],[4,"4"],[6,"6"],[8,"8"],[11,"11"]].map(c=>
        '<button data-actcols="'+c[0]+'" aria-pressed="'+(A.cols===c[0])+'">'+c[1]+"</button>").join("")+
    "</div></label>"+
    (isTenor?"":'<label><span>Scale</span><div class="segbtns">'+
      [["own","Own peak"],["shared","Shared"]].map(x=>
        '<button data-actscale="'+x[0]+'" aria-pressed="'+(A.scale===x[0])+'">'+x[1]+"</button>").join("")+
    "</div></label>")+
    '<label><span>Compare</span><div class="segbtns">'+
      '<button data-actyoy="1" aria-pressed="'+(!!A.yoy)+'">Year on year</button></div></label>'+
    '<div class="fspacer"></div><div class="alegend">'+actLegend+"</div></div>";

  const gridStyle=A.cols?' style="grid-template-columns:repeat('+A.cols+',minmax(0,1fr))"':"";
  const span=actCols.length?(A.unit==="week"?"weeks ":"days ")+actCols[0].key+"–"+actCols[actCols.length-1].key+" of "+A.year:"no periods in range";
  const activity=panel("Trading activity by trader",
    span+" · "+actRows.length+(actRows.length===1?" trader":" traders")+" · one column per "+A.unit+
      (A.yoy?" · dashed = same period last year":""),
    actStrip+'<div class="agrid"'+gridStyle+">"+actCards+"</div>",
    (isTenor
      ? "Each dot is a group of deals at one maturity, sized by how many. A book concentrated on one point of the curve is a row of large dots; a book spread across it is a column of small ones — which is the difference between a trader running a mandate and a trader wandering. The line is their median tenor."
      : "Each chart is one trader's own book, period by period, stacked by asset class.")+
    " Ordered by desk, so the people next to each other on the floor are next to each other here — a book that does not look like its neighbours' is the one to open. "+
    "<b>Click the name</b> to scope the whole page to that trader, the same as picking them in the rail — every chart above redraws on their book alone, and clicking the name again clears it. "+
    "<b>Click the card</b> to lock that trader across every panel without filtering anything away; <b>double-click</b> for the trader file.");


  return kpis+rowA+'<div class="mt10">'+rowB+"</div>"+'<div class="mt10">'+rowC+"</div>"+
    '<div class="mt10">'+activity+"</div>";
}
