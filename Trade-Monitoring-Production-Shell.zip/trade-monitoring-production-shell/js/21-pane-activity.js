/* ============================================================
   Pane — Trade Activity
   The overview answers "what fired". This answers "what is the floor actually
   doing" — the trading data on its own terms, before any rule touches it.
   Everything here is scoped by the rail, so it answers the same question for a
   desk, a trader or an asset class as it does for the whole book.
============================================================ */
function paneActivity(){
  const rows=TRADES.filter(tradeMatchesRail);
  const notl=rows.reduce((a,t)=>a+t.notional,0);
  /* Two readings of one book. "txn" counts the deals and measures them in
     notional; "pnl" draws the same cuts in what the desk earned on them. The
     panels, the dimensions and the layout are the same either way — only the
     quantity on the axis changes, so a shape you learned in one view is still
     the same shape in the other.

     Where a panel had a count and a notional twin, the P&L view keeps the pair
     but changes what the second one asks: P&L answers "where is the money", and
     P&L per million answers "where is it earned well". A name can be first on
     one and last on the other, which is the whole reason both are drawn.

     Revenue is held in USD thousands throughout, the same unit dealRevenue
     returns, so fmtK is the formatter everywhere below. */
  const PL=state.measure==="pnl";
  const mval=b=>PL?b.pl:b.n;                       // the primary measure
  const mfmt=v=>PL?fmtK(v):fmtNum(v);
  const munit=PL?"P&L":"deals";
  // Margin, in dollars earned per million traded — the second half of each pair.
  const marg=b=>b.nl>0?b.pl/b.nl*1000:0;
  const mgfmt=v=>"$"+fmtNum(Math.round(v));
  // Deals are cut "T:", notional "V:", revenue "R:"; a marker drawn over a bar
  // has to be measured in whatever the bar itself is measured in.
  const hlAggM=PL?hlAggR:hlAggT;
  const mcut=PL?"R:":"T:";
  // Sorted once: median and the 95th percentile are two reads of one ordering,
  // and at 59,000 tickets sorting twice is the most expensive line on the tab.
  const sizes=rows.map(t=>t.notional).sort((a,b)=>a-b);
  const activeTraders=uniq(rows.map(t=>t.traderId)).length;
  const bizDays=uniq(rows.map(t=>t.dayIdx)).length||1;

  /* The P&L reading of the same eight boxes. Sorted once, like the sizes above,
     because the best and the worst deal of the year are two reads of one
     ordering and the loss count is a third. */
  let kpis;
  if(PL){
    const pls=rows.map(t=>t.revenue).sort((a,b)=>a-b);
    const plTot=pls.reduce((a,v)=>a+v,0);
    const clTot=rows.reduce((a,t)=>a+t.clientRevenue,0);
    const lossN=pls.filter(v=>v<0).length;
    kpis='<div class="kpis">'+
      kpi("Net P&L",fmtK(plTot),"12 months, rail-scoped","var(--agent)")+
      kpi("Client revenue",fmtK(clTot),"dealing spread, before risk","var(--run)")+
      kpi("Margin",notl>0?mgfmt(plTot/notl*1000):"—","per $1m traded","var(--violet)")+
      kpi("Best deal",fmtK(pls.length?pls[pls.length-1]:0),"single ticket","var(--warn)")+
      kpi("Worst deal",fmtK(pls.length?pls[0]:0),"single ticket","var(--fail)")+
      kpi("P&L per day",fmtK(plTot/bizDays),"across "+fmtNum(bizDays)+" sessions","var(--cyan)")+
      kpi("Loss-making",rows.length?fmtPct(lossN/rows.length):"—","of "+fmtNum(rows.length)+" deals booked","var(--pink)")+
      kpi("Traders active",fmtNum(activeTraders),"of "+TRADERS.length+" on the floor","var(--gold)")+
      "</div>";
  }else{
    kpis='<div class="kpis">'+
      kpi("Deals booked",fmtNum(rows.length),"12 months, rail-scoped","var(--agent)")+
      kpi("Notional",fmtM(notl),"aggregate across products","var(--run)")+
      kpi("Median ticket",fmtM(median(sizes)),"p95 "+fmtM(pctile(sizes,0.95)),"var(--violet)")+
      kpi("Largest ticket",fmtM(Math.max(0,...sizes)),"single deal","var(--warn)")+
      kpi("Deals per day",fmtNum(Math.round(rows.length/bizDays)),"across "+fmtNum(bizDays)+" sessions","var(--cyan)")+
      kpi("Traders active",fmtNum(activeTraders),"of "+TRADERS.length+" on the floor","var(--gold)")+
      kpi("Products",fmtNum(uniq(rows.map(t=>t.product)).length),"of "+PRODUCTS.length+" approved","var(--pink)")+
      kpi("Counterparties",fmtNum(uniq(rows.map(t=>t.ctpy)).length),"names faced","var(--pass)")+
      "</div>";
  }

  /* One pass over the book, not one per series. Every panel below is a different
     cut of the same 12 months, and the readable shape — a filter per product, per
     counterparty, per band — walks the blotter a hundred times over. At the size a
     real floor books, that turned every toggle on this tab into a two-second wait.
     Collect once into buckets, read the buckets afterwards. */
  const SEP="\u0001";   // key delimiter, so 1+"FX Cash" cannot collide with 11+"FX Cash"
  const bucket=()=>({n:0,nl:0,pl:0,sizes:[],traders:Object.create(null),tn:0});
  const grab=(m,k)=>m[k]||(m[k]=bucket());
  const put=(b,t)=>{
    b.n++; b.nl+=t.notional; b.pl+=t.revenue; b.sizes.push(t.notional);
    if(!b.traders[t.traderId]){ b.traders[t.traderId]=1; b.tn++; }
  };
  const byProd=Object.create(null), byCtpy=Object.create(null), byAc=Object.create(null),
        byCh=Object.create(null), byTenor=Object.create(null), bySize=Object.create(null),
        byMonthAc=Object.create(null), ctpyType=Object.create(null),
        byDesk=Object.create(null), byTrader=Object.create(null),
        deskAc=Object.create(null), trAc=Object.create(null);
  const hrs=Array(24).fill(0), hrsPl=Array(24).fill(0);
  const tally=(m,k,ac)=>{ const c=m[k]||(m[k]=Object.create(null)); c[ac]=(c[ac]||0)+1; };
  rows.forEach(t=>{
    put(grab(byProd,t.product),t);
    put(grab(byDesk,t.deskId),t); tally(deskAc,t.deskId,t.ac);
    put(grab(byTrader,t.traderId),t); tally(trAc,t.traderId,t.ac);
    put(grab(byCtpy,t.ctpy),t);
    put(grab(byAc,t.ac),t);
    put(grab(byCh,t.channel),t);
    put(grab(byTenor,tenorBandOf(t.tenor)),t);
    put(grab(bySize,sizeBandOf(t.notional)),t);
    const mi=monthIdxOf(t.date);
    if(mi>=0){ const mb=grab(byMonthAc,mi+SEP+t.ac); mb.n++; mb.pl+=t.revenue; }
    const hh=Math.min(23,Math.floor(t.execMin/60));
    hrs[hh]++; hrsPl[hh]+=t.revenue;
    if(ctpyType[t.ctpy]===undefined) ctpyType[t.ctpy]=t.ctpyType||"";
  });
  // Alerts the same way: one pass keyed by dimension rather than a scan per series.
  const alBy={product:Object.create(null),ctpy:Object.create(null),
              tenorb:Object.create(null),sizeb:Object.create(null),
              desk:Object.create(null),trader:Object.create(null)};
  ALERTS.forEach(a=>{
    if(!matchRail(a)) return;
    alBy.desk[a.deskId]=(alBy.desk[a.deskId]||0)+1;
    alBy.trader[a.traderId]=(alBy.trader[a.traderId]||0)+1;
    a.products.forEach(x=>alBy.product[x]=(alBy.product[x]||0)+1);
    (a.ctpys||[]).forEach(x=>alBy.ctpy[x]=(alBy.ctpy[x]||0)+1);
    (a.tenorBands||[]).forEach(x=>alBy.tenorb[x]=(alBy.tenorb[x]||0)+1);
    (a.sizeBands||[]).forEach(x=>alBy.sizeb[x]=(alBy.sizeb[x]||0)+1);
  });
  const B=(m,k)=>m[k]||{n:0,nl:0,pl:0,sizes:[],tn:0};

  // Monthly volume, stacked by asset class — the book's own shape over the year.
  const months=MONTH_KEYS.map((mk,i)=>({label:mk.label,sub:i===0||mk.m===0?String(mk.y).slice(2):"",
    parts:ASSET_CLASSES.map(ac=>({label:ac,v:mval(byMonthAc[i+SEP+ac]||{n:0,pl:0}),color:AC_COLOR[ac]}))}));

  /* Every panel here is drawn from deals, so every marker is measured in deals
     too — "T:" for the count charts, "V:" for the notional ones, "R:" when the
     page is drawn in P&L. */
  const acSegs=ASSET_CLASSES.map(ac=>{
    const n=mval(B(byAc,ac));
    return {label:ac,v:n,color:AC_COLOR[ac],hl:'data-hlsrc="ac|'+esc(ac)+'" '+hlDim("ac",ac),agg:hlAggM("ac",ac,n)};
  }).filter(x=>x.v>0);
  const chSegs=CHANNELS.map(c=>{
    const n=mval(B(byCh,c[0]));
    return {label:c[0],v:n,
      color:{"Voice":"var(--run)","eComm single-dealer":"var(--agent)","Multi-dealer platform":"var(--cyan)",
             "API / Algo":"var(--violet)","Internal booking":"var(--ink-3)"}[c[0]]||"var(--ink-3)",
      hl:'data-hlsrc="channel|'+esc(c[0])+'" '+hlDim("channel",c[0]),
      agg:hlAggM("channel",c[0],n)};
  }).filter(x=>x.v>0);

  /* Product and counterparty, each measured twice — once by how often the desk
     deals and once by how much it moves. The two rankings disagree constantly,
     and the disagreement is the point: a name that is large by notional and
     small by count is a block relationship, and the reverse is a flow one. */
  const prodStats=PRODUCTS.map(pr=>{
    const b=byProd[pr.p]; if(!b) return null;
    const al=alBy.product[pr.p]||0;
    return {p:pr.p,ac:pr.ac,n:b.n,nl:b.nl,pl:b.pl,mg:marg(b),al,
      tiptable:["Deals|"+fmtNum(b.n),"Notional|"+fmtM(b.nl),
        "Median ticket|"+fmtM(median(b.sizes)||0),
        "P&L|"+fmtK(b.pl),"Margin|"+mgfmt(marg(b))+" per $1m",
        "Traders|"+b.tn,"Alerts|"+fmtNum(al)].join("§"),
      hl:'data-hlsrc="product|'+esc(pr.p)+'" '+hlDim("product",pr.p)};
  }).filter(Boolean);
  const prodA=prodStats.slice().sort((a,b)=>(PL?b.pl-a.pl:b.n-a.n)).slice(0,12).map(x=>({
    label:x.p,v:PL?x.pl:x.n,vLabel:PL?fmtK(x.pl):fmtNum(x.n),color:AC_COLOR[x.ac],
    tip:x.p,tipsub:x.ac+(PL?" · by P&L":" · by transaction count"),tiptable:x.tiptable,hl:x.hl,
    agg:hlAggM("product",x.p,PL?x.pl:x.n),aggKey:mcut+"product|"+x.p}));
  /* The notional twin, or in the P&L view the margin one. A margin bar is a
     ratio, so there is no share of it for a selection to account for and no
     marker to draw over it — it still lights where the selection is present. */
  const prodB=prodStats.slice().sort((a,b)=>(PL?b.mg-a.mg:b.nl-a.nl)).slice(0,12).map(x=>({
    label:x.p,v:PL?x.mg:x.nl,vLabel:PL?mgfmt(x.mg):fmtM(x.nl),color:AC_COLOR[x.ac],
    tip:x.p,tipsub:x.ac+(PL?" · by P&L per $1m":" · by notional"),tiptable:x.tiptable,hl:x.hl,
    agg:PL?hlAggR("product",x.p,x.pl):hlAggV("product",x.p,x.nl),
    aggKey:PL?null:"V:product|"+x.p}));

  const ctpyStats=Object.keys(byCtpy).map(c=>{
    const b=byCtpy[c], al=alBy.ctpy[c]||0, rel=!!RELATED_PARTIES[c];
    return {c,n:b.n,nl:b.nl,pl:b.pl,mg:marg(b),al,rel,type:ctpyType[c]||"",
      short:c.length>24?c.slice(0,23)+"…":c,
      tiptable:["Deals|"+fmtNum(b.n),"Notional|"+fmtM(b.nl),
        "Median ticket|"+fmtM(median(b.sizes)||0),
        "P&L|"+fmtK(b.pl),"Margin|"+mgfmt(marg(b))+" per $1m",
        "Traders facing this name|"+b.tn,
        "Alerts|"+fmtNum(al)].join("§"),
      hl:'data-hlsrc="ctpy|'+esc(c)+'" '+hlDim("ctpy",c)};
  });
  const ctpyRow=x=>({label:x.short,color:x.rel?"var(--fail)":"var(--agent)",
    tip:x.c,tipsub:x.type+(x.rel?" · related-party register":""),tiptable:x.tiptable,hl:x.hl});
  const ctpyA=ctpyStats.slice().sort((a,b)=>(PL?b.pl-a.pl:b.n-a.n)).slice(0,12)
    .map(x=>Object.assign(ctpyRow(x),{v:PL?x.pl:x.n,vLabel:PL?fmtK(x.pl):fmtNum(x.n),
      agg:hlAggM("ctpy",x.c,PL?x.pl:x.n),aggKey:mcut+"ctpy|"+x.c}));
  const ctpyB=ctpyStats.slice().sort((a,b)=>(PL?b.mg-a.mg:b.nl-a.nl)).slice(0,12)
    .map(x=>Object.assign(ctpyRow(x),{v:PL?x.mg:x.nl,vLabel:PL?mgfmt(x.mg):fmtM(x.nl),
      agg:PL?hlAggR("ctpy",x.c,x.pl):hlAggV("ctpy",x.c,x.nl),
      aggKey:PL?null:"V:ctpy|"+x.c}));

  const tenorItems=TENOR_BANDS.map(bd=>{
    const b=B(byTenor,bd.label), al=alBy.tenorb[bd.label]||0, v=mval(b);
    return {label:bd.label,v:v,color:bd.color,vLabel:mfmt(v),
      tip:bd.label,tipsub:"Tenor band",
      tiptable:["Deals|"+fmtNum(b.n),"Notional|"+fmtM(b.nl),
        "P&L|"+fmtK(b.pl),"Margin|"+mgfmt(marg(b))+" per $1m",
        "Share of the book|"+(rows.length?Math.round(b.n/rows.length*100):0)+"%","Alerts|"+fmtNum(al)].join("§"),
      hl:'data-hlsrc="tenorb|'+esc(bd.label)+'" '+hlDim("tenorb",bd.label),
      agg:hlAggM("tenorb",bd.label,v),aggKey:mcut+"tenorb|"+bd.label};
  });

  const sizeItems=SIZE_BANDS.map(bd=>{
    const b=B(bySize,bd[2]), al=alBy.sizeb[bd[2]]||0, v=mval(b);
    return {label:bd[2],v:v,color:"var(--run)",vLabel:mfmt(v),
      tip:bd[2],tipsub:"Ticket size band",
      tiptable:["Deals|"+fmtNum(b.n),"Notional|"+fmtM(b.nl),
        "P&L|"+fmtK(b.pl),"Margin|"+mgfmt(marg(b))+" per $1m",
        "Alerts|"+fmtNum(al)].join("§"),
      hl:'data-hlsrc="sizeb|'+esc(bd[2])+'" '+hlDim("sizeb",bd[2]),
      agg:hlAggM("sizeb",bd[2],v),aggKey:mcut+"sizeb|"+bd[2]};
  }).filter(x=>x.v>0);

  /* Desk and trader colour is the asset class each one mostly deals in, counted
     in deals rather than in the page's measure, so the colour of a desk does not
     change when the reader switches to P&L — colour follows the entity, never
     its rank. Most desks are a single class; the mix in the tooltip says so where
     one is not. */
  const domAc=m=>{ let best="",bn=-1; for(const k in m) if(m[k]>bn){ bn=m[k]; best=k; } return best; };
  const mixOf=(m,n)=>Object.keys(m||{}).sort((a,b)=>m[b]-m[a]).filter(k=>m[k]/n>=0.05)
    .map(k=>k+" "+Math.round(m[k]/n*100)+"%").join(" · ");
  const deskStats=DESKS.map(d=>{
    const b=byDesk[d.id]; if(!b) return null;
    return {d,b,v:mval(b),ac:domAc(deskAc[d.id]),al:alBy.desk[d.id]||0};
  }).filter(Boolean).sort((a,b)=>b.v-a.v);
  const deskItems=deskStats.map((x,i)=>({label:x.d.short,v:x.v,vLabel:mfmt(x.v),
    color:AC_COLOR[x.ac]||"var(--ink-3)",tip:x.d.name,
    tipsub:"Ranked "+(i+1)+" of "+deskStats.length+(PL?" by P&L":" by deals")+" · "+x.d.region,
    tiptable:["Deals|"+fmtNum(x.b.n),"Notional|"+fmtM(x.b.nl),"P&L|"+fmtK(x.b.pl),
      "Margin|"+mgfmt(marg(x.b))+" per $1m","Traders|"+x.b.tn,
      "Mix|"+mixOf(deskAc[x.d.id],x.b.n),"Alerts|"+fmtNum(x.al)].join("§"),
    hl:'data-hlsrc="desk|'+x.d.id+'" '+hlDim("desk",x.d.id),
    agg:hlAggM("desk",x.d.id,x.v),aggKey:mcut+"desk|"+x.d.id}));

  /* Every trader on the floor at once, area in the page's measure and grouped by
     desk. A tile's size is only comparable to its neighbours', which is why the
     desks are drawn as groups: the question it answers is "who carries this
     desk", and a desk carried by one tile is the one to look at. A tile cannot
     have negative area, so in the P&L view a trader who lost money in the scope
     is listed under the chart rather than silently dropped. */
  const tmGroups=deskStats.map(x=>{
    const items=TRADERS.filter(t=>t.deskId===x.d.id&&byTrader[t.id]).map(t=>{
      const b=byTrader[t.id], v=mval(b), ac=domAc(trAc[t.id]), parts=t.name.split(" ");
      const sur=parts[parts.length-1], ini=parts.map(w=>w.charAt(0)).join("");
      return {id:t.id,label:t.name,labels:[t.name,parts[0].charAt(0)+". "+sur,sur,ini],v,
        color:AC_COLOR[ac]||"var(--ink-3)",ac,tip:t.name,
        tipsub:x.d.short+" · "+t.grade+" · "+(x.v>0&&v>0?Math.round(v/x.v*100)+"% of the desk's "+(PL?"P&L":"deals"):""),
        tiptable:["Deals|"+fmtNum(b.n),"Notional|"+fmtM(b.nl),"P&L|"+fmtK(b.pl),
          "Margin|"+mgfmt(marg(b))+" per $1m","Mix|"+mixOf(trAc[t.id],b.n),
          "Alerts|"+fmtNum(alBy.trader[t.id]||0)].join("§"),
        hl:'data-hlsrc="trader|'+t.id+'" data-trader="'+t.id+'" data-hl-trader="'+t.id+'" data-hl-desk="'+t.deskId+'"',
        agg:hlAggM("trader",t.id,v),aggKey:mcut+"trader|"+t.id};
    });
    return {label:x.d.short,v:x.v,items,tip:x.d.name,tipsub:x.d.region+" · "+x.b.tn+" traders",
      tiptable:["Deals|"+fmtNum(x.b.n),"P&L|"+fmtK(x.b.pl),"Alerts|"+fmtNum(x.al)].join("§"),
      hl:'data-hlsrc="desk|'+x.d.id+'" '+hlDim("desk",x.d.id)+" "+hlAggM("desk",x.d.id,x.v)};
  });
  // A loss, or a desk that lost money overall, has no area to draw.
  const tmOut=[].concat(...tmGroups.map(g=>g.items.filter(it=>!(it.v>0))))
    .concat(...tmGroups.filter(g=>!(g.v>0)).map(g=>g.items.filter(it=>it.v>0)));
  const tmSmall=[];
  const tmSvg=treemap(tmGroups,{w:1600,h:440,fmt:mfmt,skipped:tmSmall});
  const tmDrawn=tmGroups.filter(g=>g.v>0).reduce((a,g)=>a.concat(g.items.filter(it=>it.v>0)),[])
    .filter(it=>tmSmall.indexOf(it)<0);
  const tmAcs=ASSET_CLASSES.filter(ac=>tmDrawn.some(it=>it.ac===ac));
  const tmList=a=>a.map(it=>esc(it.label)+" ("+mfmt(it.v)+")").join(", ");
  const tmNote=(tmOut.length?"Not drawn — "+(PL?"a loss":"no deals")+" in this scope: "+tmList(tmOut)+". ":"")+
    (tmSmall.length?"Too small to draw at this scale: "+tmList(tmSmall)+".":"");
  const tmPanel=panel("Trader map",
    (PL?"area = P&L":"area = deals")+" · grouped by desk · colour = main asset class · "+
      tmDrawn.length+(tmDrawn.length===1?" trader":" traders"),
    '<div class="panel-body"><div class="tmap-well">'+tmSvg+"</div>"+
      '<div class="tmap-foot"><div class="alegend">'+
        tmAcs.map(ac=>'<span class="alg"><i style="background:'+AC_COLOR[ac]+'"></i>'+esc(ac)+"</span>").join("")+"</div>"+
        (tmNote?'<div class="tmap-note">'+tmNote+"</div>":"")+
      "</div></div>",
    PL?"Who earns the floor's money, desk by desk. A desk whose revenue sits in one tile depends on one person's book — and a junior name holding the largest tile on a desk is a result that should be explainable before anyone is congratulated for it."
      :"Who does the floor's business, desk by desk. A desk whose deals sit in one tile depends on one person's book; a tile far larger than its neighbours on the same desk is someone dealing at a rate the rest of the desk does not.");

  const segTot=segs=>segs.reduce((a,x)=>a+x.v,0);
  const rowA='<div class="gridw2 tight">'+
    panel(PL?"P&L by month":"Deal volume by month","stacked by asset class · 12 months",
      '<div class="panel-body"><div class="chart-well tall">'+
        stackedBars(months,null,{w:660,h:266,dim:"ac",hlMonth:true,cut:mcut,
          unitLabel:PL?"P&L":"deals",fmt:PL?fmtK:null,padL:PL?48:34})+"</div></div>",
      PL?"The earnings shape across the year. It is not the volume shape: a quiet month on a wide spread can out-earn a busy one on a thin margin."
        :"The book's own shape across the year. Quarter ends and roll dates are visible without anyone marking them.")+
    panel("Asset class mix",PL?"share of P&L":"share of deals",
      '<div class="panel-body"><div class="chart-well donut-well">'+
      donut(acSegs,PL?fmtK(segTot(acSegs)):fmtNum(rows.length),PL?"P&L":"deals",112,19)+
      donutLegend(acSegs,PL?segTot(acSegs):rows.length,null,PL?{head:"P&L",fmt:fmtK}:null)+"</div></div>",
      PL?"Where the floor earns, which is rarely where it is busiest — options and credit carry a handful of per cent of the deals and a far larger share of the revenue."
        :"Hovering a class lights it across every panel on the page.")+
    panel("Booking channel",PL?"share of P&L":"how the deals reached the system",
      '<div class="panel-body"><div class="chart-well donut-well">'+
      donut(chSegs,PL?fmtK(segTot(chSegs)):fmtNum(rows.length),PL?"P&L":"deals",112,19)+
      donutLegend(chSegs,PL?segTot(chSegs):rows.length,null,PL?{head:"P&L",fmt:fmtK}:null)+"</div></div>",
      PL?"Voice earns a multiple of what the platforms do on the same notional, which is the commercial reason the least-evidenced channel is also the hardest to retire."
        :"Voice and internal bookings are the two channels with the least automated evidence behind them.")+
    "</div>";

  const rowB='<div class="grid4t tight">'+
    panel(PL?"P&L by product":"Transaction count by product",PL?"top 12 by P&L":"top 12 by deals",
      '<div class="panel-body"><div class="chart-well">'+hbars(prodA,{w:520,rowH:19,labW:148})+"</div></div>",
      PL?"What each product earned the floor over the year."
        :"How often the floor deals in each product.")+
    panel(PL?"Margin by product":"Volume by product",PL?"top 12 by margin":"top 12 by notional",
      '<div class="panel-body"><div class="chart-well">'+hbars(prodB,{w:520,rowH:19,labW:148})+"</div></div>",
      PL?"The same products by how well they earn rather than how much. A product high here and absent beside it earns a good margin on very little volume — which is where a mispriced ticket hides best."
        :"The same products by size. Where this order differs from the count beside it, the product trades in blocks rather than in flow.")+
    panel(PL?"P&L by counterparty":"Transaction count by counterparty",
      (PL?"top 12 by P&L":"top 12 by deals")+" · red = related party",
      '<div class="panel-body"><div class="chart-well">'+hbars(ctpyA,{w:540,rowH:19,labW:168})+"</div></div>",
      PL?"Which names the floor earns most from."
        :"Who the floor deals with most often.")+
    panel(PL?"Margin by counterparty":"Volume by counterparties",
      (PL?"top 12 by margin":"top 12 by notional")+" · red = related party",
      '<div class="panel-body"><div class="chart-well">'+hbars(ctpyB,{w:540,rowH:19,labW:168})+"</div></div>",
      PL?"Margin per name, which is where price-fairness questions start. A related party dealing at a visibly thinner margin than comparable names is the shape the off-market rules are built to find."
        :"A name large by notional and small by count is a block relationship; the reverse is a flow one. Concentration is not itself a finding, but every off-market pattern eventually points at one of these names.")+
    "</div>";

  const rowC='<div class="grid4t tight">'+
    panel("Execution hours",(PL?"P&L through the trading day":"the trading day")+" · desk-local time",
      '<div class="panel-body"><div class="chart-well">'+
        hourChart(PL?hrsPl:hrs,{w:560,h:212,cut:mcut,unitLabel:PL?"P&L":"Deals",
          fmt:PL?fmtK:null,padL:PL?44:30})+"</div></div>",
      PL?"Earnings by hour of the session. Revenue booked into the shaded hours, when neither the client nor the market is watching closely, is worth more scrutiny than revenue booked at midday."
        :"Every deal, not just the alerting ones — the shape a normal session makes, and the baseline the after-hours rule measures against. Select a trader anywhere on the page and this redraws as their session.")+
    panel("Ticket size distribution",PL?"P&L per size band":"deals per size band",
      '<div class="panel-body"><div class="chart-well">'+hbars(sizeItems,{w:460,rowH:19,labW:110})+"</div></div>",
      PL?"Where in the size profile the money is made. The small-ticket bands carry most of the deals and a minority of the revenue; the tail on the right is the reverse."
        :"A book's size profile is never linear. The tail on the right is where the authorisation rules live.")+
    panel("Tenor profile",PL?"P&L by maturity band":"how long the risk runs",
      '<div class="panel-body"><div class="chart-well">'+hbars(tenorItems,{w:460,rowH:26,labW:120})+"</div></div>",
      PL?"Longer risk earns more per million because the spread is charged on a bigger duration. A short book earning like a long one is worth a question."
        :"The whole book by maturity band, against which any one trader's mix can be read.")+
    panel("Desk",(PL?"ranked by P&L":"ranked by deals")+" · colour = main asset class",
      '<div class="panel-body"><div class="chart-well">'+hbars(deskItems,{w:460,rowH:19,labW:116})+"</div></div>",
      PL?"The desks ranked by what they earned. Read it against the deal ranking: a desk that climbs when the measure changes earns on margin rather than on flow."
        :"The desks ranked by how many deals they book. Hover a desk to see it across every other panel; double-click to scope the page to it.")+
    "</div>";

  /* Trading activity, one small chart per trader. Alert panels answer "who is
     firing"; this answers the question underneath it — what does this person's
     book actually look like, period by period, and does it look like their
     neighbours'. Squeezed on purpose: a burst, a gap, or a drift into longer
     tenors is a shape you see before you read a number. */
  const A=state.act;
  const actCols=actColumns();
  const act=traderActivity(actCols,A.metric);
  const unit=A.metric==="notional"?"m":A.metric==="pnl"?"k":"n";
  const isTenor=A.metric==="tenor";
  const actRows=TRADERS.filter(traderInRail).slice().sort((a,b)=>
    a.deskId.localeCompare(b.deskId,undefined,{numeric:true})||TRADER_STATS[b.id].idx-TRADER_STATS[a.id].idx);
  const cellTot=c=>act.segs.reduce((x,sg)=>x+(c.v[sg.label]||0),0);
  const sharedMax=Math.max(1e-9,...actRows.map(t=>Math.max(0,...act.by[t.id].map(cellTot))));
  /* The page-level measure decides what the first of these three asks: deals in
     the transaction view, earnings in the P&L one. Notional and tenor are
     properties of the book either way and stay offered in both. */
  const METRICS=[PL?["pnl","P&L"]:["count","Deal count"],
    ["notional","Notional volume"],["tenor","Tenor spread"]];
  const YEARS=uniq(Array.from({length:DAYS},(_,d)=>dateForIdx(d).getFullYear())).sort();

  const railTrader=state.filters.trader;
  const actCards=actCols.length?actRows.map(t=>{
    const cells=act.by[t.id];
    const tot=cells.reduce((a,c)=>a+cellTot(c),0);
    const peak=Math.max(0,...cells.map(cellTot));
    const allT=isTenor?cells.reduce((a,c)=>a.concat(c.tenors||[]),[]):null;
    const scoped=railTrader.size===1&&railTrader.has(t.id);
    return '<div class="acard" data-trader="'+t.id+'" data-hlsrc="trader|'+t.id+
      '" data-hl-trader="'+t.id+'" data-hl-desk="'+t.deskId+'" '+
      hlAggT("trader",t.id,TRADER_STATS[t.id].trades)+">"+
      '<div class="an"><button type="button" class="anlink'+(scoped?" on":"")+'" data-railtrader="'+t.id+
        '" data-tip="'+esc(t.name)+'" data-tipsub="'+
        (scoped?"Scoping the whole page · click to clear":"Click to scope every chart on the page to this trader")+
        '">'+esc(t.name)+"</button></div>"+
      '<div class="ad">'+esc(DESK_BY_ID[t.deskId].short)+" · "+esc(t.grade.replace("Executive Director","ED"))+"</div>"+
      (isTenor?tenorScatter(cells,{w:188,h:62,yoy:A.yoy})
              :sparkStack(cells,act.segs,{w:188,h:62,unit:unit,yoy:A.yoy,max:A.scale==="shared"?sharedMax:0}))+
      '<div class="af"><span>'+(isTenor?fmtNum(allT.length)+" deals"
          :A.metric==="notional"?fmtM(tot):A.metric==="pnl"?fmtK(tot):fmtNum(tot)+" deals")+"</span>"+
      "<b>"+(isTenor?(allT.length?fmtYrs(median(allT))+" med · "+uniq(allT.map(x=>x.toFixed(2))).length+" tenors":"—")
          :"peak "+(A.metric==="notional"?fmtM(peak):A.metric==="pnl"?fmtK(peak):fmtNum(peak)))+"</b></div>"+
      "</div>";
  }).join(""):'<div class="anodata">No weeks or days match that range. Try clearing it, or widen the numbers.</div>';

  const actLegend=(isTenor?TENOR_BANDS.map(b=>({label:b.label,color:b.color})):act.segs)
    .map(sg=>'<span class="alg"><i style="background:'+sg.color+'"></i>'+esc(sg.label)+"</span>").join("")+
    (A.yoy?'<span class="alg"><i class="dash"></i>Same period last year</span>':"");

  const actStrip='<div class="fstrip actstrip">'+
    '<label><span>Year</span><select id="a-year">'+YEARS.map(y=>opt(String(y),String(y),String(A.year))).join("")+"</select></label>"+
    '<label><span>Cut by</span><div class="segbtns">'+
      [["week","Week"],["day","Day"]].map(u=>'<button data-actunit="'+u[0]+'" aria-pressed="'+(A.unit===u[0])+'">'+u[1]+"</button>").join("")+
    "</div></label>"+
    '<label><span>'+(A.unit==="week"?"Weeks of the year":"Days of the year")+'</span>'+
      '<input type="text" id="a-range" class="wkin" placeholder="'+(A.unit==="week"?"1-9":"1-60")+'" value="'+esc(A.range)+'"></label>'+
    '<label><span>Measure</span><div class="segbtns">'+
      METRICS.map(m=>'<button data-actmetric="'+m[0]+'" aria-pressed="'+(A.metric===m[0])+'">'+m[1]+"</button>").join("")+
    "</div></label>"+
    '<label><span>Columns</span><div class="segbtns">'+
      [[0,"Auto"],[3,"3"],[4,"4"],[6,"6"],[8,"8"],[11,"11"]].map(c=>
        '<button data-actcols="'+c[0]+'" aria-pressed="'+(A.cols===c[0])+'">'+c[1]+"</button>").join("")+
    "</div></label>"+
    (isTenor?"":'<label><span>Scale</span><div class="segbtns">'+
      [["own","Own peak"],["shared","Shared"]].map(x=>
        '<button data-actscale="'+x[0]+'" aria-pressed="'+(A.scale===x[0])+'">'+x[1]+"</button>").join("")+
    "</div></label>")+
    '<label><span>Compare</span><div class="segbtns">'+
      '<button data-actyoy="1" aria-pressed="'+(!!A.yoy)+'">Year on year</button></div></label>'+
    '<div class="fspacer"></div><div class="alegend">'+actLegend+"</div></div>";

  const gridStyle=A.cols?' style="grid-template-columns:repeat('+A.cols+',minmax(0,1fr))"':"";
  const span=actCols.length?(A.unit==="week"?"weeks ":"days ")+actCols[0].key+"–"+actCols[actCols.length-1].key+" of "+A.year:"no periods in range";
  const activity=panel("Trading activity by trader",
    span+" · "+actRows.length+(actRows.length===1?" trader":" traders")+" · one column per "+A.unit+
      (A.yoy?" · dashed = same period last year":""),
    actStrip+'<div class="agrid"'+gridStyle+">"+actCards+"</div>",
    (isTenor
      ? "Each dot is a group of deals at one maturity, sized by how many. A book concentrated on one point of the curve is a row of large dots; a book spread across it is a column of small ones — which is the difference between a trader running a mandate and a trader wandering. The line is their median tenor."
      : "Each chart is one trader's own book, period by period, stacked by asset class.")+
    " Ordered by desk, so the people next to each other on the floor are next to each other here — a book that does not look like its neighbours' is the one to open. "+
    "<b>Click the name</b> to scope the whole page to that trader, the same as picking them in the rail — every chart above redraws on their book alone, and clicking the name again clears it. "+
    "<b>Click the card</b> to lock that trader across every panel without filtering anything away; <b>double-click</b> for the trader file.");


  return kpis+rowA+'<div class="mt10">'+rowC+"</div>"+'<div class="mt10">'+rowB+"</div>"+
    '<div class="mt10">'+tmPanel+"</div>"+'<div class="mt10">'+activity+"</div>";
}
