/* ============================================================
   Data dictionary
   What each rule actually needs to run. A typology is only as good as the feed
   behind it: half the rules on this page are impossible without a timestamp to
   the second, and a third of them are impossible without reference data nobody
   owns. Naming the fields — and the system each comes from — is what turns a
   rule library into something an implementation team can cost.
============================================================ */
const DATA_ELEMENTS={
  tid:      ["Trade / deal ID",                     "Trade capture"],
  tdate:    ["Trade date",                          "Trade capture"],
  exec:     ["Execution timestamp, to the second",  "Trade capture / venue"],
  cap:      ["Capture timestamp",                   "Trade capture"],
  trader:   ["Trader ID",                           "Trade capture · HR feed"],
  book:     ["Booking book",                        "Trade capture"],
  desk:     ["Desk / reporting line",               "HR feed"],
  prod:     ["Product",                             "Trade capture"],
  inst:     ["Instrument identifier (ISIN / pair)", "Trade capture · reference data"],
  notional: ["Notional",                            "Trade capture"],
  dir:      ["Direction",                           "Trade capture"],
  px:       ["Traded price or rate",                "Trade capture"],
  ivol:     ["Quoted implied volatility",           "Trade capture"],
  tenor:    ["Tenor / maturity date",               "Trade capture"],
  valdate:  ["Value date",                          "Trade capture"],
  ctpy:     ["Counterparty ID (LEI)",               "Trade capture"],
  venue:    ["Execution venue",                     "Trade capture"],
  channel:  ["Booking channel",                     "Trade capture"],
  status:   ["Booking status",                      "Trade capture"],
  amend:    ["Amendment log — field, old, new, time","Trade capture audit"],
  cancel:   ["Cancellation timestamp",              "Trade capture audit"],
  pnl:      ["Deal P&L",                            "Product control"],

  mid:      ["Market mid at execution",             "Market data — tick store"],
  spread:   ["Prevailing bid / offer",              "Market data — tick store"],
  range:    ["Intraday high / low",                 "Market data — tick store"],
  surface:  ["Volatility surface by pair and tenor","Market data — official surface"],
  curve:    ["Rate and forward-points curve",       "Market data — curve service"],
  fixing:   ["Published benchmark fixing",          "Benchmark administrator"],
  gc:       ["General collateral rate",             "Money-market data"],

  ctpystat: ["Counterparty static record",          "Client reference data"],
  ssi:      ["Standing settlement instructions",    "Settlement static data"],
  relparty: ["Related-party register",              "Compliance — conflicts register"],
  restrict: ["Restricted / watch list, dated",      "Control room"],
  wall:     ["Wall-crossing approvals",             "Control room"],
  hrjur:    ["High-risk jurisdiction list",         "Financial crime policy"],
  mandate:  ["Trader product authorisation",        "Front-office mandate register"],
  bookreg:  ["Trader book ownership and delegation","Front-office mandate register"],
  ctpycap:  ["Trader counterparty concentration cap","Market risk limits"],
  ticketlim:["Trader ticket authorisation",         "Front-office mandate register"],
  poslim:   ["Trader position limit",               "Market risk limits"],
  tenorlim: ["Trader tenor authorisation",          "Front-office mandate register"],
  leave:    ["Block-leave calendar",                "HR feed"],
  hours:    ["Desk hours / trader working pattern", "HR feed · derived baseline"],
  cohort:   ["Peer cohort membership",              "HR feed · derived"],
  superv:   ["Supervisor and delegation record",    "HR feed"],
  cal:      ["Business-day and holiday calendar",   "Reference data"],
  period:   ["Reporting-period calendar",           "Finance"],

  pos:      ["Intraday position snapshots",         "Risk engine"],
  eodpos:   ["End-of-day position",                 "Risk engine"],
  dpnl:     ["Daily P&L by trader",                 "Product control"],
  ipv:      ["Independent price verification marks","Product control"],
  modeltol: ["Day-one P&L tolerance by structure",  "Model validation"],
  collat:   ["Collateral schedule and substitutions","Collateral management"],

  orders:   ["Order log — placed, amended, pulled", "Order management system"],
  clord:    ["Client order record and timestamp",   "Order management system"],
  alloc:    ["Allocation instructions and timestamps","Order management system"],
  confirm:  ["Confirmation status and timestamp",   "Confirmations / matching"],
  settle:   ["Settlement accounts and amounts",     "Settlement / nostro"],
  news:     ["Announcement and corporate-action calendar","Market data — events"],

  base:     ["Trader's own trailing baseline",      "Derived — surveillance warehouse"],
};
/* Fields each rule reads. Codes resolve against the dictionary above, so a field
   is described once and the rules reference it. */
const RULE_REQ={
  "TS-01":["px","mid","spread","notional","dir","inst","trader","ctpy","relparty","base"],
  "TS-02":["exec","cap","tdate","tid","trader","notional","channel","base"],
  "TS-03":["amend","cancel","tid","trader","tdate","notional","base"],
  "TS-04":["inst","dir","notional","exec","ctpy","trader","pnl","tid"],
  "TS-05":["inst","dir","notional","tdate","ctpy","trader","cal"],
  "TS-06":["notional","inst","exec","trader","ticketlim","ctpy","superv"],
  "TS-07":["prod","trader","mandate","desk","notional","book","inst"],
  "TS-08":["exec","cap","trader","hours","cal","notional","prod","base"],
  "TS-09":["px","mid","tdate","dir","trader","pnl","period","ipv","inst"],
  "TS-10":["exec","notional","dir","inst","trader","fixing","mid","base"],
  "TS-11":["exec","inst","dir","notional","trader","clord","ctpy","pnl","orders"],
  "TS-12":["pos","eodpos","poslim","ticketlim","notional","exec","trader","inst"],
  "TS-13":["dpnl","trader","base","notional","prod","mid"],
  "TS-14":["book","inst","notional","tdate","trader","pnl","period","dir"],
  "TS-15":["ivol","surface","notional","inst","tenor","trader","pnl","base"],
  "TS-16":["px","mid","spread","book","ctpy","notional","trader","pnl","inst"],
  "TS-17":["ssi","ctpystat","exec","amend","ctpy","notional","trader","tid"],
  "TS-18":["notional","tenor","valdate","tdate","trader","period","ctpy","base"],
  "TS-19":["trader","tdate","leave","notional","prod","channel","superv"],
  "TS-20":["inst","dir","notional","tdate","trader","news","pnl","base","cal"],
  "TS-21":["px","curve","mid","tenor","notional","inst","trader","ctpy","base"],
  "TS-22":["px","mid","spread","ctpy","trader","tdate","notional","relparty","base"],
  "TS-23":["px","fixing","inst","tenor","notional","trader","valdate"],
  "TS-24":["px","range","mid","exec","dir","trader","inst","base"],
  "TS-25":["cancel","cap","exec","status","trader","tid","notional","ctpy","base"],
  "TS-26":["cancel","valdate","confirm","status","tid","trader","notional","settle"],
  "TS-27":["amend","cap","px","notional","tenor","valdate","trader","pnl","confirm"],
  "TS-28":["cap","exec","trader","tid","channel","ctpy","notional","base"],
  "TS-29":["book","bookreg","desk","trader","superv","notional","prod","inst"],
  "TS-30":["orders","cancel","exec","venue","channel","trader","inst","dir","base"],
  "TS-31":["exec","dir","notional","mid","inst","trader","pnl","orders","venue"],
  "TS-32":["exec","notional","dir","mid","trader","hours","inst","base"],
  "TS-33":["px","mid","spread","exec","ctpy","dir","notional","trader","relparty"],
  "TS-34":["notional","ticketlim","tdate","trader","inst","base"],
  "TS-35":["tenor","tenorlim","trader","prod","notional","valdate"],
  "TS-36":["prod","trader","tdate","notional","base","mandate"],
  "TS-37":["tdate","trader","leave","notional","tid","base","superv"],
  "TS-38":["notional","tdate","trader","base","prod","news"],
  "TS-39":["dpnl","trader","base","cal","ipv","pos"],
  "TS-40":["pnl","notional","prod","modeltol","surface","curve","trader","ctpy"],
  "TS-41":["dpnl","trader","period","pnl","inst","mid","cal"],
  "TS-42":["settle","ssi","ctpystat","notional","tid","trader","ctpy"],
  "TS-43":["settle","ssi","hrjur","ctpystat","ctpy","notional","trader","tid"],
  "TS-44":["confirm","tdate","trader","notional","ctpy","cal","base"],
  "TS-45":["alloc","clord","exec","px","mid","notional","ctpy","trader","relparty"],
  "TS-46":["ctpy","ctpycap","trader","tdate","notional","cohort","base","relparty"],
  "TS-47":["inst","restrict","wall","tdate","trader","notional","channel"],
  "TS-48":["inst","dir","notional","tdate","trader","news","pnl","base"],
  "TS-49":["px","gc","ctpy","relparty","notional","tenor","trader"],
  "TS-50":["collat","period","tdate","notional","trader","ctpy","cal"],
};
/* Grouped by the system that has to supply them — which is the shape of the
   conversation an implementation team actually has. */
function ruleSchema(id){
  const codes=RULE_REQ[id]||[];
  const bySrc={};
  codes.forEach(c=>{ const e=DATA_ELEMENTS[c]; if(!e) return; (bySrc[e[1]]=bySrc[e[1]]||[]).push(e[0]); });
  return {codes,bySrc,n:codes.length,systems:Object.keys(bySrc).length};
}

const RULE_BY_ID={}; RULES.forEach(r=>RULE_BY_ID[r.id]=r);
const RULE_CATS=[]; RULES.forEach(r=>{ if(RULE_CATS.indexOf(r.cat)<0) RULE_CATS.push(r.cat); });

const SEV_ORDER=["Critical","High","Medium","Low"];
const SEV_RANK={Critical:4,High:3,Medium:2,Low:1};
const SEV_COLOR={Critical:"var(--fail)",High:"var(--warn)",Medium:"var(--run)",Low:"var(--ink-3)"};
const SEV_TAG={Critical:"t-fail",High:"t-warn",Medium:"t-run",Low:"t-muted"};
const SEV_BASE={Critical:80,High:64,Medium:46,Low:29};
const STATUSES=["Open","In Review","Passed","Suspicious","Escalated"];
const STATUS_TAG={"Open":"t-warn","In Review":"t-run","Passed":"t-pass","Suspicious":"t-fail","Escalated":"t-violet"};
const STATUS_COLOR={"Open":"var(--warn)","In Review":"var(--run)","Passed":"var(--pass)","Suspicious":"var(--fail)","Escalated":"var(--violet)"};
const OFFICER="You (Trade Compliance)";
const PEERS=["A. Fitzgerald","M. Sundaram","L. Chevalier","P. Adeyemi"];

/* Calendar landmarks the rules key off. */
const BIZ_DAYS=[]; for(let d=0;d<DAYS;d++) if(isBiz(dateForIdx(d))) BIZ_DAYS.push(d);
const MONTH_END=[];   // last business day index of each month in range
(function(){
  for(let i=0;i<BIZ_DAYS.length;i++){
    const d=BIZ_DAYS[i], nx=BIZ_DAYS[i+1];
    if(nx==null||dateForIdx(nx).getMonth()!==dateForIdx(d).getMonth()) MONTH_END.push(d);
  }
})();
const QUARTER_END=MONTH_END.filter(d=>[2,5,8,11].indexOf(dateForIdx(d).getMonth())>=0);
const bizBack=(day,k)=>BIZ_DAYS[Math.max(0,BIZ_DAYS.indexOf(day)-k)];
const bizFwd=(day,k)=>BIZ_DAYS[Math.min(BIZ_DAYS.length-1,BIZ_DAYS.indexOf(day)+k)];
/* Month ends with room left in the book for the reversal leg. Without this the
   last month end in range clamps forward onto itself and the evidence reads
   "reversed 0 days later", which is not a pattern, it is an artefact. */
const MONTH_END_REV=MONTH_END.filter(d=>BIZ_DAYS.indexOf(d)<BIZ_DAYS.length-11);
