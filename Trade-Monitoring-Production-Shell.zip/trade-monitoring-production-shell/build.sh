#!/bin/sh
# Flatten the shell into one .html. The payload is NOT inlined: the page still
# needs window.TM_DATA or a data.json served beside it.
set -e
OUT="${1:-trade-monitoring-shell.html}"
{
  sed -n '1,/<title>/p' index.html
  printf '<style>\n'; cat css/dashboard.css; printf '</style>\n</head>\n'
  sed -n '/<body>/,$p' index.html | sed '/<script src=/d; /<\/body>/d; /<\/html>/d'
  printf '<script>\n'
  while read -r f; do [ -n "$f" ] && cat "js/$f" && printf '\n'; done < MODULES
  printf '</script>\n</body>\n</html>\n'
} > "$OUT"
echo "wrote $OUT ($(wc -c < "$OUT") bytes)"
